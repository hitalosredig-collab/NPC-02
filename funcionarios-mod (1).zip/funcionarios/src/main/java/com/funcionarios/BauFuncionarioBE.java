package com.funcionarios;

import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.world.Container;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.common.capabilities.ForgeCapabilities;
import net.minecraftforge.common.util.LazyOptional;
import net.minecraftforge.items.IItemHandler;
import net.minecraftforge.items.wrapper.InvWrapper;

/**
 * Baú do Funcionário. O tamanho depende do nível (madeira, cobre, ferro, ouro, diamante, netherite).
 * Dois baús lado a lado (mesma direção) ficam fundidos: o funcionário e os funis enxergam os dois como um só.
 */
public class BauFuncionarioBE extends BlockEntity {
    /** Todos os baús carregados no servidor (para o funcionário achar o do dono sem varrer o mundo). */
    public static final Set<BauFuncionarioBE> TODOS = ConcurrentHashMap.newKeySet();

    private final SimpleContainer armazem;
    private final int linhas;
    private final int colunas;
    private final LazyOptional<IItemHandler> manipulador = LazyOptional.of(Ligado::new);
    private UUID dono;

    public BauFuncionarioBE(BlockPos pos, BlockState estado) {
        super(Registros.BAU_BE.get(), pos, estado);
        this.linhas = estado.getBlock() instanceof BauFuncionarioBloco b ? b.getLinhas() : 3;
        this.colunas = estado.getBlock() instanceof BauFuncionarioBloco b2 ? b2.getColunas() : 9;
        this.armazem = new SimpleContainer(linhas * colunas);
        armazem.addListener(c -> setChanged());
    }

    public int getLinhas() {
        return linhas;
    }

    public int getColunas() {
        return colunas;
    }

    public SimpleContainer getArmazem() {
        return armazem;
    }

    public UUID getDono() {
        return dono;
    }

    public void setDono(UUID dono) {
        this.dono = dono;
        setChanged();
    }

    private boolean mesmoDono(BauFuncionarioBE o) {
        return dono == null || o.dono == null || dono.equals(o.dono);
    }

    /** O baú fundido ao lado (ou null). */
    public BauFuncionarioBE parceiro() {
        if (this.level == null) return null;
        BlockState st = getBlockState();
        if (!(st.getBlock() instanceof BauFuncionarioBloco)) return null;
        Direction f = st.getValue(BauFuncionarioBloco.FACING);
        for (Direction d : new Direction[] {f.getClockWise(), f.getCounterClockWise()}) {
            BlockPos p = worldPosition.relative(d);
            BlockState o = level.getBlockState(p);
            if (o.getBlock() instanceof BauFuncionarioBloco && o.getValue(BauFuncionarioBloco.FACING) == f
                    && level.getBlockEntity(p) instanceof BauFuncionarioBE be && !be.isRemoved() && mesmoDono(be)) {
                return be;
            }
        }
        return null;
    }

    /** {primeiro, segundo ou null}, em ordem fixa (a mesma para os dois lados do par). */
    public BauFuncionarioBE[] ordenado() {
        BauFuncionarioBE p = parceiro();
        if (p == null) return new BauFuncionarioBE[] {this, null};
        return this.worldPosition.asLong() <= p.worldPosition.asLong()
                ? new BauFuncionarioBE[] {this, p} : new BauFuncionarioBE[] {p, this};
    }

    /** Conteúdo do par inteiro (ou só deste baú). */
    public Container containerLigado() {
        BauFuncionarioBE[] o = ordenado();
        if (o[1] == null) return armazem;
        return new net.minecraft.world.CompoundContainer(o[0].armazem, o[1].armazem);
    }

    @Override
    public void onLoad() {
        super.onLoad();
        if (this.level != null && !this.level.isClientSide) TODOS.add(this);
    }

    @Override
    public void setRemoved() {
        super.setRemoved();
        TODOS.remove(this);
    }

    @Override
    public void onChunkUnloaded() {
        super.onChunkUnloaded();
        TODOS.remove(this);
    }

    @Override
    public <T> LazyOptional<T> getCapability(Capability<T> cap, Direction lado) {
        if (cap == ForgeCapabilities.ITEM_HANDLER) return manipulador.cast();
        return super.getCapability(cap, lado);
    }

    @Override
    public void invalidateCaps() {
        super.invalidateCaps();
        manipulador.invalidate();
    }

    /** Manipulador de itens que enxerga o par fundido como um só baú. */
    private class Ligado implements IItemHandler {
        private InvWrapper w() {
            return new InvWrapper(containerLigado());
        }

        @Override
        public int getSlots() {
            return w().getSlots();
        }

        @Override
        public ItemStack getStackInSlot(int slot) {
            return w().getStackInSlot(slot);
        }

        @Override
        public ItemStack insertItem(int slot, ItemStack stack, boolean simular) {
            return w().insertItem(slot, stack, simular);
        }

        @Override
        public ItemStack extractItem(int slot, int quantidade, boolean simular) {
            return w().extractItem(slot, quantidade, simular);
        }

        @Override
        public int getSlotLimit(int slot) {
            return w().getSlotLimit(slot);
        }

        @Override
        public boolean isItemValid(int slot, ItemStack stack) {
            return w().isItemValid(slot, stack);
        }
    }

    @Override
    protected void saveAdditional(CompoundTag tag) {
        super.saveAdditional(tag);
        ListTag lista = new ListTag();
        for (int i = 0; i < armazem.getContainerSize(); i++) {
            ItemStack s = armazem.getItem(i);
            if (s.isEmpty()) continue;
            CompoundTag t = new CompoundTag();
            t.putShort("Slot", (short) i);
            s.save(t);
            lista.add(t);
        }
        tag.put("Armazem", lista);
        if (dono != null) tag.putUUID("Dono", dono);
    }

    @Override
    public void load(CompoundTag tag) {
        super.load(tag);
        armazem.clearContent();
        ListTag lista = tag.getList("Armazem", 10);
        for (int i = 0; i < lista.size(); i++) {
            CompoundTag t = lista.getCompound(i);
            int slot = t.getShort("Slot");
            if (slot >= 0 && slot < armazem.getContainerSize()) armazem.setItem(slot, ItemStack.of(t));
        }
        dono = tag.hasUUID("Dono") ? tag.getUUID("Dono") : null;
    }
}
