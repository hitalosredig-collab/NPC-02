package com.funcionarios;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.Containers;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraftforge.network.NetworkHooks;

/** Baú só para os funcionários (6 níveis: cada um com mais linhas). Dois lado a lado se fundem. */
public class BauFuncionarioBloco extends BaseEntityBlock {
    public static final DirectionProperty FACING = BlockStateProperties.HORIZONTAL_FACING;

    private final int linhas;
    private final int colunas;

    public BauFuncionarioBloco(Properties propriedades, int linhas, int colunas) {
        super(propriedades);
        this.linhas = linhas;
        this.colunas = colunas;
        this.registerDefaultState(this.stateDefinition.any().setValue(FACING, Direction.NORTH));
    }

    public int getLinhas() {
        return linhas;
    }

    public int getColunas() {
        return colunas;
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> b) {
        b.add(FACING);
    }

    @Override
    public BlockState getStateForPlacement(BlockPlaceContext c) {
        return this.defaultBlockState().setValue(FACING, c.getHorizontalDirection().getOpposite());
    }

    @Override
    public BlockState rotate(BlockState st, Rotation r) {
        return st.setValue(FACING, r.rotate(st.getValue(FACING)));
    }

    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState estado) {
        return new BauFuncionarioBE(pos, estado);
    }

    @Override
    public RenderShape getRenderShape(BlockState estado) {
        return RenderShape.MODEL;
    }

    @Override
    public InteractionResult use(BlockState estado, Level nivel, BlockPos pos, Player jogador,
                                 InteractionHand mao, BlockHitResult acerto) {
        if (nivel.isClientSide) return InteractionResult.SUCCESS;
        BlockEntity be = nivel.getBlockEntity(pos);
        if (be instanceof BauFuncionarioBE bau && jogador instanceof ServerPlayer sp) {
            if (bau.getDono() != null && !bau.getDono().equals(jogador.getUUID()) && !jogador.isCreative()) {
                sp.displayClientMessage(Component.literal("Este baú é de outro jogador."), true);
                return InteractionResult.CONSUME;
            }
            BauFuncionarioBE[] par = bau.ordenado();
            BauFuncionarioBE a = par[0];
            BauFuncionarioBE b = par[1];
            int la = a.getLinhas();
            int ca = a.getColunas();
            int lb = b == null ? 0 : b.getLinhas();
            int cb = b == null ? 0 : b.getColunas();
            NetworkHooks.openScreen(sp, new SimpleMenuProvider(
                    (id, inv, p) -> new BauFuncionarioMenu(id, inv, a.getArmazem(), b == null ? null : b.getArmazem(), pos, la, ca, lb, cb),
                    estado.getBlock().getName()), buf -> {
                buf.writeBlockPos(pos);
                buf.writeVarInt(la);
                buf.writeVarInt(ca);
                buf.writeVarInt(lb);
                buf.writeVarInt(cb);
            });
        }
        return InteractionResult.CONSUME;
    }

    @Override
    public void setPlacedBy(Level nivel, BlockPos pos, BlockState estado, LivingEntity quem, ItemStack pilha) {
        super.setPlacedBy(nivel, pos, estado, quem, pilha);
        if (!nivel.isClientSide && quem instanceof Player jogador
                && nivel.getBlockEntity(pos) instanceof BauFuncionarioBE bau) {
            bau.setDono(jogador.getUUID());
        }
    }

    @Override
    public void onRemove(BlockState estado, Level nivel, BlockPos pos, BlockState novo, boolean movido) {
        if (!estado.is(novo.getBlock()) && nivel.getBlockEntity(pos) instanceof BauFuncionarioBE bau) {
            Containers.dropContents(nivel, pos, bau.getArmazem());
        }
        super.onRemove(estado, nivel, pos, novo, movido);
    }
}
