package com.funcionarios;

import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.world.Container;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;

/** Baú (1 ou 2 baús fundidos lado a lado) + inventário do jogador. */
public class BauFuncionarioMenu extends AbstractContainerMenu {
    public static final int TOPO = 20;

    private final BlockPos pos;
    private final int totalBau;
    private final int largura;
    private final int altura;
    private final int invY;

    /** Cliente: o conteúdo chega pela sincronização do menu. */
    public BauFuncionarioMenu(int id, Inventory inv, FriendlyByteBuf buf) {
        this(id, inv, null, null, buf.readBlockPos(), buf.readVarInt(), buf.readVarInt(), buf.readVarInt(), buf.readVarInt());
    }

    public BauFuncionarioMenu(int id, Inventory inv, Container a, Container b, BlockPos pos,
                              int la, int ca, int lb, int cb) {
        super(Registros.MENU_BAU.get(), id);
        this.pos = pos;
        if (a == null) a = new SimpleContainer(Math.max(1, la * ca));
        this.totalBau = la * ca + lb * cb;
        boolean duplo = lb > 0;
        int larguraBaus = 16 + ca * 18 + (duplo ? 6 + cb * 18 : 0);
        this.largura = Math.max(176, larguraBaus);
        int xBaus = (largura - larguraBaus) / 2 + 8;
        int maxLinhas = Math.max(la, lb);
        this.invY = TOPO + maxLinhas * 18 + 14;
        this.altura = invY + 58 + 26;
        for (int r = 0; r < la; r++) {
            for (int c = 0; c < ca; c++) {
                this.addSlot(new Slot(a, c + r * ca, xBaus + c * 18, TOPO + r * 18));
            }
        }
        if (duplo) {
            Container bb = b != null ? b : new SimpleContainer(lb * cb);
            int xb = xBaus + ca * 18 + 6;
            for (int r = 0; r < lb; r++) {
                for (int c = 0; c < cb; c++) {
                    this.addSlot(new Slot(bb, c + r * cb, xb + c * 18, TOPO + r * 18));
                }
            }
        }
        int ix = (largura - 176) / 2 + 8;
        for (int r = 0; r < 3; r++) {
            for (int c = 0; c < 9; c++) {
                this.addSlot(new Slot(inv, c + r * 9 + 9, ix + c * 18, invY + r * 18));
            }
        }
        for (int c = 0; c < 9; c++) {
            this.addSlot(new Slot(inv, c, ix + c * 18, invY + 58));
        }
    }

    public int getLargura() {
        return largura;
    }

    public int getAltura() {
        return altura;
    }

    public int getInvY() {
        return invY;
    }

    public int getInvX() {
        return (largura - 176) / 2 + 8;
    }

    @Override
    public boolean stillValid(Player jogador) {
        return jogador.distanceToSqr(pos.getX() + 0.5D, pos.getY() + 0.5D, pos.getZ() + 0.5D) <= 64.0D;
    }

    @Override
    public ItemStack quickMoveStack(Player jogador, int indice) {
        ItemStack copia = ItemStack.EMPTY;
        Slot slot = this.slots.get(indice);
        if (slot != null && slot.hasItem()) {
            ItemStack pilha = slot.getItem();
            copia = pilha.copy();
            if (indice < totalBau) {
                if (!this.moveItemStackTo(pilha, totalBau, this.slots.size(), true)) return ItemStack.EMPTY;
            } else if (!this.moveItemStackTo(pilha, 0, totalBau, false)) {
                return ItemStack.EMPTY;
            }
            if (pilha.isEmpty()) {
                slot.setByPlayer(ItemStack.EMPTY);
            } else {
                slot.setChanged();
            }
        }
        return copia;
    }
}
