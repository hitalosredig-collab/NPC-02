package com.funcionarios;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.inventory.Slot;

/** Tela do Baú do Funcionário: tamanho se ajusta ao nível do baú e a ele estar fundido ou não. */
public class BauFuncionarioScreen extends AbstractContainerScreen<BauFuncionarioMenu> {
    public BauFuncionarioScreen(BauFuncionarioMenu menu, Inventory inventario, Component titulo) {
        super(menu, inventario, titulo);
        this.imageWidth = menu.getLargura();
        this.imageHeight = menu.getAltura();
        this.titleLabelY = 6;
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float parcial) {
        this.renderBackground(g);
        super.render(g, mouseX, mouseY, parcial);
        this.renderTooltip(g, mouseX, mouseY);
    }

    @Override
    protected void renderLabels(GuiGraphics g, int mouseX, int mouseY) {
        g.drawString(this.font, this.title, 8, this.titleLabelY, 0x404040, false);
        g.drawString(this.font, this.playerInventoryTitle, this.menu.getInvX(), this.menu.getInvY() - 11, 0x404040, false);
    }

    @Override
    protected void renderBg(GuiGraphics g, float parcial, int mouseX, int mouseY) {
        g.fill(this.leftPos - 1, this.topPos - 1, this.leftPos + this.imageWidth + 1, this.topPos + this.imageHeight + 1, 0xFF000000);
        g.fill(this.leftPos, this.topPos, this.leftPos + this.imageWidth, this.topPos + this.imageHeight, 0xFFC6C6C6);
        for (Slot s : this.menu.slots) {
            int sx = this.leftPos + s.x;
            int sy = this.topPos + s.y;
            g.fill(sx - 1, sy - 1, sx + 17, sy + 17, 0xFF373737);
            g.fill(sx, sy, sx + 17, sy + 17, 0xFFFFFFFF);
            g.fill(sx, sy, sx + 16, sy + 16, 0xFF8B8B8B);
        }
    }
}
