package com.funcionarios;

import net.minecraftforge.common.ForgeConfigSpec;

/** Configuração do lado do cliente (arquivo config/funcionarios-client.toml). */
public final class Configuracao {
    public static final ForgeConfigSpec SPEC;
    public static final ForgeConfigSpec.BooleanValue VOZ_ATIVA;
    public static final ForgeConfigSpec.IntValue VOZ_DISTANCIA;

    static {
        ForgeConfigSpec.Builder b = new ForgeConfigSpec.Builder();
        VOZ_ATIVA = b.comment("Os funcionários falam em voz alta (usa a voz do sistema, por exemplo a do Windows).")
                .define("vozAtiva", true);
        VOZ_DISTANCIA = b.comment("Distância máxima, em blocos, para ouvir a voz do funcionário.")
                .defineInRange("vozDistancia", 20, 2, 64);
        SPEC = b.build();
    }

    private Configuracao() {}
}
