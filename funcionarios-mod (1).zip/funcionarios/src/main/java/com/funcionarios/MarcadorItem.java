package com.funcionarios;

import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;

/**
 * Marcador de local. Clique direito num bloco para marcar o lugar; depois clique direito num
 * funcionário com o Marcador para ele trabalhar ali. Shift + clique no funcionário solta a área.
 */
public class MarcadorItem extends Item {
    public MarcadorItem(Properties propriedades) {
        super(propriedades);
    }

    @Override
    public InteractionResult useOn(UseOnContext contexto) {
        Level nivel = contexto.getLevel();
        Player jogador = contexto.getPlayer();
        if (jogador == null) return InteractionResult.PASS;
        if (!nivel.isClientSide) {
            BlockPos pos = contexto.getClickedPos().relative(contexto.getClickedFace());
            contexto.getItemInHand().getOrCreateTag().putLong("Local", pos.asLong());
            jogador.displayClientMessage(Component.literal("Local marcado: " + pos.getX() + ", " + pos.getY()
                    + ", " + pos.getZ() + ". Agora clique num funcionário com o Marcador."), true);
        }
        return InteractionResult.sidedSuccess(nivel.isClientSide);
    }

    public static BlockPos ler(ItemStack pilha) {
        CompoundTag tag = pilha.getTag();
        if (tag == null || !tag.contains("Local")) return null;
        return BlockPos.of(tag.getLong("Local"));
    }

    @Override
    public boolean isFoil(ItemStack pilha) {
        return ler(pilha) != null;
    }
}
