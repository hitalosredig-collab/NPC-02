package com.funcionarios;

import java.util.EnumSet;
import java.util.HashSet;
import java.util.Set;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.Mth;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.level.block.EntityBlock;
import net.minecraft.tags.FluidTags;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.CropBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.pathfinder.Path;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.common.Tags;

/** A "IA" do funcionário: executa a tarefa escolhida (madeira, pedra, colher, seguir, entregar). */
public class TarefaGoal extends Goal {
    private final FuncionarioEntity f;
    private Tarefa ultima = Tarefa.PARAR;
    private BlockPos alvo;
    private final Set<BlockPos> falhas = new HashSet<>();
    private int progresso;
    private int tentativas;
    private int esperaBusca;
    private int tempoSemChegar;
    private int recalculos;
    private final DefesaLogica defesa;

    public TarefaGoal(FuncionarioEntity funcionario) {
        this.f = funcionario;
        this.defesa = new DefesaLogica(funcionario);
        this.setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
    }

    @Override
    public boolean canUse() {
        return f.getTarefa() != Tarefa.PARAR;
    }

    @Override
    public boolean canContinueToUse() {
        return f.getTarefa() != Tarefa.PARAR;
    }

    @Override
    public void stop() {
        f.getNavigation().stop();
        alvo = null;
        defesa.resetar();
        ultima = Tarefa.PARAR;
    }

    @Override
    public void tick() {
        Tarefa t = f.getTarefa();
        if (t != ultima) {
            ultima = t;
            alvo = null;
            falhas.clear();
            progresso = 0;
            tentativas = 0;
            esperaBusca = 0;
            tempoSemChegar = 0;
            recalculos = 0;
            defesa.resetar();
        }
        if (t.ehTrabalho() && defesa.revidarSeAtacado()) {
            return;
        }
        switch (t) {
            case SEGUIR -> seguir();
            case DEFENDER -> defesa.tick();
            case ENTREGAR -> entregar();
            case MADEIRA, PEDRA, CAVAR, COLHER -> trabalhar(t);
            default -> { }
        }
    }

    // ------------------------------------------------------------------ seguir / entregar

    private void irAte(Player dono, double velocidade) {
        if (f.getNavigation().isDone() || f.tickCount % 10 == 0) {
            f.getNavigation().moveTo(dono, velocidade);
        }
    }

    private void seguir() {
        Player dono = f.getDonoJogador();
        if (dono == null) return;
        double d2 = f.distanceToSqr(dono);
        if (d2 > 225.0D && f.teleportarParaDono(dono)) {
            return;
        }
        f.getLookControl().setLookAt(dono, 30.0F, 30.0F);
        if (d2 > 9.0D) {
            irAte(dono, 1.15D);
        } else {
            f.getNavigation().stop();
        }
    }

    private void entregar() {
        Player dono = f.getDonoJogador();
        if (dono == null) {
            f.falar(Falas.Situacao.LONGE);
            f.definirTarefa(Tarefa.PARAR);
            return;
        }
        double d2 = f.distanceToSqr(dono);
        if (d2 > 225.0D && f.teleportarParaDono(dono)) {
            return;
        }
        f.getLookControl().setLookAt(dono, 30.0F, 30.0F);
        if (d2 > 6.25D) {
            irAte(dono, 1.2D);
            return;
        }
        f.entregarItens(dono);
        f.falar(Falas.Situacao.ENTREGUEI);
        f.retomarOuParar();
    }

    // ------------------------------------------------------------------ trabalho

    private void trabalhar(Tarefa t) {
        Class<? extends Item> tipo = f.ferramentaPara(t);
        if (tipo != null && f.acharFerramenta(tipo).isEmpty()) {
            f.falar(Falas.Situacao.FERRAMENTA_QUEBROU);
            f.definirTarefa(Tarefa.PARAR);
            return;
        }
        if (tipo != null) {
            f.equipar(tipo);
        }

        if (alvo == null) {
            if (--esperaBusca > 0) return;
            alvo = buscar(t);
            if (alvo == null) {
                tentativas++;
                esperaBusca = 20;
                if (tentativas >= 3) {
                    if (t == Tarefa.PEDRA) {
                        f.falar(Falas.Situacao.CAVANDO);
                        f.definirTarefa(Tarefa.CAVAR);
                    } else {
                        f.falar(Falas.Situacao.NADA_ACHADO);
                        f.definirTarefa(Tarefa.PARAR);
                    }
                }
                return;
            }
            tentativas = 0;
            progresso = 0;
            tempoSemChegar = 0;
            recalculos = 0;
        }

        Level nivel = f.level();
        BlockState estado = nivel.getBlockState(alvo);
        if (!valido(t, estado, alvo)) {
            alvo = null;
            return;
        }

        Vec3 centro = Vec3.atCenterOf(alvo);
        f.getLookControl().setLookAt(centro.x, centro.y, centro.z);

        if (f.getEyePosition().distanceToSqr(centro) <= 16.0D) {
            f.getNavigation().stop();
            progresso++;
            if (progresso % 6 == 0) {
                f.swing(InteractionHand.MAIN_HAND);
            }
            if (progresso >= tempoParaQuebrar(t, estado, alvo)) {
                boolean cheio = f.quebrar(alvo, t);
                alvo = null;
                progresso = 0;
                if (cheio) {
                    f.falar(Falas.Situacao.INV_CHEIO);
                    f.definirTarefa(Tarefa.ENTREGAR);
                }
            }
        } else {
            progresso = 0;
            tempoSemChegar++;
            if (tempoSemChegar > 400) {
                falhas.add(alvo);
                alvo = null;
                return;
            }
            if (f.getNavigation().isDone()) {
                if (recalculos++ >= 3) {
                    falhas.add(alvo);
                    alvo = null;
                    return;
                }
                Path caminho = f.getNavigation().createPath(alvo, 1);
                if (caminho == null) {
                    falhas.add(alvo);
                    alvo = null;
                    return;
                }
                f.getNavigation().moveTo(caminho, 1.0D);
            }
        }
    }

    /** Ticks para quebrar o bloco, usando a velocidade real da ferramenta na mão (igual ao jogador). */
    private int tempoParaQuebrar(Tarefa t, BlockState estado, BlockPos pos) {
        if (t == Tarefa.COLHER) return 8;
        float dureza = estado.getDestroySpeed(f.level(), pos);
        if (dureza <= 0.0F) return 1;
        ItemStack ferramenta = f.getMainHandItem();
        float velocidade = ferramenta.isEmpty() ? 1.0F : ferramenta.getDestroySpeed(estado);
        if (velocidade > 1.0F) {
            int eficiencia = EnchantmentHelper.getBlockEfficiency(f);
            if (eficiencia > 0) velocidade += eficiencia * eficiencia + 1;
        }
        boolean ferramentaCerta = !estado.requiresCorrectToolForDrops() || ferramenta.isCorrectToolForDrops(estado);
        float danoPorTick = velocidade / dureza / (ferramentaCerta ? 30.0F : 100.0F);
        return Mth.clamp((int) Math.ceil(1.0F / danoPorTick), 1, 400);
    }

    /** Próximo bloco do túnel (2 de altura) a partir do ponto de trabalho, na direção escolhida. */
    private BlockPos buscarTunel() {
        Level nivel = f.level();
        BlockPos c = f.getCasa();
        Direction d = f.getDirTunel();
        for (int k = 1; k <= 40; k++) {
            for (int h = 0; h <= 1; h++) {
                BlockPos p = c.relative(d, k).above(h);
                if (falhas.contains(p)) return null;
                BlockState e = nivel.getBlockState(p);
                if (e.getCollisionShape(nivel, p).isEmpty() && e.getFluidState().isEmpty()) continue;
                return podeCavar(p, e) ? p.immutable() : null;
            }
        }
        return null;
    }

    /** Só cava bloco sólido, sem entidade de bloco (baú etc.) e sem água/lava encostada. */
    private boolean podeCavar(BlockPos pos, BlockState estado) {
        Level nivel = f.level();
        if (estado.isAir() || !estado.getFluidState().isEmpty()) return false;
        if (estado.getDestroySpeed(nivel, pos) < 0.0F || estado.getBlock() instanceof EntityBlock) return false;
        for (Direction d : Direction.values()) {
            if (!nivel.getBlockState(pos.relative(d)).getFluidState().isEmpty()) return false;
        }
        return true;
    }

    private BlockPos buscar(Tarefa t) {
        if (t == Tarefa.CAVAR) return buscarTunel();
        Level nivel = f.level();
        BlockPos c = f.getCasa();
        int r = FuncionarioEntity.RAIO;
        BlockPos melhor = null;
        double melhorDist = Double.MAX_VALUE;
        for (BlockPos p : BlockPos.betweenClosed(c.offset(-r, -r, -r), c.offset(r, r, r))) {
            if (falhas.contains(p)) continue;
            if (!nivel.hasChunkAt(p)) continue;
            BlockState estado = nivel.getBlockState(p);
            if (!valido(t, estado, p)) continue;
            double d = f.distanceToSqr(Vec3.atCenterOf(p));
            if (d < melhorDist) {
                melhorDist = d;
                melhor = p.immutable();
            }
        }
        return melhor;
    }

    private boolean valido(Tarefa t, BlockState estado, BlockPos pos) {
        return switch (t) {
            case MADEIRA -> estado.is(BlockTags.LOGS);
            case PEDRA -> ehPedra(estado) && exposto(pos);
            case COLHER -> estado.getBlock() instanceof CropBlock c && c.isMaxAge(estado);
            case CAVAR -> podeCavar(pos, estado);
            default -> false;
        };
    }

    private boolean ehPedra(BlockState estado) {
        return estado.is(BlockTags.BASE_STONE_OVERWORLD)
                || estado.is(Tags.Blocks.ORES)
                || estado.is(Tags.Blocks.COBBLESTONE);
    }

    /** O bloco precisa ter pelo menos uma face livre e nenhuma lava encostada. */
    private boolean exposto(BlockPos pos) {
        Level nivel = f.level();
        boolean livre = false;
        for (Direction d : Direction.values()) {
            BlockPos vizinho = pos.relative(d);
            BlockState e = nivel.getBlockState(vizinho);
            if (!e.getFluidState().isEmpty()) return false;
            if (e.getCollisionShape(nivel, vizinho).isEmpty()) livre = true;
        }
        return livre;
    }
}
