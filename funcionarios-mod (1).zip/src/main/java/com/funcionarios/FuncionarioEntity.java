package com.funcionarios;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.level.TicketType;
import net.minecraft.world.level.ChunkPos;
import java.util.ArrayList;
import java.util.Comparator;
import net.minecraft.world.Containers;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.OpenDoorGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.navigation.GroundPathNavigation;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.AxeItem;
import net.minecraft.world.item.DiggerItem;
import net.minecraft.world.item.HoeItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.PickaxeItem;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.CropBlock;
import net.minecraft.world.level.block.entity.BarrelBlockEntity;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.ChestBlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.items.ItemHandlerHelper;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.level.pathfinder.BlockPathTypes;
import net.minecraft.world.level.pathfinder.WalkNodeEvaluator;
import net.minecraft.world.phys.AABB;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.common.capabilities.ForgeCapabilities;
import net.minecraftforge.common.util.LazyOptional;
import net.minecraftforge.items.IItemHandler;
import net.minecraftforge.items.wrapper.InvWrapper;
import net.minecraftforge.network.NetworkHooks;
import net.minecraftforge.network.PacketDistributor;

import java.util.List;
import java.util.UUID;
import java.util.function.Predicate;

/** O funcionário: um NPC humanoide com inventário, equipamento, dono e tarefas. */
public class FuncionarioEntity extends PathfinderMob {
    private static final EntityDataAccessor<String> FALA =
            SynchedEntityData.defineId(FuncionarioEntity.class, EntityDataSerializers.STRING);
    private static final EntityDataAccessor<Integer> TAREFA =
            SynchedEntityData.defineId(FuncionarioEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> SKIN =
            SynchedEntityData.defineId(FuncionarioEntity.class, EntityDataSerializers.INT);

    private static final String[] NOMES = {"Zé", "Tião", "Beto", "Nando", "Dedé", "Marcão", "Chico", "Juca", "Toninho", "Valdir", "Zeca", "Lauro", "Osmar", "Nilson", "Edu", "Gil", "Rui", "Tonho", "Davi", "Léo", "Bruno", "Caio", "Hugo", "Otávio", "Raul", "Xande"};
    private static final String[] NOMES_F = {"Cida", "Lúcia", "Rita", "Neide", "Bia", "Fátima", "Tânia", "Dora", "Marlene", "Joana", "Sílvia", "Lia", "Vera", "Nair", "Cléo", "Iara", "Mara", "Luana", "Duda", "Nanda", "Paula", "Rosa", "Tereza", "Gabi"};
    private static final java.util.Set<String> NOMES_FEMININOS = java.util.Set.of(NOMES_F);
    private static final java.util.Set<String> NOMES_MASCULINOS = java.util.Set.of(NOMES);

    /** Raio (em blocos) ao redor do ponto onde o funcionário recebeu a ordem. */
    public static final int RAIO = 16;

    private static final EntityDataAccessor<Integer> NIVEL =
            SynchedEntityData.defineId(FuncionarioEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> MINERIO =
            SynchedEntityData.defineId(FuncionarioEntity.class, EntityDataSerializers.INT);

    private final SimpleContainer inventario = new SimpleContainer(27);
    /** 0-1 armas, 2 picareta, 3 machado, 4 pá, 5 enxada. */
    /** 0-1 armas, 2 picareta, 3 machado, 4 pá, 5 enxada, 6 mochila (qualquer item com inventário, ex.: Sophisticated Backpacks). */
    private final SimpleContainer ferramentas = new SimpleContainer(7);
    private ItemStack origemMao = ItemStack.EMPTY;
    private final LazyOptional<IItemHandler> manipulador = LazyOptional.of(() -> new InvWrapper(inventario));
    private UUID dono;
    private BlockPos casa = BlockPos.ZERO;
    private int personalidade;
    private Tarefa tarefaAnterior = Tarefa.PARAR;
    private boolean areaFixa;
    private Direction dirTunel = Direction.NORTH;
    private long ultimoTp = -1000;

    public FuncionarioEntity(EntityType<? extends PathfinderMob> tipo, Level nivel) {
        super(tipo, nivel);
        this.setPersistenceRequired();
        // não entra na água sozinho (evita ir minerar embaixo d'água)
        this.setPathfindingMalus(BlockPathTypes.WATER, -1.0F);
        this.setPathfindingMalus(BlockPathTypes.WATER_BORDER, 8.0F);
        this.setDropChance(EquipmentSlot.MAINHAND, 0.0F); // a mão só repete o item do slot
        // tudo que o jogador colocar nos slots de equipamento cai inteiro quando ele morre
        for (EquipmentSlot slot : EquipamentoContainer.SLOTS) {
            this.setDropChance(slot, 2.0F);
        }
        if (this.getNavigation() instanceof GroundPathNavigation nav) {
            nav.setCanOpenDoors(true);
            nav.setCanFloat(true);
        }
    }

    public static AttributeSupplier.Builder criarAtributos() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 40.0D)
                .add(Attributes.ARMOR, 2.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.3D)
                .add(Attributes.FOLLOW_RANGE, 48.0D)
                .add(Attributes.ATTACK_DAMAGE, 1.0D);
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(FALA, "");
        this.entityData.define(TAREFA, 0);
        this.entityData.define(SKIN, 0);
        this.entityData.define(MINERIO, 0);
        this.entityData.define(NIVEL, 0);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new OpenDoorGoal(this, true));
        this.goalSelector.addGoal(2, new TarefaGoal(this));
        this.goalSelector.addGoal(5, new LookAtPlayerGoal(this, Player.class, 6.0F));
        this.goalSelector.addGoal(6, new RandomLookAroundGoal(this));
    }

    // ------------------------------------------------------------------ capacidades (outros mods enxergam o inventário)

    @Override
    public <T> LazyOptional<T> getCapability(Capability<T> capacidade, Direction lado) {
        if (capacidade == ForgeCapabilities.ITEM_HANDLER) {
            return manipulador.cast();
        }
        return super.getCapability(capacidade, lado);
    }

    @Override
    public void invalidateCaps() {
        super.invalidateCaps();
        manipulador.invalidate();
    }

    // ------------------------------------------------------------------ dono / contratação

    public void contratar(Player jogador) {
        this.dono = jogador.getUUID();
        boolean mulher = this.getRandom().nextBoolean();
        this.entityData.set(SKIN, (mulher ? 6 : 0) + this.getRandom().nextInt(6));
        this.personalidade = this.getRandom().nextInt(3);
        String[] lista = mulher ? NOMES_F : NOMES;
        this.setCustomName(Component.literal(lista[this.getRandom().nextInt(lista.length)]));
        this.setCustomNameVisible(true);
        this.casa = this.blockPosition();
        falar(Falas.Situacao.CONTRATADO);
    }

    public boolean ehDono(Player jogador) {
        return dono != null && dono.equals(jogador.getUUID());
    }

    public Player getDonoJogador() {
        return dono == null ? null : this.level().getPlayerByUUID(dono);
    }

    @Override
    public InteractionResult mobInteract(Player jogador, InteractionHand mao) {
        if (this.level().isClientSide) {
            return InteractionResult.SUCCESS;
        }
        if (dono == null) {
            dono = jogador.getUUID();
        }
        if (!ehDono(jogador)) {
            falar(Falas.Situacao.NAO_E_PATRAO);
            return InteractionResult.CONSUME;
        }
        ItemStack naMao = jogador.getItemInHand(mao);
        if (naMao.getItem() instanceof MelhoriaItem melhoria) {
            int n = getNivel();
            if (n >= NIVEL_MAX) {
                jogador.displayClientMessage(Component.literal(getName().getString() + " já está no nível máximo (" + NIVEL_MAX + ")."), true);
            } else if (melhoria.getNivel() != n + 1) {
                jogador.displayClientMessage(Component.literal(getName().getString() + " está no nível " + n
                        + ": precisa do item de melhoria nível " + (n + 1) + "."), true);
            } else {
                this.entityData.set(NIVEL, n + 1);
                aplicarNivel();
                this.setHealth(this.getMaxHealth());
                if (!jogador.getAbilities().instabuild) naMao.shrink(1);
                if (this.level() instanceof ServerLevel sl) {
                    sl.sendParticles(net.minecraft.core.particles.ParticleTypes.HAPPY_VILLAGER,
                            getX(), getY() + 1.0D, getZ(), 20, 0.4D, 0.6D, 0.4D, 0.1D);
                    sl.playSound(null, blockPosition(), net.minecraft.sounds.SoundEvents.PLAYER_LEVELUP,
                            net.minecraft.sounds.SoundSource.NEUTRAL, 0.8F, 1.0F);
                }
                jogador.displayClientMessage(Component.literal(getName().getString() + " subiu para o nível " + (n + 1) + "!"), true);
            }
            return InteractionResult.CONSUME;
        }
        if (jogador instanceof ServerPlayer sp) {
            NetworkHooks.openScreen(sp,
                    new SimpleMenuProvider((id, inv, p) -> new FuncionarioMenu(id, inv, this), this.getDisplayName()),
                    buf -> buf.writeInt(this.getId()));
        }
        return InteractionResult.CONSUME;
    }

    // ------------------------------------------------------------------ fala

    public void falar(Falas.Situacao situacao) {
        String texto = Falas.get(situacao, personalidade, this.getRandom());
        this.entityData.set(FALA, texto);
        if (!this.level().isClientSide) {
            Player d = getDonoJogador();
            if (d != null && this.distanceToSqr(d) < 1024.0D) {
                d.displayClientMessage(Component.literal(this.getName().getString() + ": " + texto), true);
                if (d instanceof ServerPlayer sp) {
                    Rede.CANAL.send(PacketDistributor.PLAYER.with(() -> sp), new PacoteFala(this.getId(), texto, ehMulher() ? 1 : (Math.floorMod(getSkin(), 3) == 2 ? 2 : 0), personalidade));
                }
            }
        }
    }

    /** Mulher se o nome é feminino (a voz acompanha o nome). */
    public boolean ehMulher() {
        return this.getCustomName() != null && NOMES_FEMININOS.contains(this.getCustomName().getString());
    }

    public String getFala() {
        return this.entityData.get(FALA);
    }

    // ------------------------------------------------------------------ tarefas

    public Tarefa getTarefa() {
        return Tarefa.de(this.entityData.get(TAREFA));
    }

    public Tarefa getTarefaAnterior() {
        return tarefaAnterior;
    }

    public void definirTarefa(Tarefa tarefa) {
        if (tarefa.ehTrabalho()) {
            tarefaAnterior = tarefa;
        } else if (tarefa == Tarefa.PARAR || tarefa == Tarefa.SEGUIR || tarefa == Tarefa.DEFENDER) {
            tarefaAnterior = Tarefa.PARAR;
        }
        this.entityData.set(TAREFA, tarefa.ordinal());
        this.getNavigation().stop();
    }

    /** Chamado quando o jogador clica num botão da tela (já validado no servidor). */
    public void receberComando(Tarefa tarefa, Player jogador) {
        switch (tarefa) {
            case PARAR -> {
                definirTarefa(Tarefa.PARAR);
                falar(Falas.Situacao.PARADO);
            }
            case SEGUIR -> {
                definirTarefa(Tarefa.SEGUIR);
                falar(Falas.Situacao.SEGUINDO);
            }
            case DEFENDER -> {
                if (!temArmaParaDefender()) {
                    falar(Falas.Situacao.SEM_ARMA);
                    return;
                }
                definirTarefa(Tarefa.DEFENDER);
                falar(Falas.Situacao.DEFENDENDO);
            }
            case ENTREGAR -> {
                this.bauAlvo = null;
                definirTarefa(Tarefa.ENTREGAR);
                falar(Falas.Situacao.ACEITO);
            }
            case GUARDAR -> {
                if (depositarRemoto()) {
                    falar(Falas.Situacao.ENTREGUEI);
                    return;
                }
                BlockPos bau = acharBau();
                if (bau == null) {
                    jogador.displayClientMessage(Component.literal(
                            bauDeles() ? "Os baús estão cheios." : "Nenhum baú por perto (use o Baú do Funcionário)."), true);
                    return;
                }
                setLocalTrabalho(this.blockPosition());
                setBauAlvo(bau);
                definirTarefa(Tarefa.ENTREGAR);
                falar(Falas.Situacao.ACEITO);
            }
            case MELHORAR -> {
                if (true) {
                    jogador.displayClientMessage(Component.literal("Use um item de melhoria (clique direito no funcionário)."), true);
                    return;
                }
                int n = getNivel();
                if (n >= NIVEL_MAX) {
                    jogador.displayClientMessage(Component.literal("Já está no nível máximo (" + NIVEL_MAX + ")."), true);
                    return;
                }
                List<ItemStack> custo = custoMelhoria(n);
                if (!jogador.isCreative()) {
                    for (ItemStack c : custo) {
                        if (jogador.getInventory().countItem(c.getItem()) < c.getCount()) {
                            jogador.displayClientMessage(Component.literal("Faltam materiais: " + descreverCusto(custo)), true);
                            return;
                        }
                    }
                    for (ItemStack c : custo) {
                        jogador.getInventory().clearOrCountMatchingItems(s -> s.is(c.getItem()), c.getCount(),
                                jogador.inventoryMenu.getCraftSlots());
                    }
                }
                this.entityData.set(NIVEL, n + 1);
                aplicarNivel();
                this.setHealth(this.getMaxHealth());
                jogador.displayClientMessage(Component.literal("Melhorado para o nível " + (n + 1)
                        + "! Mais rápido, mais forte e mais resistente."), true);
            }
            case TROCAR_MINERIO -> {
                Minerio novo = getMinerio().proximo();
                setMascaraMinerio(1 << novo.ordinal());
                jogador.displayClientMessage(Component.literal("Minério escolhido: " + rotuloMinerios()), true);
            }
            default -> {
                Class<? extends Item> ferramenta = ferramentaPara(tarefa);
                if (ferramenta != null && acharFerramenta(ferramenta).isEmpty()) {
                    falar(tarefa == Tarefa.MADEIRA ? Falas.Situacao.SEM_MACHADO : Falas.Situacao.SEM_PICARETA);
                    return;
                }
                if (inventarioCheio() && !depositarRemoto()) {
                    falar(Falas.Situacao.INV_CHEIO);
                    return;
                }
                this.bauBase = this.blockPosition();
                this.bauAlvo = null;
                if (!areaFixa) this.casa = this.blockPosition();
                this.dirTunel = jogador.getDirection();
                equipar(ferramenta != null ? ferramenta : HoeItem.class);
                definirTarefa(tarefa);
                falar(Falas.Situacao.ACEITO);
            }
        }
    }

    /** Depois de entregar os itens, volta ao trabalho anterior (se tiver) ou para. */
    private BlockPos localTrabalho;

    /** Onde ele estava trabalhando quando encheu o inventário (para voltar direto depois de entregar). */
    public void setLocalTrabalho(BlockPos pos) {
        this.localTrabalho = pos.immutable();
    }

    public void retomarOuParar() {
        if (localTrabalho != null && tarefaAnterior.ehTrabalho()
                && this.blockPosition().distSqr(localTrabalho) > 100.0D) {
            teleportarParaSeguro(localTrabalho);
        }
        // se ficou muito longe do ponto de trabalho, passa a trabalhar perto de onde está agora
        if (this.blockPosition().distSqr(casa) > 900.0D) {
            casa = this.blockPosition();
        }
        Tarefa anterior = tarefaAnterior;
        if (anterior.ehTrabalho()) {
            Class<? extends Item> tipo = ferramentaPara(anterior);
            if (tipo == null || !acharFerramenta(tipo).isEmpty()) {
                equipar(tipo != null ? tipo : HoeItem.class);
                definirTarefa(anterior);
                return;
            }
        }
        definirTarefa(Tarefa.PARAR);
    }

    public Class<? extends Item> ferramentaPara(Tarefa tarefa) {
        if (tarefa == Tarefa.MADEIRA) return AxeItem.class;
        if (tarefa == Tarefa.PEDRA || tarefa == Tarefa.MINERIO) return PickaxeItem.class;
        return null;
    }

    // ------------------------------------------------------------------ inventário e equipamento

    public void setCasa(BlockPos pos) {
        this.casa = pos;
    }

    /**
     * Em túnel apertado o jogo põe a entidade na pose "nadando/engatinhando" (corpo deitado). Para ele fica sempre de pé
     * visualmente; a caixa de colisão continua se ajustando ao espaço.
     */
    @Override
    public boolean isVisuallySwimming() {
        return false;
    }

    @Override
    public boolean isCrouching() {
        return false;
    }

    public SimpleContainer getFerramentas() {
        return ferramentas;
    }

    public SimpleContainer getInventario() {
        return inventario;
    }

    public boolean inventarioCheio() {
        for (int i = 0; i < inventario.getContainerSize(); i++) {
            if (inventario.getItem(i).isEmpty()) return false;
        }
        IItemHandler m = mochila();
        if (m != null) {
            for (int i = 0; i < m.getSlots(); i++) {
                if (m.getStackInSlot(i).isEmpty()) return false;
            }
        }
        return true;
    }

    /** Inventário do item no slot de mochila (qualquer mod que exponha IItemHandler no item), ou null. */
    public IItemHandler mochila() {
        ItemStack s = ferramentas.getItem(6);
        if (s.isEmpty()) return null;
        return s.getCapability(ForgeCapabilities.ITEM_HANDLER).orElse(null);
    }

    /** Guarda o item: primeiro na mochila (se tiver), depois no inventário. Devolve o que não coube. */
    public ItemStack guardarItem(ItemStack s) {
        IItemHandler m = mochila();
        if (m != null) s = ItemHandlerHelper.insertItem(m, s, false);
        if (s.isEmpty()) return ItemStack.EMPTY;
        return inventario.addItem(s);
    }

    private static boolean ehFerramentaOuArma(ItemStack s) {
        return s.getItem() instanceof DiggerItem || s.getItem() instanceof SwordItem || ehFoice(s) || CompatArmas.ehArma(s);
    }

    /** Baús do Funcionário do dono em ordem de colocação (o primeiro colocado vem primeiro); um por par fundido. */
    public List<BauFuncionarioBE> bausEmOrdem() {
        List<BauFuncionarioBE> lista = new ArrayList<>();
        if (this.level().isClientSide) return lista;
        for (BauFuncionarioBE b : BauFuncionarioBE.TODOS) {
            if (b.isRemoved() || b.getLevel() != this.level()) continue;
            if (b.getDono() != null && !b.getDono().equals(dono)) continue;
            if (b.getBlockPos().distSqr(this.blockPosition()) > 512.0D * 512.0D) continue;
            lista.add(b);
        }
        lista.sort(Comparator.comparingLong(BauFuncionarioBE::getOrdem).thenComparingLong(b -> b.getBlockPos().asLong()));
        List<BauFuncionarioBE> unicos = new ArrayList<>();
        java.util.Set<BauFuncionarioBE> vistos = new java.util.HashSet<>();
        for (BauFuncionarioBE b : lista) {
            if (!vistos.add(b)) continue;
            BauFuncionarioBE p = b.parceiro();
            if (p != null) vistos.add(p);
            unicos.add(b);
        }
        return unicos;
    }

    private static ItemStack enviarAosBaus(List<BauFuncionarioBE> baus, ItemStack s) {
        for (BauFuncionarioBE b : baus) {
            IItemHandler h = b.getCapability(ForgeCapabilities.ITEM_HANDLER).orElse(null);
            if (h == null) continue;
            s = ItemHandlerHelper.insertItem(h, s, false);
            if (s.isEmpty()) break;
        }
        return s;
    }

    /**
     * Guarda tudo (inventário e mochila) nos Baús do Funcionário, em ordem, SEM precisar ir até lá.
     * Devolve true se sobrou espaço (não está mais cheio).
     */
    public boolean depositarRemoto() {
        if (this.level().isClientSide) return false;
        List<BauFuncionarioBE> baus = bausEmOrdem();
        if (baus.isEmpty()) return false;
        boolean mexeu = false;
        BlockPos ultimo = null;
        for (int i = 0; i < inventario.getContainerSize(); i++) {
            ItemStack s = inventario.getItem(i);
            if (s.isEmpty() || ehFerramentaOuArma(s)) continue;
            ItemStack resto = enviarAosBaus(baus, s.copy());
            if (resto.getCount() != s.getCount()) mexeu = true;
            inventario.setItem(i, resto);
        }
        IItemHandler m = mochila();
        if (m != null) {
            for (int i = 0; i < m.getSlots(); i++) {
                ItemStack s = m.getStackInSlot(i);
                if (s.isEmpty()) continue;
                int antes = s.getCount();
                ItemStack resto = enviarAosBaus(baus, s.copy());
                int enviados = antes - resto.getCount();
                if (enviados > 0) {
                    m.extractItem(i, enviados, false);
                    mexeu = true;
                }
            }
        }
        inventario.setChanged();
        if (mexeu && this.level() instanceof ServerLevel nivel) {
            BlockPos p = baus.get(0).getBlockPos();
            nivel.sendParticles(net.minecraft.core.particles.ParticleTypes.HAPPY_VILLAGER,
                    p.getX() + 0.5D, p.getY() + 1.1D, p.getZ() + 0.5D, 6, 0.3D, 0.2D, 0.3D, 0.02D);
            nivel.sendParticles(net.minecraft.core.particles.ParticleTypes.HAPPY_VILLAGER,
                    this.getX(), this.getY() + 1.2D, this.getZ(), 4, 0.3D, 0.3D, 0.3D, 0.02D);
            nivel.playSound(null, p, net.minecraft.sounds.SoundEvents.ITEM_PICKUP,
                    net.minecraft.sounds.SoundSource.BLOCKS, 0.5F, 1.0F);
        }
        return !inventarioCheio();
    }

    /** Procura nos slots de arma/ferramenta e depois no inventário. Devolve o próprio item (não uma cópia). */
    public ItemStack acharItem(Predicate<ItemStack> serve) {
        for (int i = 0; i < ferramentas.getContainerSize(); i++) {
            ItemStack s = ferramentas.getItem(i);
            if (!s.isEmpty() && serve.test(s)) return s;
        }
        for (int i = 0; i < inventario.getContainerSize(); i++) {
            ItemStack s = inventario.getItem(i);
            if (!s.isEmpty() && serve.test(s)) return s;
        }
        return ItemStack.EMPTY;
    }

    /** Foice (de mods: nome com scythe/sickle/foice) conta como enxada. */
    public static boolean ehFoice(ItemStack s) {
        net.minecraft.resources.ResourceLocation id = net.minecraftforge.registries.ForgeRegistries.ITEMS.getKey(s.getItem());
        if (id == null) return false;
        String p = id.getPath();
        return p.contains("scythe") || p.contains("sickle") || p.contains("foice");
    }

    public static boolean ehEnxada(ItemStack s) {
        return s.getItem() instanceof HoeItem || s.canPerformAction(net.minecraftforge.common.ToolActions.HOE_DIG) || ehFoice(s);
    }

    public ItemStack acharFerramenta(Class<? extends Item> tipo) {
        if (tipo == HoeItem.class) return acharItem(FuncionarioEntity::ehEnxada);
        return acharItem(s -> tipo.isInstance(s.getItem()));
    }

    private boolean contem(ItemStack pilha) {
        for (int i = 0; i < ferramentas.getContainerSize(); i++) {
            if (ferramentas.getItem(i) == pilha) return true;
        }
        for (int i = 0; i < inventario.getContainerSize(); i++) {
            if (inventario.getItem(i) == pilha) return true;
        }
        return false;
    }

    /**
     * Põe na mão principal o MESMO item que está no slot (não uma cópia): desgaste e munição ficam sempre em dia.
     * Se não achar nada que sirva, a mão fica como está.
     */
    public boolean equipar(Predicate<ItemStack> serve) {
        if (!origemMao.isEmpty() && !contem(origemMao)) {
            origemMao = ItemStack.EMPTY;
            this.setItemSlot(EquipmentSlot.MAINHAND, ItemStack.EMPTY);
        }
        if (!origemMao.isEmpty() && serve.test(origemMao)) return true;
        ItemStack achado = acharItem(serve);
        if (achado.isEmpty()) return false;
        origemMao = achado;
        this.setItemSlot(EquipmentSlot.MAINHAND, achado);
        return true;
    }

    public boolean equipar(Class<? extends Item> tipo) {
        if (tipo == HoeItem.class) return equipar(FuncionarioEntity::ehEnxada);
        return equipar(s -> tipo.isInstance(s.getItem()));
    }

    public boolean temArmaDeFogo() {
        return CompatArmas.disponivel() && !acharItem(CompatArmas::ehArma).isEmpty();
    }

    public boolean temArmaParaDefender() {
        return temArmaDeFogo()
                || !acharItem(s -> s.getItem() instanceof SwordItem).isEmpty()
                || !acharItem(s -> s.getItem() instanceof AxeItem).isEmpty();
    }

    /** Entrega tudo (menos ferramentas e armas) para o jogador. O que estiver na mão e na armadura fica. */
    public void entregarItens(Player jogador) {
        for (int i = 0; i < inventario.getContainerSize(); i++) {
            ItemStack s = inventario.getItem(i);
            if (s.isEmpty() || s.getItem() instanceof DiggerItem || s.getItem() instanceof SwordItem || ehFoice(s)
                    || CompatArmas.ehArma(s)) continue;
            ItemStack copia = s.copy();
            inventario.setItem(i, ItemStack.EMPTY);
            jogador.getInventory().add(copia);
            if (!copia.isEmpty()) {
                jogador.drop(copia, false);
            }
        }
        IItemHandler m = mochila();
        if (m != null) {
            for (int i = 0; i < m.getSlots(); i++) {
                ItemStack s = m.getStackInSlot(i);
                if (s.isEmpty()) continue;
                ItemStack tirado = m.extractItem(i, s.getCount(), false);
                if (tirado.isEmpty()) continue;
                jogador.getInventory().add(tirado);
                if (!tirado.isEmpty()) jogador.drop(tirado, false);
            }
        }
        inventario.setChanged();
    }

    // ------------------------------------------------------------------ baú (trabalho sem precisar do jogador)

    private BlockPos bauBase;
    private BlockPos bauAlvo;

    public BlockPos getBauAlvo() {
        return bauAlvo;
    }

    public void setBauAlvo(BlockPos pos) {
        this.bauAlvo = pos == null ? null : pos.immutable();
    }

    /** Baú ou barril num raio de 12 blocos de onde ele começou a trabalhar (o mais perto do ponto inicial). */
    public BlockPos acharBau() {
        BauFuncionarioBE dele = acharBauDele();
        if (dele != null) return dele.getBlockPos();
        BlockPos c = bauBase != null ? bauBase : casa;
        Level nivel = this.level();
        BlockPos melhor = null;
        double melhorD = Double.MAX_VALUE;
        for (BlockPos p : BlockPos.betweenClosed(c.offset(-12, -6, -12), c.offset(12, 6, 12))) {
            if (!nivel.hasChunkAt(p)) continue;
            BlockEntity be = nivel.getBlockEntity(p);
            if (!(be instanceof ChestBlockEntity) && !(be instanceof BarrelBlockEntity)) continue;
            double d = p.distSqr(c);
            if (d < melhorD) {
                melhorD = d;
                melhor = p.immutable();
            }
        }
        return melhor;
    }

    /** Guarda tudo (menos ferramentas e armas) no baú. Devolve true se sobrou algo (baú cheio ou sumiu). */
    public boolean depositarNoBau(BlockPos pos) {
        BlockEntity be = this.level().getBlockEntity(pos);
        if (be == null) return true;
        IItemHandler h = be.getCapability(ForgeCapabilities.ITEM_HANDLER).orElse(null);
        if (h == null) return true;
        boolean sobrou = false;
        for (int i = 0; i < inventario.getContainerSize(); i++) {
            ItemStack s = inventario.getItem(i);
            if (s.isEmpty() || s.getItem() instanceof DiggerItem || s.getItem() instanceof SwordItem || ehFoice(s)
                    || CompatArmas.ehArma(s)) continue;
            ItemStack resto = ItemHandlerHelper.insertItem(h, s.copy(), false);
            inventario.setItem(i, resto);
            if (!resto.isEmpty()) sobrou = true;
        }
        inventario.setChanged();
        return sobrou;
    }

    private boolean bauDeles() {
        return !bausEmOrdem().isEmpty();
    }

    /** Primeiro Baú do Funcionário (por ordem de colocação) que ainda tem espaço; se todos cheios, o primeiro. */
    public BauFuncionarioBE acharBauDele() {
        List<BauFuncionarioBE> baus = bausEmOrdem();
        for (BauFuncionarioBE b : baus) {
            if (b.temEspaco()) return b;
        }
        return baus.isEmpty() ? null : baus.get(0);
    }


    // ------------------------------------------------------------------ trabalho

    public BlockPos getCasa() {
        return casa;
    }

    /**
     * Quebra/colhe o bloco, guarda os drops no inventário e gasta a ferramenta.
     * Retorna true se o inventário ficou sem espaço.
     */
    public boolean quebrar(BlockPos pos, Tarefa tarefa) {
        if (!(this.level() instanceof ServerLevel nivel)) return false;
        BlockState estado = nivel.getBlockState(pos);
        Class<? extends Item> tipo = ferramentaPara(tarefa);
        ItemStack ferramenta = acharFerramenta(tipo != null ? tipo : HoeItem.class);

        List<ItemStack> drops = Block.getDrops(estado, nivel, pos, nivel.getBlockEntity(pos), this, ferramenta);
        boolean cheio = false;
        for (ItemStack drop : drops) {
            ItemStack resto = guardarItem(drop);
            if (!resto.isEmpty()) {
                Block.popResource(nivel, pos, resto);
                cheio = true;
            }
        }

        if (estado.getBlock() instanceof CropBlock plantacao) {
            nivel.levelEvent(2001, pos, Block.getId(estado));
            nivel.setBlock(pos, plantacao.getStateForAge(0), 3); // replanta
        } else {
            nivel.destroyBlock(pos, false, this);
        }

        if (tarefa != Tarefa.COLHER && !ferramenta.isEmpty()) {
            ferramenta.hurtAndBreak(1, this, e -> e.broadcastBreakEvent(EquipmentSlot.MAINHAND));
            inventario.setChanged();
        }
        return cheio || inventarioCheio();
    }

    // ------------------------------------------------------------------ dados

    /** Usado pela Central: manda o funcionário voltar para perto do dono e segui-lo. */
    public void chamarDeVolta(Player dono) {
        definirTarefa(Tarefa.SEGUIR);
        ultimoTp = -1000;
        teleportarParaDono(dono);
        falar(Falas.Situacao.SEGUINDO);
    }

    public static final int NIVEL_MAX = 5;
    private static final java.util.UUID MOD_VEL = java.util.UUID.fromString("5a6f1c1e-3b0a-4c61-9d11-0f0e5a1b0001");
    private static final java.util.UUID MOD_VIDA = java.util.UUID.fromString("5a6f1c1e-3b0a-4c61-9d11-0f0e5a1b0002");
    private static final java.util.UUID MOD_DANO = java.util.UUID.fromString("5a6f1c1e-3b0a-4c61-9d11-0f0e5a1b0003");

    /** Nível de melhoria: 0 a 5 (5 = máximo). Cada nível: quebra mais rápido, anda mais rápido, mais vida e dano. */
    public int getNivel() {
        return this.entityData.get(NIVEL);
    }

    /** Buffs do nível: velocidade de andar +7%, vida +4 e dano +1 por nível. */
    public void aplicarNivel() {
        int n = Math.max(0, Math.min(NIVEL_MAX, getNivel()));
        trocarModificador(Attributes.MOVEMENT_SPEED, MOD_VEL, n * 0.07D, AttributeModifier.Operation.MULTIPLY_BASE);
        trocarModificador(Attributes.MAX_HEALTH, MOD_VIDA, n * 4.0D, AttributeModifier.Operation.ADDITION);
        trocarModificador(Attributes.ATTACK_DAMAGE, MOD_DANO, n * 1.0D, AttributeModifier.Operation.ADDITION);
    }

    private void trocarModificador(net.minecraft.world.entity.ai.attributes.Attribute atr, java.util.UUID id, double valor,
                                   AttributeModifier.Operation op) {
        AttributeInstance inst = this.getAttribute(atr);
        if (inst == null) return;
        inst.removeModifier(id);
        if (valor > 0) inst.addPermanentModifier(new AttributeModifier(id, "nivel", valor, op));
    }

    /** Todas as melhorias quebram mais rápido. */
    public float getMultiplicadorVelocidade() {
        return new float[] {1.0F, 1.4F, 1.9F, 2.6F, 3.5F, 5.0F}[Math.max(0, Math.min(NIVEL_MAX, getNivel()))];
    }

    /** Material pedido para sair do nível atual para o próximo. */
    public static List<ItemStack> custoMelhoria(int nivelAtual) {
        return switch (nivelAtual) {
            case 0 -> List.of(new ItemStack(Items.IRON_INGOT, 12), new ItemStack(Items.GOLD_INGOT, 4));
            case 1 -> List.of(new ItemStack(Items.GOLD_INGOT, 8), new ItemStack(Items.DIAMOND, 4));
            case 2 -> List.of(new ItemStack(Items.DIAMOND, 8), new ItemStack(Items.EMERALD, 8));
            case 3 -> List.of(new ItemStack(Items.DIAMOND, 16), new ItemStack(Items.EMERALD, 16));
            default -> List.of(new ItemStack(Items.NETHERITE_INGOT, 2), new ItemStack(Items.DIAMOND, 32));
        };
    }

    public static String descreverCusto(List<ItemStack> custo) {
        StringBuilder sb = new StringBuilder();
        for (ItemStack c : custo) {
            if (sb.length() > 0) sb.append(" + ");
            sb.append(c.getCount()).append("x ").append(c.getHoverName().getString());
        }
        return sb.toString();
    }

    /** Os minérios escolhidos ficam numa máscara de bits (bit = posição no enum Minerio). 0 = Qualquer. */
    public int getMascaraMinerio() {
        int v = this.entityData.get(MINERIO);
        return v <= 0 ? 1 : v;
    }

    public void setMascaraMinerio(int mascara) {
        int todos = (1 << Minerio.values().length) - 1;
        int m = mascara & todos;
        if ((m & 1) != 0 || m == 0) m = 1; // Qualquer exclui o resto; vazio volta para Qualquer
        this.entityData.set(MINERIO, m);
    }

    public boolean minerioServe(net.minecraft.world.level.block.state.BlockState estado) {
        int m = getMascaraMinerio();
        if ((m & 1) != 0) return Minerio.QUALQUER.serve(estado);
        for (Minerio mi : Minerio.values()) {
            if ((m & (1 << mi.ordinal())) != 0 && mi.serve(estado)) return true;
        }
        return false;
    }

    public String rotuloMinerios() {
        int m = getMascaraMinerio();
        if ((m & 1) != 0) return Minerio.QUALQUER.getRotulo();
        StringBuilder sb = new StringBuilder();
        for (Minerio mi : Minerio.values()) {
            if ((m & (1 << mi.ordinal())) != 0) {
                if (sb.length() > 0) sb.append(", ");
                sb.append(mi.getRotulo());
            }
        }
        return sb.toString();
    }

    private int rodizioMinerio;

    /** Um dos minérios escolhidos (reveza a cada viagem) para decidir a profundidade da busca. */
    public Minerio minerioParaProfundidade() {
        int m = getMascaraMinerio();
        if ((m & 1) != 0) return Minerio.QUALQUER;
        java.util.List<Minerio> lista = new java.util.ArrayList<>();
        for (Minerio mi : Minerio.values()) if ((m & (1 << mi.ordinal())) != 0) lista.add(mi);
        return lista.get(Math.floorMod(rodizioMinerio, lista.size()));
    }

    public void revezarMinerio() {
        rodizioMinerio++;
    }

    /** Compatibilidade: o primeiro escolhido. */
    public Minerio getMinerio() {
        return minerioParaProfundidade();
    }

    public Direction getDirTunel() {
        return dirTunel;
    }

    // ------------------------------------------------------------------ teleporte seguro (como o cachorro)

    /** Teleporta para um ponto firme, seco e livre perto do dono. Se o dono estiver voando, vai para o chão abaixo dele. */
    public boolean teleportarParaDono(Player dono) {
        if (this.level().getGameTime() - ultimoTp < 40) return false;
        ultimoTp = this.level().getGameTime();
        BlockPos base = dono.blockPosition();
        for (int i = 0; i < 24; i++) {
            int dx = this.random.nextInt(7) - 3;
            int dz = this.random.nextInt(7) - 3;
            if (Math.abs(dx) < 2 && Math.abs(dz) < 2) continue;
            BlockPos ponto = acharPontoSeguro(base.offset(dx, 0, dz));
            if (ponto != null) {
                this.moveTo(ponto.getX() + 0.5D, ponto.getY(), ponto.getZ() + 0.5D, this.getYRot(), this.getXRot());
                this.getNavigation().stop();
                return true;
            }
        }
        return false;
    }

    /** Tira o funcionário de um buraco: leva para um ponto firme perto de uma posição (ex.: a superfície onde começou). */
    public boolean teleportarParaSeguro(BlockPos centro) {
        for (int i = 0; i < 30; i++) {
            int dx = i == 0 ? 0 : this.random.nextInt(5) - 2;
            int dz = i == 0 ? 0 : this.random.nextInt(5) - 2;
            BlockPos ponto = acharPontoSeguro(centro.offset(dx, 0, dz));
            if (ponto != null) {
                this.moveTo(ponto.getX() + 0.5D, ponto.getY(), ponto.getZ() + 0.5D, this.getYRot(), this.getXRot());
                this.getNavigation().stop();
                return true;
            }
        }
        return false;
    }

    /** Procura de cima para baixo (até 24 blocos) um lugar para ficar em pé. */
    private BlockPos acharPontoSeguro(BlockPos topo) {
        Level nivel = this.level();
        for (int dy = 1; dy >= -24; dy--) {
            BlockPos pe = topo.offset(0, dy, 0);
            if (!nivel.hasChunkAt(pe)) return null;
            BlockPos abaixo = pe.below();
            BlockState chao = nivel.getBlockState(abaixo);
            if (!chao.isFaceSturdy(nivel, abaixo, Direction.UP) || chao.is(BlockTags.LEAVES)) continue;
            if (WalkNodeEvaluator.getBlockPathTypeStatic(nivel, pe.mutable()) != BlockPathTypes.WALKABLE) continue;
            AABB caixa = this.getBoundingBox().move(pe.getX() + 0.5D - this.getX(),
                    pe.getY() - this.getY(), pe.getZ() + 0.5D - this.getZ());
            if (nivel.noCollision(this, caixa)) return pe;
        }
        return null;
    }

    /** Em modo de trabalho (minerar, madeira, colher, entregar) ele não morre de queda, lava, fogo, afogamento nem sufocado. */
    private boolean emServico() {
        Tarefa t = getTarefa();
        return t.ehTrabalho() || t == Tarefa.ENTREGAR;
    }

    @Override
    public boolean fireImmune() {
        return emServico() || super.fireImmune();
    }

    @Override
    public boolean hurt(DamageSource fonte, float quantidade) {
        if (emServico() && (fonte.is(DamageTypes.FALL) || fonte.is(DamageTypes.DROWN)
                || fonte.is(DamageTypes.IN_WALL) || fonte.is(DamageTypeTags.IS_FIRE))) {
            if (fonte.is(DamageTypeTags.IS_FIRE)) this.clearFire();
            return false;
        }
        return super.hurt(fonte, quantidade);
    }

    private int emLiquido;

    @Override
    public boolean causeFallDamage(float distancia, float multiplicador, DamageSource fonte) {
        return super.causeFallDamage(Math.max(0.0F, distancia - 4.0F), multiplicador, fonte);
    }

    // ------------------------------------------------------------------ regeneração e comida

    /** Mantém os chunks em volta carregados (como um jogador), para ele trabalhar mesmo com o dono longe. */
    private static final TicketType<ChunkPos> TICKET_TRABALHO =
            TicketType.create("funcionarios_trabalho", Comparator.comparingLong(ChunkPos::toLong), 40);

    @Override
    public void aiStep() {
        super.aiStep();
        if (this.level().isClientSide || !this.isAlive()) return;
        // caiu em lava ou água funda trabalhando: depois de 3 s vai para o chão onde começou
        if (emServico() && (this.isInLava() || (this.isInWater() && this.isUnderWater()))) {
            if (++emLiquido > 60) {
                emLiquido = 0;
                this.teleportarParaSeguro(this.casa);
            }
        } else {
            emLiquido = 0;
        }
        if (this.tickCount % 10 == 0 && this.level() instanceof ServerLevel sl) {
            Tarefa t = getTarefa();
            if (t.ehTrabalho() || t == Tarefa.ENTREGAR) {
                ChunkPos cp = new ChunkPos(this.blockPosition());
                sl.getChunkSource().addRegionTicket(TICKET_TRABALHO, cp, t == Tarefa.MINERIO ? 5 : 3, cp); // minerador enxerga mais chunks
            }
        }
        boolean emCombate = this.getLastHurtByMob() != null
                && this.tickCount - this.getLastHurtByMobTimestamp() < 200;
        if (!emCombate && this.tickCount % 100 == 0 && this.getHealth() < this.getMaxHealth()) {
            this.heal(1.0F);
        }
        if (this.tickCount % 20 == 0 && this.getHealth() <= this.getMaxHealth() * 0.6F) {
            comerSeNecessario();
        }
    }

    private void comerSeNecessario() {
        for (int i = 0; i < inventario.getContainerSize(); i++) {
            ItemStack s = inventario.getItem(i);
            if (s.isEmpty() || !s.isEdible()) continue;
            FoodProperties comida = s.getItem().getFoodProperties();
            if (comida == null || !comida.getEffects().isEmpty()) continue;
            this.heal(Math.max(2, comida.getNutrition()));
            this.level().playSound(null, this.blockPosition(), SoundEvents.GENERIC_EAT, SoundSource.NEUTRAL, 1.0F, 1.0F);
            s.shrink(1);
            inventario.setChanged();
            return;
        }
    }

    public int getSkin() {
        return this.entityData.get(SKIN);
    }

    @Override
    public boolean removeWhenFarAway(double distancia) {
        return false;
    }

    @Override
    protected void dropCustomDeathLoot(DamageSource fonte, int saque, boolean atingidoRecentemente) {
        super.dropCustomDeathLoot(fonte, saque, atingidoRecentemente);
        Containers.dropContents(this.level(), this.blockPosition(), inventario);
        Containers.dropContents(this.level(), this.blockPosition(), ferramentas);
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.put("Inventario", inventario.createTag());
        tag.put("Ferramentas", ferramentas.createTag());
        if (dono != null) tag.putUUID("Dono", dono);
        tag.putInt("Tarefa", getTarefa().ordinal());
        tag.putInt("TarefaAnterior", tarefaAnterior.ordinal());
        tag.putInt("Skin", getSkin());
        tag.putInt("Personalidade", personalidade);
        tag.putInt("CasaX", casa.getX());
        tag.putInt("CasaY", casa.getY());
        tag.putInt("CasaZ", casa.getZ());
        tag.putBoolean("AreaFixa", areaFixa);
        tag.putInt("MinerioMask", getMascaraMinerio());
        tag.putInt("Nivel", getNivel());
        tag.putInt("DirTunel", dirTunel.get2DDataValue());
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        inventario.fromTag(tag.getList("Inventario", Tag.TAG_COMPOUND));
        ferramentas.fromTag(tag.getList("Ferramentas", Tag.TAG_COMPOUND));
        if (tag.hasUUID("Dono")) dono = tag.getUUID("Dono");
        this.entityData.set(TAREFA, tag.getInt("Tarefa"));
        tarefaAnterior = Tarefa.de(tag.getInt("TarefaAnterior"));
        this.entityData.set(SKIN, tag.getInt("Skin"));
        if (this.getCustomName() != null) {
            String nm = this.getCustomName().getString();
            int sk = Math.floorMod(this.entityData.get(SKIN), 12);
            if (NOMES_FEMININOS.contains(nm) && sk < 6) sk += 6;
            else if (NOMES_MASCULINOS.contains(nm) && sk >= 6) sk -= 6;
            this.entityData.set(SKIN, sk);
        }
        personalidade = tag.getInt("Personalidade");
        casa = new BlockPos(tag.getInt("CasaX"), tag.getInt("CasaY"), tag.getInt("CasaZ"));
        areaFixa = tag.getBoolean("AreaFixa");
        if (tag.contains("MinerioMask")) setMascaraMinerio(tag.getInt("MinerioMask"));
        else setMascaraMinerio(1 << Math.max(0, Math.min(Minerio.values().length - 1, tag.getInt("Minerio"))));
        this.entityData.set(NIVEL, Math.max(0, Math.min(NIVEL_MAX, tag.getInt("Nivel"))));
        aplicarNivel();
        dirTunel = Direction.from2DDataValue(tag.getInt("DirTunel"));
    }
}
