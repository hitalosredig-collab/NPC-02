# Mod Funcionários (Minecraft Java 1.20.1 / Forge 47.x)

Contrate funcionários humanoides que trabalham e defendem você.

## Como colocar pra rodar

1. Baixe o **Forge MDK 1.20.1** (versão 47.x) em https://files.minecraftforge.net e extraia numa pasta.
2. Dentro do MDK, apague `src/main/java/com/example` e `src/main/resources/META-INF/mods.toml`.
3. Copie a pasta `src` deste projeto para dentro do MDK (mesclando/substituindo).
4. No `gradle.properties` do MDK, troque: `mod_id=funcionarios`, `mod_name=Funcionarios`, `mod_group_id=com.funcionarios`.
5. Abra a pasta do MDK no IntelliJ IDEA (Java 17), deixe o Gradle sincronizar e rode a configuração `runClient`.
   Para gerar o `.jar`: `gradlew build` (sai em `build/libs`).

O mod NÃO precisa do TACZ para compilar nem para rodar. A compatibilidade é opcional e feita por reflexão.

## Gerar o .jar pelo GitHub (sem instalar nada)

1. Crie um repositório no GitHub e envie o CONTEÚDO desta pasta (`src`, `.github`, `README.md`).
   A pasta `.github` é escondida em alguns sistemas: ela precisa ir junto.
2. Abra a aba **Actions** do repositório. A compilação roda sozinha (ou use **Run workflow**).
3. Quando terminar (alguns minutos), clique na execução e baixe **funcionarios-jar** em *Artifacts*.
   Dentro do zip baixado está o `.jar` para a pasta `mods`.
4. Se a compilação falhar, clique na execução, copie a mensagem de erro do passo "Compilar" e mande para ajuste.

## Como jogar

- Receita: **papel + esmeralda** (sem forma) = Contrato de Funcionário (também na aba Ferramentas do criativo).
- Clique direito com o contrato num bloco para contratar.
- Clique direito no funcionário para abrir a tela.

### Tela do funcionário

Tudo fica numa janela só (compatível com mods de itens como o JEI).

- Primeira coluna à esquerda: **capacete, peitoral, calça, bota e escudo** (com o ícone de cada peça nos slots vazios).
  A armadura aparece no corpo dele e o escudo é levantado quando ele luta de perto.
- Segunda coluna: **2 slots de arma** (espada, machado, tridente ou arma do TACZ), **picareta, machado, pá e enxada**
  (com o ícone apagado quando vazios). Cada slot só aceita o tipo certo.
- Centro: o inventário dele (27 slots, estilo baú), uma caixa com nome, tarefa e fala, e o seu inventário embaixo.
- Direita: botões de comando.
- Ele pega a ferramenta direto desses slots (pá para terra e areia; picareta, machado e enxada para o resto) e a mostra na mão.
  Ferramentas e armas nos slots não são entregues a você no "Entregar itens".

### Comandos

| Botão | O que precisa | O que faz |
|---|---|---|
| Parar | nada | para tudo |
| Seguir você | nada | anda atrás de você |
| Me defender | espada, machado ou arma do TACZ | ataca monstros perto de você e quem te machucar |
| Pegar madeira | machado (mão ou inventário) | corta árvores num raio de 16 blocos |
| Minerar pedra | picareta | quebra a pedra exposta ao redor. Se não achar, procura a pedra mais próxima (mesmo enterrada) e cava uma escada até ela |
| Minerar minério | picareta | igual, mas só pega o minério escolhido no botão `<>` (Qualquer, Carvão, Ferro, Cobre, Ouro, Redstone, Lazurita, Diamante, Esmeralda) |
| Colher plantação | nada (enxada é opcional) | colhe plantações maduras e replanta |
| Entregar itens | nada | vem até você e entrega tudo, menos ferramentas e armas |

Sem a ferramenta ou arma certa, ele recusa com uma fala. Se o inventário enche no meio do trabalho,
ele entrega sozinho e volta a trabalhar. Ao morrer, solta o inventário e o equipamento.

## Central dos Funcionários

Receita: **bússola + papel** (também na aba Ferramentas do criativo). Clique direito com ela na mão para abrir a lista de todos os
seus funcionários que estão em área carregada: nome, tarefa atual, vida e distância. Os botões **Chamar** (ele volta para perto de você,
no chão, e passa a seguir você) e **Parar** funcionam de qualquer distância. A lista atualiza sozinha a cada 2 segundos.

Limite: funcionário em área descarregada (muito longe, sem você por perto) não aparece, porque o Minecraft não o está simulando.

## Voz

Os funcionários falam em voz alta (além de escrever) usando a **voz do sistema**, a mesma do narrador do Minecraft:
no Windows em português, a voz "Microsoft Maria/Daniel" etc., se estiver instalada. Só fala quando ele está a até 20 blocos de você.
O botão **Voz: ligada/desligada** na tela dele liga e desliga. A distância e o liga/desliga também ficam em `config/funcionarios-client.toml`.
Não é um dublador: o tom é o da voz do computador, igual para todos. Se não houver voz no sistema, ele só escreve.

## Comportamento

- Se não achar pedra ou minério no raio de trabalho, ele sai andando uns 24 blocos numa direção nova e procura de novo (até 4 vezes) antes de desistir.

- Teletransporte: se você se afastar mais de 15 blocos, ele aparece num chão firme e seco perto de você. Se você estiver voando, ele vai para o chão embaixo de você.
- Velocidade: ele quebra blocos na velocidade real da ferramenta na mão (material, eficiência e dureza do bloco).
- Combate: 40 de vida, regenera sozinho, come comida do inventário quando está ferido, usa o escudo da mão secundária e revida se for atacado trabalhando (precisa de espada, machado ou arma).
- Ele não entra na água sozinho.
- Só quebra o que ele enxerga em linha reta (não atravessa parede). Ao cavar, só mexe em terreno natural (terra, pedra, areia, cascalho, minério) e nunca em água, lava ou baús.
- Ao quebrar, aparece a rachadura no bloco, o som e o braço balançando (visível em 1ª e 3ª pessoa).

## Armas do TACZ (opcional)

Com o TACZ instalado, ponha uma arma dele no inventário (ou na mão) e munição no inventário do funcionário,
e use "Me defender". Se algo falhar, procure por `CompatArmas` no log do jogo (`logs/latest.log`) e mande para ajuste.

Essa parte foi escrita a partir da documentação pública do TACZ e ainda não foi testada com o jogo.

## Próximas etapas (ainda não feitas)

- Salário/pagamento recorrente
- Baú vinculado para entrega
- Troca com villagers
- Construção de casas
- Skins escolhidas pelo jogador


## v0.8
- Escada: ele faz a escada UMA vez até a pedra e depois só quebra o que ficou exposto ao redor (não cava mais pra baixo sem parar).
- Central: mostra vida (barra), o que tem na mão e o inventário (ícones com quantidade).
- Vozes: no Windows cada funcionário usa uma voz instalada (português) com tom e velocidade próprios; senão cai no narrador.
  Para mais vozes: Configurações > Hora e idioma > Fala > Adicionar vozes.

## v0.9
- Pedra: depois da escada, limpa um salão 7x7 (3 de altura) e avança, até o inventário encher; aí vem te entregar.
- Madeira: sem árvore perto, procura copas nos chunks carregados (até 64 blocos) e vai até lá.
- Minério: raio-X de 20 blocos; se não achar, desce em escada até a profundidade do minério (diamante y -54) e abre túnel, minerando a veia e seguindo.

## v0.10
- Se não consegue chegar andando até uma pedra/minério exposto, cava até ele; se o caminho do degrau falha, desliza até o degrau que ele mesmo cavou.
- Terra, pedra e folhas de passagem são descartadas (não enchem o inventário); na pedra ele guarda só pedra/minério.
- Madeira: começa pela base do tronco e derruba a árvore inteira (só árvores naturais, com folhas; casas de madeira não).

## v0.11
- Vigia: se ele passa 30 s sem quebrar nada nem avançar, avisa no chat o motivo ([Funcionário] ...), recomeça e sai do buraco (teleporta para o chão onde começou). Na 3ª vez para.
- Seguir/entregar: sem caminho (preso em buraco/mina funda), ele teleporta para o chão perto de você.

## v0.12 (menos pensar, mais fazer)
- Pedra: não anda atrás de pedra; quebra a grama/terra e desce em escada até achar pedra, aí limpa o salão 7x7 e segue até encher.
- Pedra/minério nunca desistem: se travar, recomeça (e volta para o chão onde começou).
- Árvore: quebra um tronco e derruba a árvore inteira (qualquer árvore com folhas).
- Ao encher o inventário ele vem entregar e, depois, volta direto para onde estava minerando.

## v0.13 – vozes
- Skins 0 e 2 usam voz masculina e a skin 1 usa voz feminina (se o Windows tiver as duas; senão ele muda o tom da que tiver).
- Para ter homem e mulher: Configurações > Hora e idioma > Fala > Adicionar vozes (Português do Brasil).

## v0.14
- Se há um bloco entre ele e o alvo (terra na frente da pedra, folhas na frente do tronco), ele quebra o que está atrapalhando na hora.
- Se ficar preso 2 vezes, passa a quebrar qualquer bloco comum no caminho (nunca baú, água ou lava).
- Árvore: derruba troncos e as folhas naturais juntos; alcança troncos até 6 blocos.

## v0.15 – mineração com raio-X
- O minério escolhido é procurado em todos os chunks carregados (até ~6 chunks) e ele cava direto até o mais próximo; depois da veia, vai pro próximo (um minério por minério).
- Se não há nenhum nos chunks carregados, abre túnel de busca na profundidade certa.
- Consertado: minério que estava no caminho era quebrado e jogado fora; agora é guardado.
- Mensagens [Funcionário] no chat mostram o que ele achou/está fazendo (ajuda a achar bugs).

## v0.16
- Viagem até árvore distante sem caminho (penhasco, montanha): teleporta para o chão perto do destino em vez de ficar parado.

## v0.17
- Madeira: tronco que não dá para alcançar andando (penhasco/buraco): ele teleporta para o chão perto do tronco (até 2 vezes) antes de desistir daquele.

## v0.18
- Anti-travamento rápido: depois de 4 s sem progresso ele quebra o bloco na frente dele (ou larga o alvo travado); com 20 s sem progresso reinicia tudo.
- Dica: para trabalharem enquanto você está longe construindo, o chão onde eles estão precisa estar carregado: fique até ~10 chunks de distância ou use /forceload add ~ ~ (servidor/mundo aberto).

## v0.19 – trabalho sem você
- Ao dar uma ordem de trabalho, ele guarda o ponto onde estava. Se houver um baú ou barril num raio de 12 blocos desse ponto, quando o inventário enche ele leva tudo (menos ferramentas/armas) para o baú, e volta direto para onde estava trabalhando. Sem baú por perto, ele vem entregar para você como antes.
- Para deixar eles trabalhando sozinhos: coloque um baú ao lado de onde dá a ordem.

## v0.20
- Carrega chunks como um jogador: enquanto trabalha (ou entrega), mantém uns 3 chunks em volta carregados, então segue trabalhando mesmo com você longe.
- Animação ao quebrar: braço balançando, rachadura no bloco, partículas do bloco e som.

## v0.21
- Conserto importante: o degrau cavado contava como "chegou" quando ele ainda estava na célula vizinha (distância < 1,5); ele ficava repetindo o mesmo degrau sem sair do lugar (congelado) e o vigia nem disparava. Agora só conta ao entrar na célula, e desliza até ela depois de 0,6 s se o caminho falhar.

## v0.22 – melhorias (3 níveis)
- Botão "Melhorar" na tela do funcionário. Cada nível custa material do SEU inventário (passe o mouse no botão para ver):
  - Nível 1 (2x2): 12 lingotes de ferro + 4 de ouro
  - Nível 2 (3x3): 8 lingotes de ouro + 4 diamantes
  - Nível 3 (4x4): 16 diamantes + 8 esmeraldas
- Pedra e minério quebram em área (2x2/3x3/4x4, no plano de frente para o bloco). Todos os níveis quebram mais rápido (x1,5 / x2,2 / x3,5), inclusive madeira e colheita.

## v0.23 – tela compacta
- A tela do funcionário agora tem 176x216 (tamanho de baú duplo) em vez de 342x224, para não brigar com o JEI.
- Duas abas na mesma janela: "Itens" (armadura/escudo, 2 armas, picareta/machado/pá/enxada, inventário dele e o seu) e "Comandos" (status, fala, botões, voz, melhorar).

## v0.24
- Em serviço (minerar, madeira, colher, entregar) ele não leva dano de queda, lava/fogo, afogamento nem sufocamento. Fora do serviço, volta ao normal.
- Se cair em lava ou ficar debaixo d'água por 3 s trabalhando, é levado para o chão onde começou.

## v0.25 – TACZ
- O tiro agora funciona com as duas assinaturas do TACZ (shoot(pitch, yaw) e shoot(pitch, yaw, tempo)); métodos são achados por nome.
- No chat aparecem mensagens "[Funcionário] TACZ ..." quando a arma de fogo não funciona (API diferente) ou o TACZ recusa o tiro (NOT_DRAW, COOL_DOWN, NO_AMMO...).

## v0.26 – vozes realmente diferentes
- A fala é gerada pelo Windows em um arquivo de áudio e o mod muda o tom antes de tocar: skin 0 voz masculina grave, skin 2 masculina mais leve, skin 1 feminina; a personalidade deixa mais grave/lenta (rabugento) ou mais aguda/rápida (animado).
- Se o Windows tiver vozes masculinas e femininas em português, usa cada uma pelo gênero e o tom só varia de leve.

## v0.27 – Baú do Funcionário
- Novo bloco "Baú do Funcionário" (receita: baú + esmeralda). Tem 27 slots de armazenamento e 5 slots verdes de "pedido".
- Ao terminar o trabalho / encher a mochila, o funcionário vai a este baú e guarda tudo; depois pega o que estiver nos 5 slots de pedido (armadura, escudo, ferramentas vestem/guardam; o resto vai para a mochila).
- Ao receber um comando de trabalho, se houver pedidos esperando, ele passa no baú antes de começar.
- Só o dono abre o baú. Funis/itens automáticos usam os 27 slots de armazenamento.

## v0.28 – Baús em 6 níveis, fundidos, visual de baú
- Baú com formato de baú (tampa, fecho com esmeralda), vira para o jogador ao colocar.
- Níveis: madeira (3 linhas), cobre (4), ferro (5), ouro (6), diamante (7), netherite (9). Upgrade: baú do nível anterior no meio + 4 lingotes/diamantes em cruz; netherite pela mesa de ferraria (molde + baú de diamante + lingote de netherite).
- Dois baús lado a lado (mesma direção) se fundem: abre uma tela só com os dois; o funcionário e funis enxergam o par como um baú só.
- Removidos os 5 slots de "pedido" (funcionário pegar itens do baú).
- Mineração: raio-X não varre mais os chunks toda hora quando não acha minério (menos lag).

## v0.29 – vozes por gênero, resenha, mineração sem espera
- Gênero da voz segue o nome (Cida, Lúcia, Rita, Neide = feminina; os outros = masculina). Voz masculina fica bem mais grave e continua na velocidade normal (reamostragem + WSOLA).
- Nova situação RESENHA: a cada ~45–105 s trabalhando ou seguindo ele solta uma fala de papo (30 frases, 10 por personalidade). Nomes novos: Rita, Chico, Neide, Juca.
- Mineração: sem pausas; a busca de raio-X só é pulada por 2 s (ele continua cavando) e a espera entre buscas caiu para 2 ticks.

## v0.30 – vozes de verdade (WinRT)
- Voz agora usa também as vozes do Windows 10/11 (as que aparecem em Configurações > Hora e idioma > Fala), com voz masculina real (ex.: Daniel pt-BR) quando instalada. Sem pitch grave: só usa a voz do gênero certo.
- O chat mostra uma vez a lista de vozes achadas ("[Funcionário] Vozes do seu Windows -> ...").

## v0.31 – baú no estilo mochila
- Tamanhos: madeira 27 slots (9x3), cobre 36 (9x4), ferro 54 (9x6), ouro 81 (9x9), diamante 108 (12x9), netherite 120 (12x10). Telas largas para os níveis altos.

## v0.32 – foice e espada
- Foice (qualquer item de mod com scythe/sickle/foice no nome) vale como enxada: slot de enxada, colheita e quebra de folhas/feno.
- Ao quebrar folhas, feno e blocos "de enxada" ele troca para enxada/foice; teia, bambu e plantas, para espada. Depois volta à ferramenta da tarefa.

## v0.32 – mineração mais rápida e sem travar
- Degraus cavados: ele anda reto até a célula (sem pathfinding), 0,3 bloco por tick.
- Quebra de passagem 3x mais rápida; pedra/minério 1,5x mais rápidos.

## v0.33 – baú duplo de verdade + rolagem
- Baús do MESMO nível lado a lado (mesma direção) se fundem em baú duplo, com modelo emendado, só 2 por vez (agachar ao colocar não funde).
- Bloco sem "transparência" ao redor (noOcclusion + forma própria).
- Tela com janela de até 6 linhas e barra de rolagem (roda do mouse ou arrastar); duplo tem o dobro de slots numa grade só.

## v0.34 – minério sem ficar parado
- Se 3 minérios seguidos ficam sem caminho (água/lava no meio), ele abre um túnel de busca por ~40 passos em vez de ficar tentando.
- A mensagem "achado a N blocos" aparece no máximo a cada 1 minuto; espera entre tentativas caiu para 1 tick.
