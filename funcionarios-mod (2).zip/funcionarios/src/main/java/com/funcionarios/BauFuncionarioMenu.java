package com.funcionarios;

import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.world.Container;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;

/**
 * Baú com janela rolável (igual às mochilas): mostra até 6 linhas e o resto aparece rolando.
 * Os slots visíveis apontam para (posição + rolagem) dentro do baú inteiro (1 ou 2 baús fundidos).
 */
public class BauFuncionarioMenu extends AbstractContainerMenu {
    public static final int TOPO = 20;
    public static final int MAX_VISIVEIS = 6;

    private final Container bau;
    private final BlockPos pos;
    private final int colunas;
    private final int linhasTotais;
    private final int linhasVisiveis;
    private final int janela;
    private final int largura;
    private final int altura;
    private final int invY;
    private final int xBaus;
    private int rolagem;

    /** Cliente: o conteúdo chega pela sincronização do menu. */
    public BauFuncionarioMenu(int id, Inventory inv, FriendlyByteBuf buf) {
        this(id, inv, null, buf.readBlockPos(), buf.readVarInt(), buf.readVarInt());
    }

    public BauFuncionarioMenu(int id, Inventory inv, Container bau, BlockPos pos, int colunas, int total) {
        super(Registros.MENU_BAU.get(), id);
        this.pos = pos;
        this.colunas = Math.max(1, colunas);
        this.bau = bau != null ? bau : new SimpleContainer(Math.max(1, total));
        this.linhasTotais = Math.max(1, (total + this.colunas - 1) / this.colunas);
        this.linhasVisiveis = Math.min(linhasTotais, MAX_VISIVEIS);
        boolean barra = linhasTotais > linhasVisiveis;
        int larguraBaus = 16 + this.colunas * 18 + (barra ? 12 : 0);
        this.largura = Math.max(176, larguraBaus);
        this.xBaus = (largura - larguraBaus) / 2 + 8;
        this.invY = TOPO + linhasVisiveis * 18 + 14;
        this.altura = invY + 58 + 26;
        this.janela = linhasVisiveis * this.colunas;
        for (int i = 0; i < janela; i++) {
            this.addSlot(new SlotJanela(this.bau, i, xBaus + (i % this.colunas) * 18, TOPO + (i / this.colunas) * 18));
        }
        int ix = (largura - 176) / 2 + 8;
        for (int r = 0; r < 3; r++) {
            for (int c = 0; c < 9; c++) {
                this.addSlot(new Slot(inv, c + r * 9 + 9, ix + c * 18, invY + r * 18));
            }
        }
        for (int c = 0; c < 9; c++) {
            this.addSlot(new Slot(inv, c, ix + c * 18, invY + 58));
        }
    }

    /** Slot que mostra o item de índice (posição + rolagem) do baú inteiro. */
    private class SlotJanela extends Slot {
        private final int local;

        SlotJanela(Container c, int local, int x, int y) {
            super(c, local, x, y);
            this.local = local;
        }

        private int real() {
            int r = local + rolagem * colunas;
            return r < container.getContainerSize() ? r : -1;
        }

        @Override
        public ItemStack getItem() {
            int r = real();
            return r < 0 ? ItemStack.EMPTY : container.getItem(r);
        }

        @Override
        public void set(ItemStack pilha) {
            int r = real();
            if (r >= 0) container.setItem(r, pilha);
            this.setChanged();
        }

        @Override
        public void setByPlayer(ItemStack pilha) {
            set(pilha);
        }

        @Override
        public ItemStack remove(int qtd) {
            int r = real();
            return r < 0 ? ItemStack.EMPTY : container.removeItem(r, qtd);
        }

        @Override
        public boolean mayPlace(ItemStack pilha) {
            return real() >= 0;
        }

        @Override
        public boolean mayPickup(Player jogador) {
            return real() >= 0;
        }

        @Override
        public int getContainerSlot() {
            return Math.max(0, real());
        }
    }

    public int getColunas() {
        return colunas;
    }

    public int getLinhasTotais() {
        return linhasTotais;
    }

    public int getLinhasVisiveis() {
        return linhasVisiveis;
    }

    public int getXBaus() {
        return xBaus;
    }

    public int getRolagem() {
        return rolagem;
    }

    public int getMaxRolagem() {
        return linhasTotais - linhasVisiveis;
    }

    public void setRolagem(int r) {
        this.rolagem = Math.max(0, Math.min(getMaxRolagem(), r));
    }

    @Override
    public boolean clickMenuButton(Player jogador, int id) {
        if (id < 0 || id > getMaxRolagem()) return false;
        setRolagem(id);
        this.sendAllDataToRemote();
        return true;
    }

    public int getLargura() {
        return largura;
    }

    public int getAltura() {
        return altura;
    }

    public int getInvY() {
        return invY;
    }

    public int getInvX() {
        return (largura - 176) / 2 + 8;
    }

    @Override
    public boolean stillValid(Player jogador) {
        return jogador.distanceToSqr(pos.getX() + 0.5D, pos.getY() + 0.5D, pos.getZ() + 0.5D) <= 64.0D;
    }

    /** Coloca o item em qualquer lugar do baú inteiro (não só nas linhas visíveis). */
    private boolean inserirTudo(ItemStack pilha) {
        boolean mexeu = false;
        int total = bau.getContainerSize();
        for (int i = 0; i < total && !pilha.isEmpty(); i++) {
            ItemStack c = bau.getItem(i);
            if (c.isEmpty() || !ItemStack.isSameItemSameTags(c, pilha)) continue;
            int limite = Math.min(bau.getMaxStackSize(), c.getMaxStackSize());
            int mover = Math.min(pilha.getCount(), limite - c.getCount());
            if (mover > 0) {
                c.grow(mover);
                pilha.shrink(mover);
                mexeu = true;
            }
        }
        for (int i = 0; i < total && !pilha.isEmpty(); i++) {
            if (!bau.getItem(i).isEmpty()) continue;
            int mover = Math.min(pilha.getCount(), Math.min(bau.getMaxStackSize(), pilha.getMaxStackSize()));
            bau.setItem(i, pilha.split(mover));
            mexeu = true;
        }
        if (mexeu) bau.setChanged();
        return mexeu;
    }

    @Override
    public ItemStack quickMoveStack(Player jogador, int indice) {
        Slot slot = this.slots.get(indice);
        if (slot == null || !slot.hasItem()) return ItemStack.EMPTY;
        ItemStack pilha = slot.getItem();
        ItemStack copia = pilha.copy();
        if (indice < janela) {
            if (!this.moveItemStackTo(pilha, janela, this.slots.size(), true)) return ItemStack.EMPTY;
        } else if (!inserirTudo(pilha)) {
            return ItemStack.EMPTY;
        }
        if (pilha.isEmpty()) {
            slot.setByPlayer(ItemStack.EMPTY);
        } else {
            slot.setChanged();
        }
        return copia;
    }
}
