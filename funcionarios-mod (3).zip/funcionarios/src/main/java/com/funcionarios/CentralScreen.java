package com.funcionarios;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/** Central dos funcionários: lista todos os que estão em área carregada e deixa chamar de volta ou parar. */
public class CentralScreen extends Screen {
    private static final int LARGURA = 300;
    private static final int LINHA = 28;
    private static final int TOPO = 28;

    private List<PacoteLista.Entrada> lista = new ArrayList<>();
    private int tempo;
    private boolean recebeu;

    public CentralScreen() {
        super(Component.literal("Central dos Funcionários"));
    }

    @Override
    protected void init() {
        Rede.CANAL.sendToServer(new PacoteCentral(PacoteCentral.PEDIR, 0));
        montar();
    }

    public void atualizar(List<PacoteLista.Entrada> nova) {
        this.lista = nova;
        this.recebeu = true;
        montar();
    }

    private int altura() {
        return TOPO + Math.max(1, lista.size()) * LINHA + 14;
    }

    private void montar() {
        this.clearWidgets();
        int x = (this.width - LARGURA) / 2;
        int y = (this.height - altura()) / 2;
        for (int i = 0; i < lista.size(); i++) {
            PacoteLista.Entrada e = lista.get(i);
            int ly = y + TOPO + i * LINHA;
            this.addRenderableWidget(Button.builder(Component.literal("Chamar"),
                            b -> Rede.CANAL.sendToServer(new PacoteCentral(PacoteCentral.CHAMAR, e.id)))
                    .bounds(x + LARGURA - 112, ly + 3, 54, 18).build());
            this.addRenderableWidget(Button.builder(Component.literal("Parar"),
                            b -> Rede.CANAL.sendToServer(new PacoteCentral(PacoteCentral.PARAR, e.id)))
                    .bounds(x + LARGURA - 54, ly + 3, 48, 18).build());
        }
    }

    @Override
    public void tick() {
        if (++tempo % 40 == 0) {
            Rede.CANAL.sendToServer(new PacoteCentral(PacoteCentral.PEDIR, 0));
        }
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float parcial) {
        this.renderBackground(g);
        int x = (this.width - LARGURA) / 2;
        int y = (this.height - altura()) / 2;
        g.fill(x - 1, y - 1, x + LARGURA + 1, y + altura() + 1, 0xFF000000);
        g.fill(x, y, x + LARGURA, y + altura(), 0xFF2B2B2B);
        g.drawCenteredString(this.font, this.title, this.width / 2, y + 9, 0xFFD700);

        if (lista.isEmpty()) {
            String msg = recebeu ? "Nenhum funcionário em área carregada." : "Carregando...";
            g.drawCenteredString(this.font, Component.literal(msg), this.width / 2, y + TOPO + 9, 0xAAAAAA);
        }
        for (int i = 0; i < lista.size(); i++) {
            PacoteLista.Entrada e = lista.get(i);
            int ly = y + TOPO + i * LINHA;
            g.fill(x + 4, ly, x + LARGURA - 4, ly + LINHA - 2, 0xFF3C3C3C);
            g.drawString(this.font, Component.literal(e.nome), x + 8, ly + 4, 0xFFD700, false);
            g.drawString(this.font, Component.literal(Tarefa.de(e.tarefa).getRotulo()), x + 8, ly + 15, 0xFFFFFF, false);
            String info = (int) e.vida + "/" + (int) e.vidaMax + " vida  |  " + e.distancia + " blocos";
            g.drawString(this.font, Component.literal(info), x + 100, ly + 9, 0xAAAAAA, false);
        }
        super.render(g, mouseX, mouseY, parcial);
    }
}
