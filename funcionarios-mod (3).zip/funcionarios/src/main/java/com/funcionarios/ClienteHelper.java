package com.funcionarios;

import java.util.List;
import net.minecraft.client.Minecraft;

/** Chamadas que só existem no cliente (telas). Fica separado para o servidor não carregar classes de tela. */
public final class ClienteHelper {
    private ClienteHelper() {}

    public static void abrirCentral() {
        Minecraft.getInstance().setScreen(new CentralScreen());
    }

    public static void atualizar(List<PacoteLista.Entrada> lista) {
        if (Minecraft.getInstance().screen instanceof CentralScreen tela) {
            tela.atualizar(lista);
        }
    }
}
