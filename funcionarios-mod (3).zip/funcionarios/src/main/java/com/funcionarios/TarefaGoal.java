package com.funcionarios;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.EnumSet;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.CropBlock;
import net.minecraft.world.level.block.EntityBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.pathfinder.Path;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.common.Tags;

/**
 * A "IA" do funcionário: seguir, entregar e trabalhar (madeira, pedra, minério, colheita).
 *
 * Regras de trabalho:
 * - só quebra um bloco se tiver linha de visão direta até ele (nunca atravessa parede);
 * - se não achar pedra/minério exposto, escolhe o mais próximo (mesmo enterrado) e cava uma escada
 *   até ele, só em terreno natural (terra, pedra, areia...), sem tocar em água, lava ou baús;
 * - ao chegar na pedra, passa a quebrar tudo que ficou exposto ao redor.
 */
public class TarefaGoal extends Goal {
    private final FuncionarioEntity f;
    private final DefesaLogica defesa;

    private Tarefa ultima = Tarefa.PARAR;
    private BlockPos alvo;      // bloco sendo quebrado
    private BlockPos destino;   // lugar para onde andar durante a escavação
    private boolean escavando;  // true se o alvo atual é só passagem (não é o que procuramos)
    private final Set<BlockPos> falhas = new HashSet<>();
    private final ArrayDeque<BlockPos> fila = new ArrayDeque<>();
    private int progresso;
    private int estagio = -1;
    private int tentativas;
    private int esperaBusca;
    private int tempoSemChegar;
    private int recalculos;
    private int semVisao;
    private int travados;

    public TarefaGoal(FuncionarioEntity funcionario) {
        this.f = funcionario;
        this.defesa = new DefesaLogica(funcionario);
        this.setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
    }

    @Override
    public boolean canUse() {
        return f.getTarefa() != Tarefa.PARAR;
    }

    @Override
    public boolean canContinueToUse() {
        return f.getTarefa() != Tarefa.PARAR;
    }

    @Override
    public void stop() {
        soltarAlvo();
        destino = null;
        f.getNavigation().stop();
        defesa.resetar();
        ultima = Tarefa.PARAR;
    }

    @Override
    public void tick() {
        Tarefa t = f.getTarefa();
        if (t != ultima) {
            ultima = t;
            soltarAlvo();
            destino = null;
            escavando = false;
            falhas.clear();
            fila.clear();
            tentativas = 0;
            esperaBusca = 0;
            tempoSemChegar = 0;
            recalculos = 0;
            semVisao = 0;
            travados = 0;
            defesa.resetar();
        }
        if (t.ehTrabalho() && defesa.revidarSeAtacado()) {
            return;
        }
        switch (t) {
            case SEGUIR -> seguir();
            case DEFENDER -> defesa.tick();
            case ENTREGAR -> entregar();
            case MADEIRA, PEDRA, MINERIO, COLHER -> trabalhar(t);
            default -> { }
        }
    }

    // ------------------------------------------------------------------ seguir / entregar

    private void irAte(Player dono, double velocidade) {
        if (f.getNavigation().isDone() || f.tickCount % 10 == 0) {
            f.getNavigation().moveTo(dono, velocidade);
        }
    }

    private void seguir() {
        Player dono = f.getDonoJogador();
        if (dono == null) return;
        double d2 = f.distanceToSqr(dono);
        if (d2 > 225.0D && f.teleportarParaDono(dono)) {
            return;
        }
        f.getLookControl().setLookAt(dono, 30.0F, 30.0F);
        if (d2 > 9.0D) {
            irAte(dono, 1.15D);
        } else {
            f.getNavigation().stop();
        }
    }

    private void entregar() {
        Player dono = f.getDonoJogador();
        if (dono == null) {
            f.falar(Falas.Situacao.LONGE);
            f.definirTarefa(Tarefa.PARAR);
            return;
        }
        double d2 = f.distanceToSqr(dono);
        if (d2 > 225.0D && f.teleportarParaDono(dono)) {
            return;
        }
        f.getLookControl().setLookAt(dono, 30.0F, 30.0F);
        if (d2 > 6.25D) {
            irAte(dono, 1.2D);
            return;
        }
        f.entregarItens(dono);
        f.falar(Falas.Situacao.ENTREGUEI);
        f.retomarOuParar();
    }

    // ------------------------------------------------------------------ trabalho

    private void trabalhar(Tarefa t) {
        Class<? extends Item> tipo = f.ferramentaPara(t);
        if (tipo != null) {
            if (f.acharFerramenta(tipo).isEmpty()) {
                f.falar(Falas.Situacao.FERRAMENTA_QUEBROU);
                f.definirTarefa(Tarefa.PARAR);
                return;
            }
            f.equipar(tipo);
        }

        if (alvo == null && destino == null) {
            if (--esperaBusca > 0) return;
            if (escolherProximo(t)) {
                tentativas = 0;
            } else {
                tentativas++;
                esperaBusca = 20;
                if (tentativas >= 3) {
                    f.falar(Falas.Situacao.NADA_ACHADO);
                    f.definirTarefa(Tarefa.PARAR);
                }
            }
            return;
        }
        if (alvo == null) {
            andar();
            return;
        }
        minerarAlvo(t);
    }

    /** Define o próximo alvo (ou destino). Devolve false se não há mais nada a fazer. */
    private boolean escolherProximo(Tarefa t) {
        Level nivel = f.level();

        // 0) blocos de passagem pendentes (parte da escada)
        while (!fila.isEmpty()) {
            BlockPos p = fila.poll();
            BlockState e = nivel.getBlockState(p);
            if (!falhas.contains(p) && !e.isAir() && naturalCavavel(e) && podeCavar(p, e)) {
                alvo = p;
                escavando = true;
                return true;
            }
        }

        // 1) o que procuramos, já exposto
        BlockPos exposto = buscarExposto(t);
        if (exposto != null) {
            alvo = exposto;
            escavando = false;
            return true;
        }

        // 2) madeira e colheita não escavam
        if (t != Tarefa.PEDRA && t != Tarefa.MINERIO) return false;

        // 3) escavar uma escada até o mais próximo
        return planejarEscavacao(t);
    }

    private BlockPos buscarExposto(Tarefa t) {
        Level nivel = f.level();
        BlockPos c = f.getCasa();
        int r = FuncionarioEntity.RAIO;
        BlockPos melhor = null;
        double melhorDist = Double.MAX_VALUE;
        for (BlockPos p : BlockPos.betweenClosed(c.offset(-r, -r, -r), c.offset(r, r, r))) {
            if (falhas.contains(p) || !nivel.hasChunkAt(p)) continue;
            BlockState estado = nivel.getBlockState(p);
            if (!valido(t, estado, p)) continue;
            double d = f.distanceToSqr(Vec3.atCenterOf(p));
            if (d < melhorDist) {
                melhorDist = d;
                melhor = p.immutable();
            }
        }
        return melhor;
    }

    private boolean planejarEscavacao(Tarefa t) {
        Level nivel = f.level();
        BlockPos pe = f.blockPosition();
        BlockPos meta = maisProximo(t, pe, 20, 24);
        if (meta == null) return false;

        int dx = meta.getX() - pe.getX();
        int dz = meta.getZ() - pe.getZ();
        Direction d;
        if (dx == 0 && dz == 0) {
            d = f.getDirTunel();
        } else if (Math.abs(dx) >= Math.abs(dz)) {
            d = dx >= 0 ? Direction.EAST : Direction.WEST;
        } else {
            d = dz >= 0 ? Direction.SOUTH : Direction.NORTH;
        }
        int passo = Integer.compare(meta.getY(), pe.getY()); // -1 desce, 0 reto, +1 sobe
        BlockPos frente = pe.relative(d);

        List<BlockPos> limpar = new ArrayList<>();
        BlockPos novoPe;
        if (passo < 0) {
            limpar.add(frente.above());
            limpar.add(frente);
            limpar.add(frente.below());
            novoPe = frente.below();
        } else if (passo > 0) {
            limpar.add(pe.above(2));
            limpar.add(frente.above());
            limpar.add(frente.above(2));
            novoPe = frente.above();
        } else {
            limpar.add(frente);
            limpar.add(frente.above());
            novoPe = frente;
        }

        List<BlockPos> sobrando = new ArrayList<>();
        for (BlockPos p : limpar) {
            BlockState e = nivel.getBlockState(p);
            boolean livre = e.getCollisionShape(nivel, p).isEmpty() && e.getFluidState().isEmpty();
            if (livre) continue;
            if (!naturalCavavel(e) || !podeCavar(p, e)) {
                // caminho bloqueado por algo que não devemos quebrar: tenta outra meta
                falhas.add(meta);
                esperaBusca = 5;
                return true;
            }
            sobrando.add(p.immutable());
        }
        if (sobrando.isEmpty()) {
            if (nivel.getBlockState(novoPe.below()).getCollisionShape(nivel, novoPe.below()).isEmpty()
                    && passo >= 0 && !nivel.getBlockState(novoPe.below()).getFluidState().isEmpty()) {
                falhas.add(meta);
                esperaBusca = 5;
                return true;
            }
            destino = novoPe.immutable();
            tempoSemChegar = 0;
            return true;
        }
        alvo = sobrando.get(0);
        escavando = true;
        for (int i = 1; i < sobrando.size(); i++) fila.add(sobrando.get(i));
        return true;
    }

    private BlockPos maisProximo(Tarefa t, BlockPos centro, int rh, int rv) {
        Level nivel = f.level();
        BlockPos melhor = null;
        double melhorD = Double.MAX_VALUE;
        for (BlockPos p : BlockPos.betweenClosed(centro.offset(-rh, -rv, -rh), centro.offset(rh, 8, rh))) {
            if (falhas.contains(p) || !nivel.hasChunkAt(p)) continue;
            BlockState e = nivel.getBlockState(p);
            boolean serve = t == Tarefa.MINERIO ? f.getMinerio().serve(e) : ehPedra(e);
            if (!serve || temFluidoPerto(p)) continue;
            double d = p.distSqr(centro);
            if (d < melhorD) {
                melhorD = d;
                melhor = p.immutable();
            }
        }
        return melhor;
    }

    private void andar() {
        Vec3 c = Vec3.atBottomCenterOf(destino);
        if (f.position().distanceToSqr(c) < 1.5D) {
            destino = null;
            travados = 0;
            return;
        }
        if (++tempoSemChegar > 200) {
            destino = null;
            if (++travados >= 4) {
                f.falar(Falas.Situacao.NADA_ACHADO);
                f.definirTarefa(Tarefa.PARAR);
            }
            return;
        }
        if (f.getNavigation().isDone() || f.tickCount % 20 == 0) {
            f.getNavigation().moveTo(c.x, c.y, c.z, 1.0D);
        }
    }

    private void minerarAlvo(Tarefa t) {
        Level nivel = f.level();
        BlockState estado = nivel.getBlockState(alvo);
        boolean ok = escavando
                ? (!estado.isAir() && naturalCavavel(estado) && podeCavar(alvo, estado))
                : valido(t, estado, alvo);
        if (!ok) {
            soltarAlvo();
            return;
        }

        Vec3 centro = Vec3.atCenterOf(alvo);
        f.getLookControl().setLookAt(centro.x, centro.y, centro.z);
        boolean perto = f.getEyePosition().distanceToSqr(centro) <= 16.0D;

        if (perto && veAlvo(alvo)) {
            f.getNavigation().stop();
            semVisao = 0;
            progresso++;
            f.swing(InteractionHand.MAIN_HAND);
            int total = tempoParaQuebrar(t, estado, alvo);
            int novoEstagio = Math.min(9, progresso * 10 / Math.max(1, total));
            if (novoEstagio != estagio) {
                estagio = novoEstagio;
                nivel.destroyBlockProgress(f.getId(), alvo, estagio);
            }
            if (progresso % 4 == 1) {
                nivel.playSound(null, alvo, estado.getSoundType().getHitSound(), SoundSource.BLOCKS, 0.6F, 0.8F);
            }
            if (progresso >= total) {
                BlockPos quebrado = alvo;
                soltarAlvo();
                boolean cheio = f.quebrar(quebrado, t);
                if (cheio) {
                    f.falar(Falas.Situacao.INV_CHEIO);
                    f.definirTarefa(Tarefa.ENTREGAR);
                }
            }
            return;
        }

        // ainda não alcança ou não enxerga o bloco: chega mais perto
        progresso = 0;
        limparRachadura();
        if (perto && ++semVisao > 40) {
            falharAlvo();
            return;
        }
        if (++tempoSemChegar > 400) {
            falharAlvo();
            return;
        }
        if (f.getNavigation().isDone()) {
            if (recalculos++ >= 3) {
                falharAlvo();
                return;
            }
            Path caminho = f.getNavigation().createPath(alvo, 1);
            if (caminho == null) {
                falharAlvo();
                return;
            }
            f.getNavigation().moveTo(caminho, 1.0D);
        }
    }

    // ------------------------------------------------------------------ auxiliares

    private void falharAlvo() {
        falhas.add(alvo);
        soltarAlvo();
    }

    private void soltarAlvo() {
        limparRachadura();
        alvo = null;
        progresso = 0;
        tempoSemChegar = 0;
        recalculos = 0;
        semVisao = 0;
    }

    private void limparRachadura() {
        if (alvo != null && estagio >= 0) {
            f.level().destroyBlockProgress(f.getId(), alvo, -1);
        }
        estagio = -1;
    }

    /** Linha de visão: o primeiro bloco que o olhar do funcionário encontra tem de ser o próprio alvo. */
    private boolean veAlvo(BlockPos pos) {
        Vec3 olho = f.getEyePosition();
        Vec3 centro = Vec3.atCenterOf(pos);
        BlockHitResult r = f.level().clip(new ClipContext(olho, centro,
                ClipContext.Block.OUTLINE, ClipContext.Fluid.NONE, f));
        return r.getType() == HitResult.Type.MISS || r.getBlockPos().equals(pos);
    }

    /** Ticks para quebrar o bloco, usando a velocidade real da ferramenta na mão (igual ao jogador). */
    private int tempoParaQuebrar(Tarefa t, BlockState estado, BlockPos pos) {
        if (t == Tarefa.COLHER) return 8;
        float dureza = estado.getDestroySpeed(f.level(), pos);
        if (dureza <= 0.0F) return 1;
        ItemStack ferramenta = f.getMainHandItem();
        float velocidade = ferramenta.isEmpty() ? 1.0F : ferramenta.getDestroySpeed(estado);
        if (velocidade > 1.0F) {
            int eficiencia = EnchantmentHelper.getBlockEfficiency(f);
            if (eficiencia > 0) velocidade += eficiencia * eficiencia + 1;
        }
        boolean ferramentaCerta = !estado.requiresCorrectToolForDrops() || ferramenta.isCorrectToolForDrops(estado);
        float danoPorTick = velocidade / dureza / (ferramentaCerta ? 30.0F : 100.0F);
        return Mth.clamp((int) Math.ceil(1.0F / danoPorTick), 1, 400);
    }

    private boolean valido(Tarefa t, BlockState estado, BlockPos pos) {
        return switch (t) {
            case MADEIRA -> estado.is(BlockTags.LOGS);
            case PEDRA -> ehPedra(estado) && exposto(pos);
            case MINERIO -> f.getMinerio().serve(estado) && exposto(pos);
            case COLHER -> estado.getBlock() instanceof CropBlock c && c.isMaxAge(estado);
            default -> false;
        };
    }

    private boolean ehPedra(BlockState estado) {
        return estado.is(BlockTags.BASE_STONE_OVERWORLD)
                || estado.is(Tags.Blocks.ORES)
                || estado.is(Tags.Blocks.COBBLESTONE);
    }

    /** Terreno natural que pode ser atravessado na escavação (nunca paredes de casa, madeira, tijolo...). */
    private boolean naturalCavavel(BlockState estado) {
        return estado.is(BlockTags.BASE_STONE_OVERWORLD)
                || estado.is(BlockTags.DIRT)
                || estado.is(BlockTags.SAND)
                || estado.is(Tags.Blocks.GRAVEL)
                || estado.is(Tags.Blocks.SANDSTONE)
                || estado.is(Tags.Blocks.ORES);
    }

    /** Sem bloco-entidade (baú etc.), com dureza normal e sem água/lava encostada. */
    private boolean podeCavar(BlockPos pos, BlockState estado) {
        Level nivel = f.level();
        if (estado.isAir() || !estado.getFluidState().isEmpty()) return false;
        if (estado.getDestroySpeed(nivel, pos) < 0.0F || estado.getBlock() instanceof EntityBlock) return false;
        return !temFluidoPerto(pos);
    }

    private boolean temFluidoPerto(BlockPos pos) {
        Level nivel = f.level();
        for (Direction d : Direction.values()) {
            if (!nivel.getBlockState(pos.relative(d)).getFluidState().isEmpty()) return true;
        }
        return false;
    }

    /** O bloco precisa ter pelo menos uma face livre e nenhum líquido encostado. */
    private boolean exposto(BlockPos pos) {
        Level nivel = f.level();
        boolean livre = false;
        for (Direction d : Direction.values()) {
            BlockPos vizinho = pos.relative(d);
            BlockState e = nivel.getBlockState(vizinho);
            if (!e.getFluidState().isEmpty()) return false;
            if (e.getCollisionShape(nivel, vizinho).isEmpty()) livre = true;
        }
        return livre;
    }
}
