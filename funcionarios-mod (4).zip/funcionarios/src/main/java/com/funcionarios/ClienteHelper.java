package com.funcionarios;

import com.mojang.logging.LogUtils;
import com.mojang.text2speech.Narrator;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.Entity;
import org.slf4j.Logger;

/** Chamadas que só existem no cliente (telas e voz). Fica separado para o servidor não carregar essas classes. */
public final class ClienteHelper {
    private static final Logger LOG = LogUtils.getLogger();
    private static Narrator narrador;
    private static boolean narradorFalhou;
    private static long ultimaFala = -1000;

    private ClienteHelper() {}

    public static void abrirCentral() {
        Minecraft.getInstance().setScreen(new CentralScreen());
    }

    public static void atualizar(List<PacoteLista.Entrada> lista) {
        if (Minecraft.getInstance().screen instanceof CentralScreen tela) {
            tela.atualizar(lista);
        }
    }

    /**
     * Lê a frase em voz alta com a voz do sistema (a mesma do narrador do Minecraft).
     * Só fala se o funcionário estiver perto e sem atropelar a frase anterior.
     */
    public static void falar(int idEntidade, String texto) {
        if (narradorFalhou || !Configuracao.VOZ_ATIVA.get()) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null) return;
        Entity e = mc.level.getEntity(idEntidade);
        if (e == null) return;
        double max = Configuracao.VOZ_DISTANCIA.get();
        if (e.distanceToSqr(mc.player) > max * max) return;
        long agora = mc.level.getGameTime();
        if (agora - ultimaFala < 20) return;
        ultimaFala = agora;
        try {
            if (narrador == null) {
                narrador = Narrator.getNarrator();
            }
            if (narrador.active()) {
                narrador.say(texto, false);
            } else {
                narradorFalhou = true;
                LOG.warn("[Funcionarios] Sem voz do sistema disponível: os funcionários só vão escrever as falas.");
            }
        } catch (Throwable t) {
            narradorFalhou = true;
            LOG.warn("[Funcionarios] Não foi possível usar a voz do sistema.", t);
        }
    }
}
