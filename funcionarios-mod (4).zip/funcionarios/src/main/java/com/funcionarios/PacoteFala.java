package com.funcionarios;

import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

/** Servidor -> cliente do dono: o funcionário falou uma frase (o cliente lê em voz alta). */
public class PacoteFala {
    private final int entidade;
    private final String texto;

    public PacoteFala(int entidade, String texto) {
        this.entidade = entidade;
        this.texto = texto;
    }

    public void codificar(FriendlyByteBuf buf) {
        buf.writeInt(entidade);
        buf.writeUtf(texto);
    }

    public static PacoteFala decodificar(FriendlyByteBuf buf) {
        return new PacoteFala(buf.readInt(), buf.readUtf());
    }

    public static void tratar(PacoteFala pacote, Supplier<NetworkEvent.Context> contexto) {
        contexto.get().enqueueWork(() ->
                DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ClienteHelper.falar(pacote.entidade, pacote.texto)));
        contexto.get().setPacketHandled(true);
    }
}
