package com.funcionarios;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.inventory.Slot;

/** Tela do Baú do Funcionário, com barra de rolagem (roda do mouse ou arrastar) quando o baú é grande. */
public class BauFuncionarioScreen extends AbstractContainerScreen<BauFuncionarioMenu> {
    private boolean arrastando;

    public BauFuncionarioScreen(BauFuncionarioMenu menu, Inventory inventario, Component titulo) {
        super(menu, inventario, titulo);
        this.imageWidth = menu.getLargura();
        this.imageHeight = menu.getAltura();
        this.titleLabelY = 6;
    }

    private boolean temBarra() {
        return this.menu.getMaxRolagem() > 0;
    }

    private int barraX() {
        return this.leftPos + this.menu.getXBaus() + this.menu.getColunas() * 18 + 3;
    }

    private int barraY() {
        return this.topPos + BauFuncionarioMenu.TOPO;
    }

    private int barraAltura() {
        return this.menu.getLinhasVisiveis() * 18;
    }

    private int alturaPolegar() {
        return Math.max(14, barraAltura() * this.menu.getLinhasVisiveis() / this.menu.getLinhasTotais());
    }

    /** Muda a rolagem aqui e avisa o servidor (o servidor reenvia o conteúdo da nova janela). */
    private void aplicar(int nova) {
        int r = Mth.clamp(nova, 0, this.menu.getMaxRolagem());
        if (r == this.menu.getRolagem()) return;
        this.menu.setRolagem(r);
        if (this.minecraft != null && this.minecraft.gameMode != null) {
            this.minecraft.gameMode.handleInventoryButtonClick(this.menu.containerId, r);
        }
    }

    private void rolarPeloMouse(double mouseY) {
        int livre = barraAltura() - alturaPolegar();
        if (livre <= 0) return;
        double rel = (mouseY - barraY() - alturaPolegar() / 2.0D) / livre;
        aplicar((int) Math.round(rel * this.menu.getMaxRolagem()));
    }

    @Override
    public boolean mouseScrolled(double x, double y, double delta) {
        if (temBarra()) {
            aplicar(this.menu.getRolagem() - (int) Math.signum(delta));
            return true;
        }
        return super.mouseScrolled(x, y, delta);
    }

    @Override
    public boolean mouseClicked(double x, double y, int botao) {
        if (botao == 0 && temBarra() && x >= barraX() - 2 && x <= barraX() + 10
                && y >= barraY() && y <= barraY() + barraAltura()) {
            arrastando = true;
            rolarPeloMouse(y);
            return true;
        }
        return super.mouseClicked(x, y, botao);
    }

    @Override
    public boolean mouseDragged(double x, double y, int botao, double dx, double dy) {
        if (arrastando) {
            rolarPeloMouse(y);
            return true;
        }
        return super.mouseDragged(x, y, botao, dx, dy);
    }

    @Override
    public boolean mouseReleased(double x, double y, int botao) {
        arrastando = false;
        return super.mouseReleased(x, y, botao);
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float parcial) {
        this.renderBackground(g);
        super.render(g, mouseX, mouseY, parcial);
        this.renderTooltip(g, mouseX, mouseY);
    }

    @Override
    protected void renderLabels(GuiGraphics g, int mouseX, int mouseY) {
        g.drawString(this.font, this.title, 8, this.titleLabelY, 0x404040, false);
        g.drawString(this.font, this.playerInventoryTitle, this.menu.getInvX(), this.menu.getInvY() - 11, 0x404040, false);
    }

    @Override
    protected void renderBg(GuiGraphics g, float parcial, int mouseX, int mouseY) {
        g.fill(this.leftPos - 1, this.topPos - 1, this.leftPos + this.imageWidth + 1, this.topPos + this.imageHeight + 1, 0xFF000000);
        g.fill(this.leftPos, this.topPos, this.leftPos + this.imageWidth, this.topPos + this.imageHeight, 0xFFC6C6C6);
        for (Slot s : this.menu.slots) {
            int sx = this.leftPos + s.x;
            int sy = this.topPos + s.y;
            g.fill(sx - 1, sy - 1, sx + 17, sy + 17, 0xFF373737);
            g.fill(sx, sy, sx + 17, sy + 17, 0xFFFFFFFF);
            g.fill(sx, sy, sx + 16, sy + 16, 0xFF8B8B8B);
        }
        if (temBarra()) {
            int bx = barraX();
            int by = barraY();
            g.fill(bx, by, bx + 8, by + barraAltura(), 0xFF555555);
            int livre = barraAltura() - alturaPolegar();
            int py = by + (this.menu.getMaxRolagem() == 0 ? 0 : livre * this.menu.getRolagem() / this.menu.getMaxRolagem());
            g.fill(bx + 1, py + 1, bx + 7, py + alturaPolegar() - 1, arrastando ? 0xFFE0E0E0 : 0xFFB0B0B0);
        }
    }
}
