package com.funcionarios;

import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;

/** Clique direito: abre a Central, com a lista dos seus funcionários e o botão de chamar de volta. */
public class CentralItem extends Item {
    public CentralItem(Properties propriedades) {
        super(propriedades);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level nivel, Player jogador, InteractionHand mao) {
        if (nivel.isClientSide) {
            DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> ClienteHelper::abrirCentral);
        }
        return InteractionResultHolder.sidedSuccess(jogador.getItemInHand(mao), nivel.isClientSide);
    }
}
