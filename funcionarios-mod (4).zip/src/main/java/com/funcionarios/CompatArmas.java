package com.funcionarios;

import com.mojang.logging.LogUtils;
import java.lang.reflect.Method;
import java.util.function.Supplier;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.fml.ModList;
import org.slf4j.Logger;

/**
 * Compatibilidade OPCIONAL com o mod de armas TACZ (modid "tacz").
 *
 * Tudo é feito por reflexão, então o mod compila e roda sem o TACZ instalado.
 * Se o TACZ não estiver presente (ou a API for diferente do esperado), os funcionários
 * simplesmente não usam armas de fogo e usam espada/machado.
 *
 * ATENÇÃO: os nomes abaixo foram montados a partir da documentação pública do TACZ e
 * ainda NÃO foram testados com o jogo. Se algo falhar, o motivo aparece no log do jogo
 * (procure por "CompatArmas").
 */
public final class CompatArmas {
    private static final Logger LOG = LogUtils.getLogger();
    private static final int MAX_FALHAS = 5;

    private static boolean iniciado;
    private static boolean disponivel;
    private static int falhas;

    private static Class<?> classeIGun;
    private static Method mFromLiving;
    private static Method mShoot;
    private static Method mAim;
    private static Method mReload;
    private static Method mDraw;     // opcional
    private static Method mBolt;     // opcional
    private static Method mMunicao;  // opcional
    private static Method mDataHolder; // opcional (versões novas pedem um carimbo de tempo no tiro)
    private static boolean shootComTempo;
    private static String erro;
    private static java.lang.reflect.Field campoBase;
    private static boolean campoBaseBuscado;

    private CompatArmas() {}

    public static synchronized boolean disponivel() {
        if (!iniciado) {
            iniciado = true;
            iniciar();
        }
        return disponivel;
    }

    private static void iniciar() {
        if (!ModList.get().isLoaded("tacz")) {
            return;
        }
        try {
            classeIGun = Class.forName("com.tacz.guns.api.item.IGun");
            Class<?> operador = Class.forName("com.tacz.guns.api.entity.IGunOperator");
            mFromLiving = operador.getMethod("fromLivingEntity", LivingEntity.class);
            // o TACZ mudou a assinatura do tiro entre versões: shoot(pitch, yaw) e shoot(pitch, yaw, tempo)
            mShoot = achar(operador, "shoot", 3);
            shootComTempo = mShoot != null;
            if (mShoot == null) mShoot = achar(operador, "shoot", 2);
            if (mShoot == null) throw new NoSuchMethodException("IGunOperator.shoot não encontrado");
            mAim = achar(operador, "aim", 1);
            mReload = achar(operador, "reload", 0);
            if (mAim == null || mReload == null) throw new NoSuchMethodException("aim/reload não encontrados");
            mDraw = achar(operador, "draw", 1);
            mBolt = achar(operador, "bolt", 0);
            mDataHolder = achar(operador, "getDataHolder", 0);
            mMunicao = metodoOpcional(classeIGun, "getCurrentAmmoCount", ItemStack.class);
            disponivel = true;
            LOG.info("[CompatArmas] TACZ encontrado: funcionários vão poder usar armas de fogo.");
        } catch (ReflectiveOperationException | LinkageError e) {
            erro = "TACZ instalado, mas a API não bateu (" + e + "). Armas de fogo desativadas.";
            LOG.warn("[CompatArmas] TACZ está instalado, mas a API não bateu com o esperado. "
                    + "Armas de fogo desativadas.", e);
        }
    }

    /** Motivo de as armas de fogo não estarem funcionando (null se estiver tudo certo ou o TACZ não existe). */
    public static String erro() {
        disponivel();
        return erro;
    }

    private static Method achar(Class<?> classe, String nome, int parametros) {
        for (Method m : classe.getMethods()) {
            if (m.getName().equals(nome) && m.getParameterCount() == parametros) return m;
        }
        return null;
    }

    /** Carimbo de tempo que as versões novas do TACZ esperam no tiro (ms desde a base do atirador). */
    private static long carimbo(Object op) {
        long agora = System.currentTimeMillis();
        if (mDataHolder == null) return agora;
        try {
            Object holder = mDataHolder.invoke(op);
            if (holder == null) return agora;
            if (!campoBaseBuscado) {
                campoBaseBuscado = true;
                try {
                    campoBase = holder.getClass().getField("baseTimestamp");
                } catch (NoSuchFieldException e) {
                    campoBase = null;
                }
            }
            if (campoBase != null) return agora - campoBase.getLong(holder);
        } catch (ReflectiveOperationException | RuntimeException e) {
            // cai no tempo atual
        }
        return agora;
    }

    private static Method metodoOpcional(Class<?> classe, String nome, Class<?>... parametros) {
        try {
            return classe.getMethod(nome, parametros);
        } catch (NoSuchMethodException e) {
            LOG.info("[CompatArmas] método opcional '{}' não existe nesta versão do TACZ.", nome);
            return null;
        }
    }

    public static boolean ehArma(ItemStack pilha) {
        return disponivel() && !pilha.isEmpty() && classeIGun.isInstance(pilha.getItem());
    }

    /** Munição atual dentro da arma, ou -1 se não for possível saber. */
    public static int municao(ItemStack arma) {
        if (!ehArma(arma) || mMunicao == null) return -1;
        try {
            Object r = mMunicao.invoke(arma.getItem(), arma);
            return r instanceof Integer i ? i : -1;
        } catch (ReflectiveOperationException | RuntimeException e) {
            registrarFalha(e);
            return -1;
        }
    }

    /** Avisa o TACZ de qual item o funcionário está segurando. */
    public static void sacar(LivingEntity entidade) {
        if (!disponivel() || mDraw == null) return;
        try {
            Supplier<ItemStack> mao = entidade::getMainHandItem;
            mDraw.invoke(operador(entidade), mao);
        } catch (ReflectiveOperationException | RuntimeException e) {
            registrarFalha(e);
        }
    }

    public static void mirar(LivingEntity entidade, boolean mirando) {
        if (!disponivel()) return;
        try {
            mAim.invoke(operador(entidade), mirando);
        } catch (ReflectiveOperationException | RuntimeException e) {
            registrarFalha(e);
        }
    }

    /** Dispara. Devolve o resultado do TACZ (ex.: SUCCESS, NOT_DRAW, COOL_DOWN, NO_AMMO) ou null se falhou. */
    public static String atirar(LivingEntity entidade, float pitch, float yaw) {
        if (!disponivel()) return null;
        try {
            Supplier<Float> p = () -> pitch;
            Supplier<Float> y = () -> yaw;
            Object op = operador(entidade);
            Object r = shootComTempo ? mShoot.invoke(op, p, y, carimbo(op)) : mShoot.invoke(op, p, y);
            return String.valueOf(r);
        } catch (ReflectiveOperationException | RuntimeException e) {
            registrarFalha(e);
            return null;
        }
    }

    /** Enche o pente da arma (e põe bala na agulha) quando não há munição para recarregar. Devolve true se conseguiu. */
    public static boolean encherPente(ItemStack arma) {
        if (!ehArma(arma)) return false;
        try {
            Method set = classeIGun.getMethod("setCurrentAmmoCount", ItemStack.class, int.class);
            set.invoke(arma.getItem(), arma, 30);
            try {
                Method barril = classeIGun.getMethod("setBulletInBarrel", ItemStack.class, boolean.class);
                barril.invoke(arma.getItem(), arma, true);
            } catch (NoSuchMethodException ignorado) {
                // versão sem bala na agulha
            }
            return true;
        } catch (ReflectiveOperationException | RuntimeException e) {
            registrarFalha(e);
            return false;
        }
    }

    /** Puxa o ferrolho / coloca bala na agulha (armas que pedem NEED_BOLT). */
    public static void ferrolho(LivingEntity entidade) {
        if (!disponivel() || mBolt == null) return;
        try {
            mBolt.invoke(operador(entidade));
        } catch (ReflectiveOperationException | RuntimeException e) {
            registrarFalha(e);
        }
    }

    public static void recarregar(LivingEntity entidade) {
        if (!disponivel()) return;
        try {
            mReload.invoke(operador(entidade));
        } catch (ReflectiveOperationException | RuntimeException e) {
            registrarFalha(e);
        }
    }

    private static Object operador(LivingEntity entidade) throws ReflectiveOperationException {
        return mFromLiving.invoke(null, entidade);
    }

    private static void registrarFalha(Exception e) {
        falhas++;
        LOG.warn("[CompatArmas] erro ao falar com o TACZ ({}/{}).", falhas, MAX_FALHAS, e);
        if (falhas >= MAX_FALHAS) {
            disponivel = false;
            LOG.warn("[CompatArmas] muitos erros seguidos: armas de fogo desativadas até reiniciar o jogo.");
        }
    }
}
