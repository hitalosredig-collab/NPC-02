package com.funcionarios;

import java.util.List;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.AxeItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.common.ToolActions;

/** Combate do funcionário: comando "Me defender" e revide quando ele é atacado trabalhando. */
public class DefesaLogica {
    private static final double DIST_MAX_TIRO = 24.0D;

    private final FuncionarioEntity f;
    private LivingEntity alvo;
    private int espera;
    private int ultimaRecarga = -1000;
    private int falhasMunicao;
    private boolean semMunicao;
    private boolean mirando;
    private boolean emRevide;
    private ItemStack armaSacada = ItemStack.EMPTY;
    private int ultimoSaque = -1000;

    public DefesaLogica(FuncionarioEntity funcionario) {
        this.f = funcionario;
    }

    public void resetar() {
        if (mirando) {
            CompatArmas.mirar(f, false);
        }
        if (f.isUsingItem()) {
            f.stopUsingItem();
        }
        alvo = null;
        espera = 0;
        ultimaRecarga = -1000;
        falhasMunicao = 0;
        semMunicao = false;
        mirando = false;
        emRevide = false;
        armaSacada = ItemStack.EMPTY;
    }

    // ------------------------------------------------------------------ comando "Me defender"

    public void tick() {
        Player dono = f.getDonoJogador();
        if (dono == null) return;
        if (espera > 0) espera--;

        alvo = escolherAlvo(dono);
        if (alvo == null) {
            parouDeMirar();
            usarEscudo(false);
            acompanhar(dono);
            return;
        }
        lutar();
    }

    // ------------------------------------------------------------------ revide durante o trabalho

    /** Se algum monstro atacou o funcionário há pouco, ele para o trabalho e revida (se tiver arma). */
    public boolean revidarSeAtacado() {
        if (espera > 0) espera--;
        LivingEntity agressor = f.getLastHurtByMob();
        boolean deveRevidar = agressor != null && agressor.isAlive() && !(agressor instanceof Player)
                && !(agressor instanceof FuncionarioEntity)
                && f.tickCount - f.getLastHurtByMobTimestamp() <= 100 && f.temArmaParaDefender();
        if (!deveRevidar) {
            if (emRevide) {
                emRevide = false;
                parouDeMirar();
                usarEscudo(false);
            }
            return false;
        }
        emRevide = true;
        alvo = agressor;
        lutar();
        return true;
    }

    // ------------------------------------------------------------------ luta

    private void lutar() {
        f.getLookControl().setLookAt(alvo, 30.0F, 30.0F);

        if (!semMunicao && f.temArmaDeFogo() && f.equipar(CompatArmas::ehArma)) {
            usarEscudo(false);
            aDistancia();
            return;
        }
        parouDeMirar();
        if (!avisouTacz && CompatArmas.erro() != null) {
            avisouTacz = true;
            avisarDono("não funcionou: " + CompatArmas.erro());
        }
        if (f.equipar(s -> s.getItem() instanceof SwordItem) || f.equipar(s -> s.getItem() instanceof AxeItem)) {
            corpoACorpo();
            return;
        }
        if (semMunicao) {
            f.getNavigation().stop();
            return;
        }
        f.falar(Falas.Situacao.SEM_ARMA);
        f.definirTarefa(Tarefa.PARAR);
    }

    private LivingEntity escolherAlvo(Player dono) {
        if (alvo != null && alvo.isAlive() && f.tickCount % 10 != 0) return alvo;

        LivingEntity agressor = dono.getLastHurtByMob();
        if (valido(agressor) && dono.tickCount - dono.getLastHurtByMobTimestamp() < 200) return agressor;

        LivingEntity atacado = dono.getLastHurtMob();
        if (valido(atacado) && atacado instanceof Enemy
                && dono.tickCount - dono.getLastHurtMobTimestamp() < 200) return atacado;

        List<Mob> lista = f.level().getEntitiesOfClass(Mob.class, dono.getBoundingBox().inflate(12.0D),
                m -> m instanceof Enemy && m.isAlive() && m != f);
        LivingEntity melhor = null;
        double melhorDist = Double.MAX_VALUE;
        for (Mob m : lista) {
            double d = m.distanceToSqr(dono);
            if (d < melhorDist) {
                melhorDist = d;
                melhor = m;
            }
        }
        return melhor;
    }

    private boolean valido(LivingEntity e) {
        return e != null && e.isAlive() && e != f && !(e instanceof FuncionarioEntity) && !(e instanceof Player);
    }

    // ------------------------------------------------------------------ escudo

    /** Levanta ou abaixa o escudo da mão secundária. */
    private void usarEscudo(boolean levantar) {
        ItemStack segundaMao = f.getOffhandItem();
        boolean temEscudo = !segundaMao.isEmpty() && segundaMao.canPerformAction(ToolActions.SHIELD_BLOCK);
        if (levantar && temEscudo) {
            if (!f.isUsingItem()) {
                f.startUsingItem(InteractionHand.OFF_HAND);
            }
        } else if (f.isUsingItem()) {
            f.stopUsingItem();
        }
    }

    // ------------------------------------------------------------------ movimento

    private void aproximar() {
        if (f.getNavigation().isDone() || f.tickCount % 10 == 0) {
            f.getNavigation().moveTo(alvo, 1.2D);
        }
    }

    private void acompanhar(Player dono) {
        double d2 = f.distanceToSqr(dono);
        if (d2 > 225.0D) {
            f.teleportarParaDono(dono);
        } else if (d2 > 36.0D) {
            if (f.getNavigation().isDone() || f.tickCount % 10 == 0) {
                f.getNavigation().moveTo(dono, 1.15D);
            }
        } else {
            f.getNavigation().stop();
        }
    }

    // ------------------------------------------------------------------ corpo a corpo

    private void corpoACorpo() {
        usarEscudo(f.distanceToSqr(alvo) < 49.0D);
        float largura = f.getBbWidth() * 2.0F;
        double alcance = largura * largura + alvo.getBbWidth() + 1.0D;
        if (f.distanceToSqr(alvo) <= alcance && f.hasLineOfSight(alvo)) {
            f.getNavigation().stop();
            if (espera <= 0) {
                espera = 20;
                f.swing(InteractionHand.MAIN_HAND);
                f.doHurtTarget(alvo);
                ItemStack arma = f.getMainHandItem();
                arma.hurtAndBreak(1, f, e -> e.broadcastBreakEvent(EquipmentSlot.MAINHAND));
            }
        } else {
            aproximar();
        }
    }

    // ------------------------------------------------------------------ arma de fogo

    private int ultimoAvisoTiro = -1000;
    private boolean avisouTacz;

    private void avisarDono(String texto) {
        if (!Configuracao.MENSAGENS) return;
        Player dono = f.getDonoJogador();
        if (dono != null) dono.sendSystemMessage(net.minecraft.network.chat.Component.literal("[Funcionário] TACZ " + texto));
    }

    private void parouDeMirar() {
        if (mirando) {
            CompatArmas.mirar(f, false);
            mirando = false;
        }
    }

    private void aDistancia() {
        ItemStack arma = f.getMainHandItem();
        // saca UMA vez por arma (compara o tipo do item: a munição muda o NBT a cada tiro e reiniciaria o saque)
        if (armaSacada.isEmpty() || armaSacada.getItem() != arma.getItem()) {
            CompatArmas.sacar(f);
            armaSacada = arma;
            ultimoSaque = f.tickCount;
        }

        int municao = CompatArmas.municao(arma);
        if (municao == 0 && CompatArmas.encherPente(arma)) {
            municao = -1; // munição infinita: pente cheio, segue atirando
        }
        if (municao == 0) {
            parouDeMirar();
            if (f.tickCount - ultimaRecarga >= 80) {
                if (falhasMunicao >= 1) {
                    // sem munição para recarregar: enche o pente (munição infinita) e continua atirando
                    if (CompatArmas.encherPente(arma)) {
                        falhasMunicao = 0;
                        return;
                    }
                    if (falhasMunicao >= 3) {
                        semMunicao = true;
                        f.falar(Falas.Situacao.SEM_MUNICAO);
                        return;
                    }
                }
                CompatArmas.recarregar(f);
                ultimaRecarga = f.tickCount;
                falhasMunicao++;
            }
            return;
        }
        falhasMunicao = 0;

        double d2 = f.distanceToSqr(alvo);
        boolean visivel = f.hasLineOfSight(alvo);
        if (!visivel || d2 > DIST_MAX_TIRO * DIST_MAX_TIRO) {
            parouDeMirar();
            aproximar();
            return;
        }
        f.getNavigation().stop();
        if (!mirando) {
            CompatArmas.mirar(f, true);
            mirando = true;
        }
        if (f.tickCount % 2 == 0) {
            Vec3 olho = f.getEyePosition();
            Vec3 ponto = alvo.position().add(0.0D, alvo.getBbHeight() * 0.6D, 0.0D);
            double dx = ponto.x - olho.x;
            double dy = ponto.y - olho.y;
            double dz = ponto.z - olho.z;
            double h = Math.sqrt(dx * dx + dz * dz);
            float yaw = (float) (Mth.atan2(dz, dx) * (180.0D / Math.PI)) - 90.0F;
            float pitch = (float) -(Mth.atan2(dy, h) * (180.0D / Math.PI));
            f.setYRot(yaw);
            f.setYHeadRot(yaw);
            f.setYBodyRot(yaw);
            f.setXRot(pitch);
            String resultado = CompatArmas.atirar(f, pitch, yaw);
            if (resultado != null && resultado.contains("NOT_DRAW")) {
                // ainda sacando (ou saque perdido): só repete o saque depois de 3 s, senão o saque nunca termina
                if (f.tickCount - ultimoSaque > 60) {
                    CompatArmas.sacar(f);
                    ultimoSaque = f.tickCount;
                }
            } else if (resultado != null && resultado.contains("NEED_BOLT")) {
                CompatArmas.ferrolho(f);
            } else if (resultado != null && resultado.contains("NO_AMMO")) {
                if (!CompatArmas.encherPente(arma)) CompatArmas.recarregar(f);
            }
            if (resultado != null && !resultado.equals("SUCCESS") && f.tickCount - ultimoAvisoTiro > 100) {
                ultimoAvisoTiro = f.tickCount;
                com.mojang.logging.LogUtils.getLogger().info("[Funcionarios] TACZ tiro: {}", resultado);
                avisarDono("tiro: " + resultado);
            }
        }
    }
}
