package com.funcionarios;

import java.util.function.Predicate;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.Container;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.InventoryMenu;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.AxeItem;
import net.minecraft.world.item.HoeItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.PickaxeItem;
import net.minecraft.world.item.ShovelItem;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.TridentItem;
import net.minecraftforge.common.ToolActions;

/**
 * Slots, na ordem:
 * 0-26 inventário dele (baú), 27-62 inventário do jogador, 63-67 equipamento (capacete, peitoral,
 * calça, bota, escudo) e 68-73 armas e ferramentas (2 armas, picareta, machado, pá, enxada).
 */
public class FuncionarioMenu extends AbstractContainerMenu {
    private static final int SLOTS_FUNC = 27;
    private static final int INICIO_JOGADOR = 27;
    private static final int INICIO_EQUIP = 63;
    public static final int INICIO_FERR = 68;
    private static final int TOTAL = 75;

    // janela compacta (176 de largura, como um baú duplo): equipamento e ferramentas em linhas no topo
    public static final int EQ_Y = 22;
    public static final int FERR_Y = 42;
    public static final int BAU_X = 8;
    public static final int BAU_Y = 64;
    public static final int INV_X = 8;
    public static final int INV_Y = 134;
    public static final int HOT_Y = 192;

    /** Aba aberta na tela (só no cliente): com os comandos abertos, os slots ficam escondidos. */
    public boolean abaComandos;

    private static final ResourceLocation[] ICONES = {
            InventoryMenu.EMPTY_ARMOR_SLOT_HELMET, InventoryMenu.EMPTY_ARMOR_SLOT_CHESTPLATE,
            InventoryMenu.EMPTY_ARMOR_SLOT_LEGGINGS, InventoryMenu.EMPTY_ARMOR_SLOT_BOOTS,
            InventoryMenu.EMPTY_ARMOR_SLOT_SHIELD
    };

    private final FuncionarioEntity funcionario;

    /** Construtor usado no cliente (lê o id da entidade enviado pelo servidor). */
    public FuncionarioMenu(int id, Inventory inventarioJogador, FriendlyByteBuf buf) {
        this(id, inventarioJogador, (FuncionarioEntity) inventarioJogador.player.level().getEntity(buf.readInt()));
    }

    public FuncionarioMenu(int id, Inventory inventarioJogador, FuncionarioEntity funcionario) {
        super(Registros.MENU.get(), id);
        this.funcionario = funcionario;
        Container bau = funcionario.getInventario();
        checkContainerSize(bau, SLOTS_FUNC);
        bau.startOpen(inventarioJogador.player);

        // 0..26: inventário do funcionário (estilo baú)
        for (int linha = 0; linha < 3; linha++) {
            for (int col = 0; col < 9; col++) {
                this.addSlot(new SlotAba(bau, col + linha * 9, BAU_X + col * 18, BAU_Y + linha * 18));
            }
        }
        // 27..62: inventário do jogador
        for (int linha = 0; linha < 3; linha++) {
            for (int col = 0; col < 9; col++) {
                this.addSlot(new SlotAba(inventarioJogador, col + linha * 9 + 9, INV_X + col * 18, INV_Y + linha * 18));
            }
        }
        for (int col = 0; col < 9; col++) {
            this.addSlot(new SlotAba(inventarioJogador, col, INV_X + col * 18, HOT_Y));
        }
        // 63..67: capacete, peitoral, calça, bota e escudo (com os ícones vazios do jogo)
        Container equipamento = new EquipamentoContainer(funcionario);
        for (int i = 0; i < EquipamentoContainer.SLOTS.length; i++) {
            Slot slot = new SlotEquipamento(equipamento, i, 8 + i * 18, EQ_Y,
                    EquipamentoContainer.SLOTS[i], funcionario);
            slot.setBackground(InventoryMenu.BLOCK_ATLAS, ICONES[i]);
            this.addSlot(slot);
        }
        // 68..73: armas e ferramentas
        Container ferramentas = funcionario.getFerramentas();
        for (int i = 0; i < 7; i++) {
            this.addSlot(new SlotRestrito(ferramentas, i, 8 + i * 18, FERR_Y, regra(i)));
        }
    }

    public static Predicate<ItemStack> regra(int i) {
        return switch (i) {
            case 0, 1 -> s -> s.getItem() instanceof SwordItem || s.getItem() instanceof AxeItem
                    || s.getItem() instanceof TridentItem || s.canPerformAction(ToolActions.SWORD_SWEEP)
                    || CompatArmas.ehArma(s);
            case 2 -> s -> s.getItem() instanceof PickaxeItem || s.canPerformAction(ToolActions.PICKAXE_DIG);
            case 3 -> s -> s.getItem() instanceof AxeItem || s.canPerformAction(ToolActions.AXE_DIG);
            case 4 -> s -> s.getItem() instanceof ShovelItem || s.canPerformAction(ToolActions.SHOVEL_DIG);
            case 6 -> s -> s.getCapability(net.minecraftforge.common.capabilities.ForgeCapabilities.ITEM_HANDLER).isPresent();
            default -> s -> s.getItem() instanceof HoeItem || s.canPerformAction(ToolActions.HOE_DIG) || FuncionarioEntity.ehFoice(s);
        };
    }

    public FuncionarioEntity getFuncionario() {
        return funcionario;
    }

    @Override
    public boolean stillValid(Player jogador) {
        return funcionario.isAlive() && jogador.distanceToSqr(funcionario) < 64.0D;
    }

    @Override
    public void removed(Player jogador) {
        super.removed(jogador);
        funcionario.getInventario().stopOpen(jogador);
    }

    @Override
    public ItemStack quickMoveStack(Player jogador, int indice) {
        ItemStack copia = ItemStack.EMPTY;
        Slot slot = this.slots.get(indice);
        if (slot != null && slot.hasItem()) {
            ItemStack pilha = slot.getItem();
            copia = pilha.copy();

            if (indice >= INICIO_EQUIP) {
                // equipamento / armas / ferramentas -> baú e inventário do jogador
                if (!this.moveItemStackTo(pilha, 0, INICIO_EQUIP, false)) {
                    return ItemStack.EMPTY;
                }
            } else {
                // tenta vestir/guardar no slot certo (armadura, escudo, armas, ferramentas)
                boolean movido = false;
                for (int d = INICIO_EQUIP; d < TOTAL && !movido; d++) {
                    if (d == INICIO_EQUIP + 4 && !pilha.canPerformAction(ToolActions.SHIELD_BLOCK)) continue;
                    Slot alvo = this.slots.get(d);
                    if (!alvo.hasItem() && alvo.mayPlace(pilha)) {
                        movido = this.moveItemStackTo(pilha, d, d + 1, false);
                    }
                }
                if (!movido) {
                    if (indice < INICIO_JOGADOR) {
                        if (!this.moveItemStackTo(pilha, INICIO_JOGADOR, INICIO_EQUIP, true)) {
                            return ItemStack.EMPTY;
                        }
                    } else if (!this.moveItemStackTo(pilha, 0, SLOTS_FUNC, false)) {
                        return ItemStack.EMPTY;
                    }
                }
            }

            if (pilha.isEmpty()) {
                slot.setByPlayer(ItemStack.EMPTY);
            } else {
                slot.setChanged();
            }
        }
        return copia;
    }

    /** Slot de equipamento: só aceita o que cabe naquele lugar (o de escudo aceita qualquer coisa). */
    /** Slot comum que some quando a aba de comandos está aberta. */
    private class SlotAba extends Slot {
        SlotAba(Container container, int indice, int x, int y) {
            super(container, indice, x, y);
        }

        @Override
        public boolean isActive() {
            return !abaComandos;
        }
    }

    private class SlotEquipamento extends Slot {
        private final EquipmentSlot tipo;
        private final FuncionarioEntity entidade;

        SlotEquipamento(Container container, int indice, int x, int y, EquipmentSlot tipo, FuncionarioEntity entidade) {
            super(container, indice, x, y);
            this.tipo = tipo;
            this.entidade = entidade;
        }

        @Override
        public boolean isActive() {
            return !abaComandos;
        }

        @Override
        public boolean mayPlace(ItemStack pilha) {
            if (tipo == EquipmentSlot.OFFHAND) return true;
            return pilha.canEquip(tipo, entidade);
        }

        @Override
        public int getMaxStackSize() {
            return tipo.getType() == EquipmentSlot.Type.ARMOR ? 1 : super.getMaxStackSize();
        }
    }

    /** Slot de arma/ferramenta: aceita só o tipo certo, um item por slot. */
    private class SlotRestrito extends Slot {
        private final Predicate<ItemStack> regra;

        SlotRestrito(Container container, int indice, int x, int y, Predicate<ItemStack> regra) {
            super(container, indice, x, y);
            this.regra = regra;
        }

        @Override
        public boolean isActive() {
            return !abaComandos;
        }

        @Override
        public boolean mayPlace(ItemStack pilha) {
            return regra.test(pilha);
        }

        @Override
        public int getMaxStackSize() {
            return 1;
        }
    }
}
