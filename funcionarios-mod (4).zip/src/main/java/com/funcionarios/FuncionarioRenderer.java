package com.funcionarios;

import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.client.renderer.entity.layers.HumanoidArmorLayer;
import net.minecraft.resources.ResourceLocation;

/** Desenha o funcionário com o modelo humanoide de jogador, uma das skins do mod e a armadura equipada. */
public class FuncionarioRenderer extends HumanoidMobRenderer<FuncionarioEntity, HumanoidModel<FuncionarioEntity>> {
    /** Modelo de jogador com poses de trabalho: segura o item como o jogador, respira parado e balança o braço ao trabalhar. */
    static class ModeloFuncionario extends HumanoidModel<FuncionarioEntity> {
        ModeloFuncionario(net.minecraft.client.model.geom.ModelPart raiz) {
            super(raiz);
        }

        @Override
        public void setupAnim(FuncionarioEntity e, float limbSwing, float limbSwingAmount, float age, float yaw, float pitch) {
            boolean item = !e.getMainHandItem().isEmpty();
            this.rightArmPose = item ? ArmPose.ITEM : ArmPose.EMPTY;
            this.leftArmPose = ArmPose.EMPTY;
            super.setupAnim(e, limbSwing, limbSwingAmount, age, yaw, pitch);
            // respiração suave (como um jogador parado) em ambos os braços
            net.minecraft.client.model.AnimationUtils.bobArms(this.rightArm, this.leftArm, age);
            // trabalhando (sem andar): braço livre acompanha o corpo e a cabeça olha um pouco para baixo
            if (this.attackTime > 0.0F && limbSwingAmount < 0.1F) {
                this.leftArm.xRot += Math.sin(this.attackTime * Math.PI) * 0.35F;
            }
            this.hat.copyFrom(this.head);
        }
    }

    public FuncionarioRenderer(EntityRendererProvider.Context contexto) {
        super(contexto, new ModeloFuncionario(contexto.bakeLayer(ModelLayers.PLAYER)), 0.5F);
        this.addLayer(new HumanoidArmorLayer<>(this,
                new HumanoidModel<>(contexto.bakeLayer(ModelLayers.PLAYER_INNER_ARMOR)),
                new HumanoidModel<>(contexto.bakeLayer(ModelLayers.PLAYER_OUTER_ARMOR)),
                contexto.getModelManager()));
    }

    @Override
    public ResourceLocation getTextureLocation(FuncionarioEntity entidade) {
        return new ResourceLocation(FuncionariosMod.MOD_ID,
                "textures/entity/funcionario_" + Math.floorMod(entidade.getSkin(), 12) + ".png");
    }
}
