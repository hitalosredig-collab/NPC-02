package com.funcionarios;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.network.chat.Component;
import net.minecraft.util.FormattedCharSequence;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

/**
 * Janela compacta (176 x 216, do tamanho de um baú duplo) para não brigar com mods de itens como o JEI.
 * Duas abas na mesma janela: "Itens" (equipamento, ferramentas, inventários) e "Comandos".
 */
public class FuncionarioScreen extends AbstractContainerScreen<FuncionarioMenu> {
    private static final int LARGURA_COL = 80;
    private static final int ALTURA_BOTAO = 18;

    /** Ícone "fantasma" mostrado nos slots de arma/ferramenta vazios. */
    private static final Item[] FANTASMAS = {
            Items.IRON_SWORD, Items.IRON_SWORD, Items.IRON_PICKAXE, Items.IRON_AXE, Items.IRON_SHOVEL, Items.IRON_HOE
    };

    private final List<Button> botoesComandos = new ArrayList<>();
    private Button abaItens;
    private Button abaComandos;
    private Button botaoMinerio;
    private Button botaoVoz;
    private Button botaoMelhorar;
    private int nivelDoBotao = -1;

    public FuncionarioScreen(FuncionarioMenu menu, Inventory inventario, Component titulo) {
        super(menu, inventario, titulo);
        this.imageWidth = 176;
        this.imageHeight = 216;
        this.inventoryLabelX = FuncionarioMenu.INV_X;
        this.inventoryLabelY = FuncionarioMenu.INV_Y - 11;
    }

    private void enviar(Tarefa tarefa) {
        Rede.CANAL.sendToServer(new PacoteComando(this.menu.getFuncionario().getId(), tarefa.ordinal()));
    }

    private Button botao(String texto, int x, int y, int largura, Button.OnPress acao) {
        Button b = Button.builder(Component.literal(texto), acao)
                .bounds(this.leftPos + x, this.topPos + y, largura, ALTURA_BOTAO).build();
        this.addRenderableWidget(b);
        botoesComandos.add(b);
        return b;
    }

    @Override
    protected void init() {
        super.init();
        botoesComandos.clear();

        // abas (no topo da janela)
        abaItens = Button.builder(Component.literal("Itens"), b -> this.menu.abaComandos = false)
                .bounds(this.leftPos + 6, this.topPos + 4, 82, 14).build();
        abaComandos = Button.builder(Component.literal("Comandos"), b -> this.menu.abaComandos = true)
                .bounds(this.leftPos + 88, this.topPos + 4, 82, 14).build();
        this.addRenderableWidget(abaItens);
        this.addRenderableWidget(abaComandos);

        int x1 = 6;
        int x2 = 88;
        int w = 82;
        // voz: dentro da caixa de status
        botaoVoz = botao("Voz", 110, 46, 60, b -> {
            Configuracao.VOZ_ATIVA.set(!Configuracao.VOZ_ATIVA.get());
            Configuracao.VOZ_ATIVA.save();
        });
        // trabalho
        botao("Madeira", x1, 82, w, b -> enviar(Tarefa.MADEIRA));
        botao("Pedra", x2, 82, w, b -> enviar(Tarefa.PEDRA));
        botaoMinerio = botao("Minério", x1, 102, 138, b -> enviar(Tarefa.MINERIO));
        Button escolher = botao("...", 146, 102, 22, b -> this.minecraft.setScreen(
                new MinerioScreen(this, this.menu.getFuncionario(), () -> enviar(Tarefa.MINERIO))));
        escolher.setTooltip(Tooltip.create(Component.literal("Escolher vários minérios preferidos")));
        botao("Colher", x1, 122, w, b -> enviar(Tarefa.COLHER));
        botaoMelhorar = botao("Melhorar", x2, 122, w, b -> enviar(Tarefa.MELHORAR));
        // entrega
        Button entregar = botao("Entregar a mim", x1, 154, w, b -> enviar(Tarefa.ENTREGAR));
        entregar.setTooltip(Tooltip.create(Component.literal("Leva tudo que ele juntou até você")));
        Button guardar = botao("Guardar no baú", x2, 154, w, b -> enviar(Tarefa.GUARDAR));
        guardar.setTooltip(Tooltip.create(Component.literal("Guarda nos Baús do Funcionário (de longe) ou no baú mais perto")));
        // controle
        botao("Seguir", x1, 186, 52, b -> enviar(Tarefa.SEGUIR));
        botao("Defender", 62, 186, 52, b -> enviar(Tarefa.DEFENDER));
        botao("Parar", 118, 186, 52, b -> enviar(Tarefa.PARAR));
        nivelDoBotao = -1;
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float parcial) {
        this.renderBackground(g);
        boolean comandos = this.menu.abaComandos;
        for (Button b : botoesComandos) {
            b.visible = comandos;
        }
        abaItens.active = comandos;
        abaComandos.active = !comandos;

        if (botaoMinerio != null) {
            String rot = "Minério: " + this.menu.getFuncionario().rotuloMinerios();
            botaoMinerio.setMessage(Component.literal(this.font.plainSubstrByWidth(rot, 130)));
        }
        if (botaoVoz != null) {
            botaoVoz.setMessage(Component.literal("Voz: " + (Configuracao.VOZ_ATIVA.get() ? "sim" : "não")));
        }
        if (botaoMelhorar != null) {
            int n = this.menu.getFuncionario().getNivel();
            if (n != nivelDoBotao) {
                nivelDoBotao = n;
                botaoMelhorar.setMessage(Component.literal("Nível " + n + "/" + FuncionarioEntity.NIVEL_MAX));
                botaoMelhorar.active = false; // agora sobe com item (clique direito no funcionário)
                botaoMelhorar.setTooltip(Tooltip.create(Component.literal(n >= FuncionarioEntity.NIVEL_MAX
                        ? "Nível máximo"
                        : "Para subir: clique direito nele com a Melhoria nível " + (n + 1))));
            }
        }
        super.render(g, mouseX, mouseY, parcial);
        this.renderTooltip(g, mouseX, mouseY);
    }

    @Override
    protected void renderLabels(GuiGraphics g, int mouseX, int mouseY) {
        if (!this.menu.abaComandos) {
            g.drawString(this.font, this.playerInventoryTitle, this.inventoryLabelX, this.inventoryLabelY, 0x404040, false);
        }
    }

    private void titulo(GuiGraphics g, String texto, int y) {
        int x = this.leftPos + 6;
        int yy = this.topPos + y;
        g.drawString(this.font, Component.literal(texto), x, yy, 0x303030, false);
        int larg = this.font.width(texto);
        g.fill(x + larg + 4, yy + 4, this.leftPos + 170, yy + 5, 0xFF8B8B8B);
    }

    @Override
    protected void renderBg(GuiGraphics g, float parcial, int mouseX, int mouseY) {
        FuncionarioEntity f = this.menu.getFuncionario();

        // janela
        g.fill(this.leftPos - 1, this.topPos - 1, this.leftPos + this.imageWidth + 1, this.topPos + this.imageHeight + 1, 0xFF000000);
        g.fill(this.leftPos, this.topPos, this.leftPos + this.imageWidth, this.topPos + this.imageHeight, 0xFFC6C6C6);

        if (!this.menu.abaComandos) {
            // moldura dos slots
            for (Slot s : this.menu.slots) {
                if (!s.isActive()) continue;
                int sx = this.leftPos + s.x;
                int sy = this.topPos + s.y;
                g.fill(sx - 1, sy - 1, sx + 17, sy + 17, 0xFF373737);
                g.fill(sx, sy, sx + 17, sy + 17, 0xFFFFFFFF);
                g.fill(sx, sy, sx + 16, sy + 16, 0xFF8B8B8B);
            }
            // ícones apagados nos slots de arma/ferramenta vazios
            for (int i = 0; i < FANTASMAS.length; i++) {
                Slot s = this.menu.slots.get(FuncionarioMenu.INICIO_FERR + i);
                if (!s.hasItem()) {
                    int sx = this.leftPos + s.x;
                    int sy = this.topPos + s.y;
                    g.renderFakeItem(new ItemStack(FANTASMAS[i]), sx, sy);
                    g.fill(RenderType.guiGhostRecipeOverlay(), sx, sy, sx + 16, sy + 16, 0xB08B8B8B);
                }
            }
            // ícone de mochila apagado no 7º slot vazio
            Slot sm = this.menu.slots.get(FuncionarioMenu.INICIO_FERR + 6);
            if (!sm.hasItem()) {
                int mx = this.leftPos + sm.x;
                int my = this.topPos + sm.y;
                g.fill(mx + 6, my + 1, mx + 10, my + 3, 0xB05A3A1A);     // alça
                g.fill(mx + 3, my + 3, mx + 13, my + 15, 0xB0A9743C);    // corpo
                g.fill(mx + 3, my + 3, mx + 13, my + 7, 0xB07A4F22);     // aba
                g.fill(mx + 5, my + 10, mx + 11, my + 14, 0xB0C99A55);   // bolso
                g.fill(mx + 7, my + 6, mx + 9, my + 9, 0xB0E0C040);      // fivela
            }
            // nome e vida ao lado do equipamento
            g.drawString(this.font, f.getName(), this.leftPos + 102, this.topPos + 23, 0x202020, false);
            g.drawString(this.font, Component.literal("Vida " + (int) f.getHealth() + "/" + (int) f.getMaxHealth()),
                    this.leftPos + 102, this.topPos + 33, 0x802020, false);
            g.drawString(this.font, Component.literal("Nível " + f.getNivel()), this.leftPos + 128, this.topPos + 46, 0x206020, false);
            return;
        }

        // aba de comandos: caixa de status, fala e títulos das seções
        int px = this.leftPos + 6;
        int py = this.topPos + 22;
        g.fill(px, py, px + 164, py + 46, 0xFF1E1E1E);
        g.drawString(this.font, f.getName(), px + 4, py + 4, 0xFFD700, false);
        g.drawString(this.font, Component.literal("Nível " + f.getNivel() + "/" + FuncionarioEntity.NIVEL_MAX), px + 84, py + 4, 0x8FD18F, false);
        g.drawString(this.font, Component.literal("Tarefa: " + f.getTarefa().getRotulo()), px + 4, py + 15, 0xAAAAAA, false);
        String fala = f.getFala();
        if (fala != null && !fala.isEmpty()) {
            int linhaY = py + 26;
            for (FormattedCharSequence linha : this.font.split(Component.literal(fala), 100)) {
                if (linhaY > py + 38) break;
                g.drawString(this.font, linha, px + 4, linhaY, 0xFFFFFF, false);
                linhaY += 10;
            }
        }
        titulo(g, "Trabalho", 72);
        titulo(g, "Entrega", 144);
        titulo(g, "Controle", 176);
    }
}
