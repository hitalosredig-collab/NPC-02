package com.funcionarios;

import java.util.List;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;

/** Item de melhoria: clique direito num funcionário no nível anterior para subir ele de nível. */
public class MelhoriaItem extends Item {
    private final int nivel;

    public MelhoriaItem(int nivel, Properties propriedades) {
        super(propriedades);
        this.nivel = nivel;
    }

    public int getNivel() {
        return nivel;
    }

    @Override
    public boolean isFoil(ItemStack pilha) {
        return nivel >= 4;
    }

    @Override
    public void appendHoverText(ItemStack pilha, @Nullable Level nivelMundo, List<Component> dicas, TooltipFlag flag) {
        dicas.add(Component.literal("Clique direito num funcionário de nível " + (nivel - 1) + " para subir ele para o nível " + nivel + ".")
                .withStyle(net.minecraft.ChatFormatting.GRAY));
        dicas.add(Component.literal("Mais rápido, mais forte e mais resistente.").withStyle(net.minecraft.ChatFormatting.DARK_GRAY));
    }
}
