package com.funcionarios;

import net.minecraft.tags.TagKey;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.common.Tags;

/** Qual minério o funcionário procura no comando "Minerar minério". */
public enum Minerio {
    QUALQUER("Qualquer", Tags.Blocks.ORES),
    CARVAO("Carvão", Tags.Blocks.ORES_COAL),
    FERRO("Ferro", Tags.Blocks.ORES_IRON),
    COBRE("Cobre", Tags.Blocks.ORES_COPPER),
    OURO("Ouro", Tags.Blocks.ORES_GOLD),
    REDSTONE("Redstone", Tags.Blocks.ORES_REDSTONE),
    LAPIS("Lazurita", Tags.Blocks.ORES_LAPIS),
    DIAMANTE("Diamante", Tags.Blocks.ORES_DIAMOND),
    ESMERALDA("Esmeralda", Tags.Blocks.ORES_EMERALD);

    private final String rotulo;
    private final TagKey<Block> tag;

    Minerio(String rotulo, TagKey<Block> tag) {
        this.rotulo = rotulo;
        this.tag = tag;
    }

    public String getRotulo() {
        return rotulo;
    }

    public boolean serve(BlockState estado) {
        return estado.is(tag);
    }

    public Minerio proximo() {
        Minerio[] v = values();
        return v[(ordinal() + 1) % v.length];
    }

    public static Minerio de(int indice) {
        Minerio[] v = values();
        return (indice >= 0 && indice < v.length) ? v[indice] : QUALQUER;
    }
}
