package com.funcionarios;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/** Escolha de vários minérios preferidos: ele vai atrás de todos os marcados. */
public class MinerioScreen extends Screen {
    private final Screen pai;
    private final FuncionarioEntity func;
    private final Runnable aoMinerar;
    private int mascara;
    private final Button[] botoes = new Button[Minerio.values().length];

    public MinerioScreen(Screen pai, FuncionarioEntity func, Runnable aoMinerar) {
        super(Component.literal("Minérios preferidos"));
        this.pai = pai;
        this.func = func;
        this.aoMinerar = aoMinerar;
        this.mascara = func.getMascaraMinerio();
    }

    @Override
    protected void init() {
        Minerio[] todos = Minerio.values();
        int largura = 110;
        int x0 = this.width / 2 - largura - 4;
        int y0 = this.height / 2 - 62;
        for (int i = 0; i < todos.length; i++) {
            final Minerio m = todos[i];
            int col = i % 2;
            int lin = i / 2;
            botoes[i] = Button.builder(Component.empty(), b -> alternar(m))
                    .bounds(x0 + col * (largura + 8), y0 + lin * 24, largura, 20).build();
            this.addRenderableWidget(botoes[i]);
        }
        int y = y0 + ((todos.length + 1) / 2) * 24 + 6;
        this.addRenderableWidget(Button.builder(Component.literal("Minerar estes"), b -> {
            aoMinerar.run();
            this.minecraft.setScreen(pai);
        }).bounds(this.width / 2 - largura - 4, y, largura, 20).build());
        this.addRenderableWidget(Button.builder(Component.literal("Voltar"),
                b -> this.minecraft.setScreen(pai)).bounds(this.width / 2 + 4, y, largura, 20).build());
        atualizar();
    }

    private void alternar(Minerio m) {
        int bit = 1 << m.ordinal();
        if (m == Minerio.QUALQUER) {
            mascara = 1;
        } else {
            mascara &= ~1;
            mascara ^= bit;
            if (mascara == 0) mascara = 1;
        }
        Rede.CANAL.sendToServer(new PacoteMinerio(func.getId(), mascara));
        atualizar();
    }

    private void atualizar() {
        Minerio[] todos = Minerio.values();
        for (int i = 0; i < todos.length; i++) {
            boolean on = (mascara & (1 << todos[i].ordinal())) != 0;
            botoes[i].setMessage(Component.literal((on ? "§a[x] " : "§7[ ] ") + todos[i].getRotulo()));
        }
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float parcial) {
        this.renderBackground(g);
        int w = 2 * 118 + 24;
        int alt = ((Minerio.values().length + 1) / 2) * 24 + 90;
        int x = this.width / 2 - w / 2;
        int y = this.height / 2 - 62 - 34;
        g.fill(x - 1, y - 1, x + w + 1, y + alt + 1, 0xFF000000);
        g.fill(x, y, x + w, y + alt, 0xFFC6C6C6);
        g.drawCenteredString(this.font, this.title, this.width / 2, y + 8, 0x404040);
        g.drawCenteredString(this.font, Component.literal("Marque os que quiser: ele vai atrás de todos"),
                this.width / 2, y + 20, 0x555555);
        super.render(g, mouseX, mouseY, parcial);
    }
}
