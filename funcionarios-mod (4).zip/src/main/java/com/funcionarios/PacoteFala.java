package com.funcionarios;

import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

/** Servidor -> cliente do dono: o funcionário falou uma frase (o cliente lê em voz alta). */
public class PacoteFala {
    private final int entidade;
    private final String texto;
    private final int skin;
    private final int personalidade;

    public PacoteFala(int entidade, String texto, int skin, int personalidade) {
        this.entidade = entidade;
        this.texto = texto;
        this.skin = skin;
        this.personalidade = personalidade;
    }

    public void codificar(FriendlyByteBuf buf) {
        buf.writeInt(entidade);
        buf.writeUtf(texto);
        buf.writeInt(skin);
        buf.writeInt(personalidade);
    }

    public static PacoteFala decodificar(FriendlyByteBuf buf) {
        return new PacoteFala(buf.readInt(), buf.readUtf(), buf.readInt(), buf.readInt());
    }

    public static void tratar(PacoteFala pacote, Supplier<NetworkEvent.Context> contexto) {
        contexto.get().enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT,
                () -> () -> ClienteHelper.falar(pacote.entidade, pacote.texto, pacote.skin, pacote.personalidade)));
        contexto.get().setPacketHandled(true);
    }
}
