package com.funcionarios;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

/** Servidor -> cliente: lista dos funcionários do jogador, para a tela da Central. */
public class PacoteLista {
    public static class Entrada {
        public final int id;
        public final String nome;
        public final int tarefa;
        public final float vida;
        public final float vidaMax;
        public final int distancia;
        public final ItemStack mao;
        public final List<ItemStack> itens;

        public Entrada(int id, String nome, int tarefa, float vida, float vidaMax, int distancia,
                       ItemStack mao, List<ItemStack> itens) {
            this.id = id;
            this.nome = nome;
            this.tarefa = tarefa;
            this.vida = vida;
            this.vidaMax = vidaMax;
            this.distancia = distancia;
            this.mao = mao;
            this.itens = itens;
        }
    }

    public final List<Entrada> lista;

    public PacoteLista(List<Entrada> lista) {
        this.lista = lista;
    }

    private static void escreverItem(FriendlyByteBuf buf, ItemStack s) {
        ItemStack um = s.copy();
        um.setCount(1);
        buf.writeItem(um);
        buf.writeVarInt(s.getCount()); // a contagem vai separada porque pode passar de 127
    }

    private static ItemStack lerItem(FriendlyByteBuf buf) {
        ItemStack s = buf.readItem();
        s.setCount(buf.readVarInt());
        return s;
    }

    public void codificar(FriendlyByteBuf buf) {
        buf.writeVarInt(lista.size());
        for (Entrada e : lista) {
            buf.writeInt(e.id);
            buf.writeUtf(e.nome);
            buf.writeInt(e.tarefa);
            buf.writeFloat(e.vida);
            buf.writeFloat(e.vidaMax);
            buf.writeInt(e.distancia);
            escreverItem(buf, e.mao);
            buf.writeVarInt(e.itens.size());
            for (ItemStack s : e.itens) {
                escreverItem(buf, s);
            }
        }
    }

    public static PacoteLista decodificar(FriendlyByteBuf buf) {
        int n = buf.readVarInt();
        List<Entrada> lista = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            int id = buf.readInt();
            String nome = buf.readUtf();
            int tarefa = buf.readInt();
            float vida = buf.readFloat();
            float vidaMax = buf.readFloat();
            int distancia = buf.readInt();
            ItemStack mao = lerItem(buf);
            int total = buf.readVarInt();
            List<ItemStack> itens = new ArrayList<>();
            for (int k = 0; k < total; k++) {
                itens.add(lerItem(buf));
            }
            lista.add(new Entrada(id, nome, tarefa, vida, vidaMax, distancia, mao, itens));
        }
        return new PacoteLista(lista);
    }

    public static void tratar(PacoteLista pacote, Supplier<NetworkEvent.Context> contexto) {
        contexto.get().enqueueWork(() ->
                DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ClienteHelper.atualizar(pacote.lista)));
        contexto.get().setPacketHandled(true);
    }
}
