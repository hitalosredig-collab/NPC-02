package com.funcionarios;

import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraftforge.network.NetworkEvent;

/** Cliente -> servidor: os minérios preferidos do funcionário (máscara de bits). */
public class PacoteMinerio {
    private final int entidade;
    private final int mascara;

    public PacoteMinerio(int entidade, int mascara) {
        this.entidade = entidade;
        this.mascara = mascara;
    }

    public void codificar(FriendlyByteBuf buf) {
        buf.writeInt(entidade);
        buf.writeInt(mascara);
    }

    public static PacoteMinerio decodificar(FriendlyByteBuf buf) {
        return new PacoteMinerio(buf.readInt(), buf.readInt());
    }

    public static void tratar(PacoteMinerio pacote, Supplier<NetworkEvent.Context> contexto) {
        contexto.get().enqueueWork(() -> {
            ServerPlayer jogador = contexto.get().getSender();
            if (jogador == null) return;
            Entity e = jogador.level().getEntity(pacote.entidade);
            if (e instanceof FuncionarioEntity f && f.ehDono(jogador) && jogador.distanceToSqr(f) < 100.0D) {
                f.setMascaraMinerio(pacote.mascara);
            }
        });
        contexto.get().setPacketHandled(true);
    }
}
