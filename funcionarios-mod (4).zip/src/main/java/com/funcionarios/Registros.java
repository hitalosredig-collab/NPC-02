package com.funcionarios;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.item.Item;
import net.minecraftforge.common.extensions.IForgeMenuType;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class Registros {
    public static final DeferredRegister<EntityType<?>> ENTIDADES =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, FuncionariosMod.MOD_ID);
    public static final DeferredRegister<MenuType<?>> MENUS =
            DeferredRegister.create(ForgeRegistries.MENU_TYPES, FuncionariosMod.MOD_ID);
    public static final DeferredRegister<Block> BLOCOS =
            DeferredRegister.create(ForgeRegistries.BLOCKS, FuncionariosMod.MOD_ID);
    public static final DeferredRegister<BlockEntityType<?>> BLOCOS_ENTIDADE =
            DeferredRegister.create(ForgeRegistries.BLOCK_ENTITY_TYPES, FuncionariosMod.MOD_ID);
    public static final DeferredRegister<Item> ITENS =
            DeferredRegister.create(ForgeRegistries.ITEMS, FuncionariosMod.MOD_ID);

    public static final RegistryObject<EntityType<FuncionarioEntity>> FUNCIONARIO =
            ENTIDADES.register("funcionario", () ->
                    EntityType.Builder.of(FuncionarioEntity::new, MobCategory.CREATURE)
                            .sized(0.6F, 1.8F)
                            .clientTrackingRange(10)
                            .build("funcionario"));

    public static final RegistryObject<MenuType<FuncionarioMenu>> MENU =
            MENUS.register("funcionario", () -> IForgeMenuType.create(FuncionarioMenu::new));

    public static final RegistryObject<Item> CONTRATO =
            ITENS.register("contrato", () -> new ContratoItem(new Item.Properties().stacksTo(16)));

    /** Níveis do baú: madeira, cobre, ferro, ouro, diamante, netherite (linhas de 9 slots). */
    public static final String[] NOMES_BAU = {
            "bau_funcionario", "bau_funcionario_cobre", "bau_funcionario_ferro",
            "bau_funcionario_ouro", "bau_funcionario_diamante", "bau_funcionario_netherite"
    };
    public static final int[] LINHAS_BAU = {3, 4, 6, 9, 9, 10};
    public static final int[] COLUNAS_BAU = {9, 9, 9, 9, 12, 12}; // 27, 36, 54, 81, 108, 120 slots

    public static final List<RegistryObject<Block>> BAUS = new ArrayList<>();
    public static final List<RegistryObject<Item>> BAU_ITENS = new ArrayList<>();

    static {
        for (int i = 0; i < NOMES_BAU.length; i++) {
            final int linhas = LINHAS_BAU[i];
            final int colunas = COLUNAS_BAU[i];
            final boolean fogo = i == NOMES_BAU.length - 1;
            final RegistryObject<Block> bloco = BLOCOS.register(NOMES_BAU[i], () ->
                    new BauFuncionarioBloco(BlockBehaviour.Properties.of().mapColor(MapColor.WOOD)
                            .strength(2.5F + linhas * 0.2F).sound(SoundType.WOOD).noOcclusion(), linhas, colunas));
            BAUS.add(bloco);
            BAU_ITENS.add(ITENS.register(NOMES_BAU[i], () ->
                    new BlockItem(bloco.get(), fogo ? new Item.Properties().fireResistant() : new Item.Properties())));
        }
    }

    public static final RegistryObject<BlockEntityType<BauFuncionarioBE>> BAU_BE =
            BLOCOS_ENTIDADE.register("bau_funcionario", () ->
                    BlockEntityType.Builder.of(BauFuncionarioBE::new,
                            BAUS.stream().map(RegistryObject::get).toArray(Block[]::new)).build(null));

    public static final RegistryObject<MenuType<BauFuncionarioMenu>> MENU_BAU =
            MENUS.register("bau_funcionario", () -> IForgeMenuType.create(BauFuncionarioMenu::new));

    public static final RegistryObject<Item> CENTRAL =
            ITENS.register("central", () -> new CentralItem(new Item.Properties().stacksTo(1)));

    /** Itens de melhoria nível 1 a 5 (usados com clique direito no funcionário). */
    public static final List<RegistryObject<Item>> MELHORIAS = new ArrayList<>();

    static {
        for (int n = 1; n <= 5; n++) {
            final int nivel = n;
            MELHORIAS.add(ITENS.register("melhoria_" + n, () -> new MelhoriaItem(nivel, new Item.Properties().stacksTo(16))));
        }
    }
}
