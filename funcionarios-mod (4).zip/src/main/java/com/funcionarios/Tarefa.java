package com.funcionarios;

public enum Tarefa {
    PARAR("Parar"),
    SEGUIR("Seguir você"),
    DEFENDER("Me defender"),
    MADEIRA("Pegar madeira"),
    PEDRA("Minerar pedra"),
    MINERIO("Minerar minério"),
    COLHER("Colher plantação"),
    ENTREGAR("Entregar itens"),
    /** Só serve para trocar o minério escolhido; nunca fica como tarefa atual. */
    TROCAR_MINERIO("Trocar minério"),
    /** Compra a próxima melhoria (quebra mais rápido e em área); nunca fica como tarefa atual. */
    MELHORAR("Melhorar"),
    /** Guarda os itens nos baús (de longe nos Baús do Funcionário, ou no baú mais perto); nunca fica como tarefa atual. */
    GUARDAR("Guardar no baú");

    private final String rotulo;

    Tarefa(String rotulo) {
        this.rotulo = rotulo;
    }

    public String getRotulo() {
        return rotulo;
    }

    public boolean ehTrabalho() {
        return this == MADEIRA || this == PEDRA || this == MINERIO || this == COLHER;
    }

    public static Tarefa de(int indice) {
        Tarefa[] v = values();
        return (indice >= 0 && indice < v.length) ? v[indice] : PARAR;
    }
}
