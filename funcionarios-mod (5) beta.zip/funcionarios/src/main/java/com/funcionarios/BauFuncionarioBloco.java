package com.funcionarios;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.StringRepresentable;
import net.minecraft.world.Containers;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.level.block.state.properties.EnumProperty;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;
import net.minecraftforge.network.NetworkHooks;

/**
 * Baú do Funcionário (6 níveis). Igual ao baú do Minecraft: dois baús do MESMO nível lado a lado (mesma direção)
 * se fundem num baú duplo. Agachado ao colocar, não funde.
 */
public class BauFuncionarioBloco extends BaseEntityBlock {
    public enum Sentido implements StringRepresentable {
        UNICO("unico"), HORARIO("horario"), ANTI("anti");

        private final String nome;

        Sentido(String nome) {
            this.nome = nome;
        }

        @Override
        public String getSerializedName() {
            return nome;
        }

        public Sentido oposto() {
            return this == HORARIO ? ANTI : (this == ANTI ? HORARIO : UNICO);
        }
    }

    public static final DirectionProperty FACING = BlockStateProperties.HORIZONTAL_FACING;
    /** 0 fechado, 1 e 2 tampa abrindo (animação). */
    public static final IntegerProperty ABERTURA = IntegerProperty.create("abertura", 0, 2);
    public static final EnumProperty<Sentido> SENTIDO = EnumProperty.create("sentido", Sentido.class);

    private final int linhas;
    private final int colunas;

    public BauFuncionarioBloco(Properties propriedades, int linhas, int colunas) {
        super(propriedades);
        this.linhas = linhas;
        this.colunas = colunas;
        this.registerDefaultState(this.stateDefinition.any().setValue(FACING, Direction.NORTH).setValue(SENTIDO, Sentido.UNICO).setValue(ABERTURA, 0));
    }

    public int getLinhas() {
        return linhas;
    }

    public int getColunas() {
        return colunas;
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> b) {
        b.add(FACING, SENTIDO, ABERTURA);
    }

    /** Direção onde está o outro baú do par (null se for baú único). */
    public static Direction parceiroDir(BlockState st) {
        Direction f = st.getValue(FACING);
        return switch (st.getValue(SENTIDO)) {
            case HORARIO -> f.getClockWise();
            case ANTI -> f.getCounterClockWise();
            default -> null;
        };
    }

    private boolean donoCompativel(Level nivel, BlockPos pos, Player jogador) {
        if (jogador == null) return true;
        return !(nivel.getBlockEntity(pos) instanceof BauFuncionarioBE be)
                || be.getDono() == null || be.getDono().equals(jogador.getUUID());
    }

    /** Direção do baú vizinho (do mesmo nível, ainda sozinho, do mesmo dono) na direção "d", ou null. */
    private Direction vizinhoDirecao(BlockPlaceContext c, Direction d) {
        Level nivel = c.getLevel();
        BlockPos vp = c.getClickedPos().relative(d);
        BlockState v = nivel.getBlockState(vp);
        if (v.is(this) && v.getValue(SENTIDO) == Sentido.UNICO && donoCompativel(nivel, vp, c.getPlayer())) {
            return v.getValue(FACING);
        }
        return null;
    }

    /**
     * Igual ao baú do Minecraft: sem agachar, encaixa sozinho no baú ao lado (mesma direção). Agachado e mirando
     * na lateral de um baú, encaixa nesse baú e assume a direção dele. Só 2 por vez, só do mesmo nível.
     */
    @Override
    public BlockState getStateForPlacement(BlockPlaceContext c) {
        Direction f = c.getHorizontalDirection().getOpposite();
        Sentido s = Sentido.UNICO;
        boolean agachado = c.isSecondaryUseActive();
        Direction clicada = c.getClickedFace();
        if (agachado && clicada.getAxis().isHorizontal()) {
            Direction d2 = vizinhoDirecao(c, clicada.getOpposite());
            if (d2 != null && d2.getAxis() != clicada.getAxis()) {
                f = d2;
                s = d2.getCounterClockWise() == clicada.getOpposite() ? Sentido.ANTI : Sentido.HORARIO;
            }
        }
        if (s == Sentido.UNICO && !agachado) {
            if (f == vizinhoDirecao(c, f.getClockWise())) {
                s = Sentido.HORARIO;
            } else if (f == vizinhoDirecao(c, f.getCounterClockWise())) {
                s = Sentido.ANTI;
            }
        }
        return this.defaultBlockState().setValue(FACING, f).setValue(SENTIDO, s);
    }

    @Override
    public BlockState updateShape(BlockState st, Direction dir, BlockState viz, LevelAccessor nivel,
                                  BlockPos pos, BlockPos vizPos) {
        if (dir.getAxis().isHorizontal()) {
            if (viz.is(this)) {
                if (st.getValue(SENTIDO) == Sentido.UNICO && viz.getValue(FACING) == st.getValue(FACING)
                        && viz.getValue(SENTIDO) != Sentido.UNICO && parceiroDir(viz) == dir.getOpposite()) {
                    return st.setValue(SENTIDO, viz.getValue(SENTIDO).oposto());
                }
            } else if (parceiroDir(st) == dir) {
                return st.setValue(SENTIDO, Sentido.UNICO);
            }
        }
        return super.updateShape(st, dir, viz, nivel, pos, vizPos);
    }

    @Override
    public BlockState rotate(BlockState st, Rotation r) {
        return st.setValue(FACING, r.rotate(st.getValue(FACING)));
    }

    /** Forma do baú (menor que um bloco inteiro; junto ao parceiro ocupa até a borda). */
    @Override
    public VoxelShape getShape(BlockState st, BlockGetter nivel, BlockPos pos, CollisionContext ctx) {
        double x1 = 1;
        double x2 = 15;
        Sentido s = st.getValue(SENTIDO);
        if (s == Sentido.HORARIO) x2 = 16;
        if (s == Sentido.ANTI) x1 = 0;
        double z1 = 1;
        double z2 = 15;
        double a1;
        double a2;
        double b1;
        double b2;
        switch (st.getValue(FACING)) {
            case EAST -> { a1 = 16 - z2; a2 = 16 - z1; b1 = x1; b2 = x2; }
            case SOUTH -> { a1 = 16 - x2; a2 = 16 - x1; b1 = 16 - z2; b2 = 16 - z1; }
            case WEST -> { a1 = z1; a2 = z2; b1 = 16 - x2; b2 = 16 - x1; }
            default -> { a1 = x1; a2 = x2; b1 = z1; b2 = z2; }
        }
        return Block.box(a1, 0, b1, a2, 16, b2);
    }

    /** Anima a tampa: sobe até aberta (2) enquanto alguém está com a tela aberta; desce até fechada (0) depois. */
    @Override
    public void tick(BlockState st, ServerLevel nivel, BlockPos pos, RandomSource aleatorio) {
        if (!(nivel.getBlockEntity(pos) instanceof BauFuncionarioBE b)) return;
        boolean aberto = b.getAbertos() > 0;
        BauFuncionarioBE p = b.parceiro();
        if (p != null && p.getAbertos() > 0) aberto = true;
        int a = st.getValue(ABERTURA);
        int alvo = aberto ? 2 : 0;
        if (a != alvo) {
            a += a < alvo ? 1 : -1;
            nivel.setBlock(pos, st.setValue(ABERTURA, a), 3);
            if (a != alvo) nivel.scheduleTick(pos, this, 3);
        }
    }

    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState estado) {
        return new BauFuncionarioBE(pos, estado);
    }

    @Override
    public RenderShape getRenderShape(BlockState estado) {
        return RenderShape.MODEL;
    }

    @Override
    public InteractionResult use(BlockState estado, Level nivel, BlockPos pos, Player jogador,
                                 InteractionHand mao, BlockHitResult acerto) {
        if (nivel.isClientSide) return InteractionResult.SUCCESS;
        BlockEntity be = nivel.getBlockEntity(pos);
        if (be instanceof BauFuncionarioBE bau && jogador instanceof ServerPlayer sp) {
            if (bau.getDono() != null && !bau.getDono().equals(jogador.getUUID()) && !jogador.isCreative()) {
                sp.displayClientMessage(Component.literal("Este baú é de outro jogador."), true);
                return InteractionResult.CONSUME;
            }
            net.minecraft.world.Container todo = bau.containerLigado();
            int cols = bau.getColunas();
            int total = todo.getContainerSize();
            NetworkHooks.openScreen(sp, new SimpleMenuProvider(
                    (id, inv, p) -> new BauFuncionarioMenu(id, inv, todo, pos, cols, total, bau),
                    estado.getBlock().getName()), buf -> {
                buf.writeBlockPos(pos);
                buf.writeVarInt(cols);
                buf.writeVarInt(total);
            });
        }
        return InteractionResult.CONSUME;
    }

    @Override
    public void setPlacedBy(Level nivel, BlockPos pos, BlockState estado, LivingEntity quem, ItemStack pilha) {
        super.setPlacedBy(nivel, pos, estado, quem, pilha);
        if (!nivel.isClientSide && quem instanceof Player jogador
                && nivel.getBlockEntity(pos) instanceof BauFuncionarioBE bau) {
            bau.setDono(jogador.getUUID());
            bau.setOrdem(nivel.getGameTime());
        }
    }

    @Override
    public void onRemove(BlockState estado, Level nivel, BlockPos pos, BlockState novo, boolean movido) {
        if (!estado.is(novo.getBlock()) && nivel.getBlockEntity(pos) instanceof BauFuncionarioBE bau) {
            Containers.dropContents(nivel, pos, bau.getArmazem());
        }
        super.onRemove(estado, nivel, pos, novo, movido);
    }
}
