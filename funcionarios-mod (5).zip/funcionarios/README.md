# Mod Funcionários (Minecraft Java 1.20.1 / Forge 47.x)

Contrate funcionários humanoides que trabalham e defendem você.

## Como colocar pra rodar

1. Baixe o **Forge MDK 1.20.1** (versão 47.x) em https://files.minecraftforge.net e extraia numa pasta.
2. Dentro do MDK, apague `src/main/java/com/example` e `src/main/resources/META-INF/mods.toml`.
3. Copie a pasta `src` deste projeto para dentro do MDK (mesclando/substituindo).
4. No `gradle.properties` do MDK, troque: `mod_id=funcionarios`, `mod_name=Funcionarios`, `mod_group_id=com.funcionarios`.
5. Abra a pasta do MDK no IntelliJ IDEA (Java 17), deixe o Gradle sincronizar e rode a configuração `runClient`.
   Para gerar o `.jar`: `gradlew build` (sai em `build/libs`).

O mod NÃO precisa do TACZ para compilar nem para rodar. A compatibilidade é opcional e feita por reflexão.

## Gerar o .jar pelo GitHub (sem instalar nada)

1. Crie um repositório no GitHub e envie o CONTEÚDO desta pasta (`src`, `.github`, `README.md`).
   A pasta `.github` é escondida em alguns sistemas: ela precisa ir junto.
2. Abra a aba **Actions** do repositório. A compilação roda sozinha (ou use **Run workflow**).
3. Quando terminar (alguns minutos), clique na execução e baixe **funcionarios-jar** em *Artifacts*.
   Dentro do zip baixado está o `.jar` para a pasta `mods`.
4. Se a compilação falhar, clique na execução, copie a mensagem de erro do passo "Compilar" e mande para ajuste.

## Como jogar

- Receita: **papel + esmeralda** (sem forma) = Contrato de Funcionário (também na aba Ferramentas do criativo).
- Clique direito com o contrato num bloco para contratar.
- Clique direito no funcionário para abrir a tela.

### Tela do funcionário

Tudo fica numa janela só (compatível com mods de itens como o JEI).

- Primeira coluna à esquerda: **capacete, peitoral, calça, bota e escudo** (com o ícone de cada peça nos slots vazios).
  A armadura aparece no corpo dele e o escudo é levantado quando ele luta de perto.
- Segunda coluna: **2 slots de arma** (espada, machado, tridente ou arma do TACZ), **picareta, machado, pá e enxada**
  (com o ícone apagado quando vazios). Cada slot só aceita o tipo certo.
- Centro: o inventário dele (27 slots, estilo baú), uma caixa com nome, tarefa e fala, e o seu inventário embaixo.
- Direita: botões de comando.
- Ele pega a ferramenta direto desses slots (pá para terra e areia; picareta, machado e enxada para o resto) e a mostra na mão.
  Ferramentas e armas nos slots não são entregues a você no "Entregar itens".

### Comandos

| Botão | O que precisa | O que faz |
|---|---|---|
| Parar | nada | para tudo |
| Seguir você | nada | anda atrás de você |
| Me defender | espada, machado ou arma do TACZ | ataca monstros perto de você e quem te machucar |
| Pegar madeira | machado (mão ou inventário) | corta árvores num raio de 16 blocos |
| Minerar pedra | picareta | quebra a pedra exposta ao redor. Se não achar, procura a pedra mais próxima (mesmo enterrada) e cava uma escada até ela |
| Minerar minério | picareta | igual, mas só pega o minério escolhido no botão `<>` (Qualquer, Carvão, Ferro, Cobre, Ouro, Redstone, Lazurita, Diamante, Esmeralda) |
| Colher plantação | nada (enxada é opcional) | colhe plantações maduras e replanta |
| Entregar itens | nada | vem até você e entrega tudo, menos ferramentas e armas |

Sem a ferramenta ou arma certa, ele recusa com uma fala. Se o inventário enche no meio do trabalho,
ele entrega sozinho e volta a trabalhar. Ao morrer, solta o inventário e o equipamento.

## Central dos Funcionários

Receita: **bússola + papel** (também na aba Ferramentas do criativo). Clique direito com ela na mão para abrir a lista de todos os
seus funcionários que estão em área carregada: nome, tarefa atual, vida e distância. Os botões **Chamar** (ele volta para perto de você,
no chão, e passa a seguir você) e **Parar** funcionam de qualquer distância. A lista atualiza sozinha a cada 2 segundos.

Limite: funcionário em área descarregada (muito longe, sem você por perto) não aparece, porque o Minecraft não o está simulando.

## Voz

Os funcionários falam em voz alta (além de escrever) usando a **voz do sistema**, a mesma do narrador do Minecraft:
no Windows em português, a voz "Microsoft Maria/Daniel" etc., se estiver instalada. Só fala quando ele está a até 20 blocos de você.
O botão **Voz: ligada/desligada** na tela dele liga e desliga. A distância e o liga/desliga também ficam em `config/funcionarios-client.toml`.
Não é um dublador: o tom é o da voz do computador, igual para todos. Se não houver voz no sistema, ele só escreve.

## Comportamento

- Se não achar pedra ou minério no raio de trabalho, ele sai andando uns 24 blocos numa direção nova e procura de novo (até 4 vezes) antes de desistir.

- Teletransporte: se você se afastar mais de 15 blocos, ele aparece num chão firme e seco perto de você. Se você estiver voando, ele vai para o chão embaixo de você.
- Velocidade: ele quebra blocos na velocidade real da ferramenta na mão (material, eficiência e dureza do bloco).
- Combate: 40 de vida, regenera sozinho, come comida do inventário quando está ferido, usa o escudo da mão secundária e revida se for atacado trabalhando (precisa de espada, machado ou arma).
- Ele não entra na água sozinho.
- Só quebra o que ele enxerga em linha reta (não atravessa parede). Ao cavar, só mexe em terreno natural (terra, pedra, areia, cascalho, minério) e nunca em água, lava ou baús.
- Ao quebrar, aparece a rachadura no bloco, o som e o braço balançando (visível em 1ª e 3ª pessoa).

## Armas do TACZ (opcional)

Com o TACZ instalado, ponha uma arma dele no inventário (ou na mão) e munição no inventário do funcionário,
e use "Me defender". Se algo falhar, procure por `CompatArmas` no log do jogo (`logs/latest.log`) e mande para ajuste.

Essa parte foi escrita a partir da documentação pública do TACZ e ainda não foi testada com o jogo.

## Próximas etapas (ainda não feitas)

- Salário/pagamento recorrente
- Baú vinculado para entrega
- Troca com villagers
- Construção de casas
- Skins escolhidas pelo jogador


## v0.8
- Escada: ele faz a escada UMA vez até a pedra e depois só quebra o que ficou exposto ao redor (não cava mais pra baixo sem parar).
- Central: mostra vida (barra), o que tem na mão e o inventário (ícones com quantidade).
- Vozes: no Windows cada funcionário usa uma voz instalada (português) com tom e velocidade próprios; senão cai no narrador.
  Para mais vozes: Configurações > Hora e idioma > Fala > Adicionar vozes.

## v0.9
- Pedra: depois da escada, limpa um salão 7x7 (3 de altura) e avança, até o inventário encher; aí vem te entregar.
- Madeira: sem árvore perto, procura copas nos chunks carregados (até 64 blocos) e vai até lá.
- Minério: raio-X de 20 blocos; se não achar, desce em escada até a profundidade do minério (diamante y -54) e abre túnel, minerando a veia e seguindo.
