package com.funcionarios;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.network.chat.Component;
import net.minecraft.util.FormattedCharSequence;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

/**
 * Tudo (slots, botões e fala) fica dentro de UMA janela. Assim mods de itens (JEI etc.) enxergam o tamanho
 * certo e não desenham por cima dos botões.
 */
public class FuncionarioScreen extends AbstractContainerScreen<FuncionarioMenu> {
    private static final int PAINEL_X = 222;
    private static final int LARGURA_PAINEL = 112;
    private static final int ALTURA_BOTAO = 18;
    private static final int ESPACO_BOTAO = 19;

    /** Ícone "fantasma" mostrado nos slots de arma/ferramenta vazios. */
    private static final Item[] FANTASMAS = {
            Items.IRON_SWORD, Items.IRON_SWORD, Items.IRON_PICKAXE, Items.IRON_AXE, Items.IRON_SHOVEL, Items.IRON_HOE
    };

    private Button botaoMinerio;
    private Button botaoVoz;

    public FuncionarioScreen(FuncionarioMenu menu, Inventory inventario, Component titulo) {
        super(menu, inventario, titulo);
        this.imageWidth = 342;
        this.imageHeight = 224;
        this.inventoryLabelX = FuncionarioMenu.INV_X;
        this.inventoryLabelY = FuncionarioMenu.INV_Y - 12;
    }

    @Override
    protected void init() {
        super.init();
        int x = this.leftPos + PAINEL_X;
        int y = this.topPos + 18;
        int i = 0;
        for (Tarefa tarefa : Tarefa.values()) {
            if (tarefa == Tarefa.TROCAR_MINERIO) continue;
            boolean minerio = tarefa == Tarefa.MINERIO;
            Button botao = Button.builder(Component.literal(tarefa.getRotulo()),
                            b -> Rede.CANAL.sendToServer(
                                    new PacoteComando(this.menu.getFuncionario().getId(), tarefa.ordinal())))
                    .bounds(x, y + i * ESPACO_BOTAO, minerio ? LARGURA_PAINEL - 24 : LARGURA_PAINEL, ALTURA_BOTAO)
                    .build();
            this.addRenderableWidget(botao);
            if (minerio) {
                botaoMinerio = botao;
                this.addRenderableWidget(Button.builder(Component.literal("<>"),
                                b -> Rede.CANAL.sendToServer(new PacoteComando(
                                        this.menu.getFuncionario().getId(), Tarefa.TROCAR_MINERIO.ordinal())))
                        .bounds(x + LARGURA_PAINEL - 22, y + i * ESPACO_BOTAO, 22, ALTURA_BOTAO)
                        .build());
            }
            i++;
        }
        botaoVoz = Button.builder(Component.literal("Voz"), b -> {
                    Configuracao.VOZ_ATIVA.set(!Configuracao.VOZ_ATIVA.get());
                    Configuracao.VOZ_ATIVA.save();
                })
                .bounds(x, y + i * ESPACO_BOTAO, LARGURA_PAINEL, ALTURA_BOTAO).build();
        this.addRenderableWidget(botaoVoz);
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float parcial) {
        this.renderBackground(g);
        if (botaoMinerio != null) {
            botaoMinerio.setMessage(Component.literal("Minério: " + this.menu.getFuncionario().getMinerio().getRotulo()));
        }
        if (botaoVoz != null) {
            botaoVoz.setMessage(Component.literal("Voz: " + (Configuracao.VOZ_ATIVA.get() ? "ligada" : "desligada")));
        }
        super.render(g, mouseX, mouseY, parcial);
        this.renderTooltip(g, mouseX, mouseY);
    }

    @Override
    protected void renderBg(GuiGraphics g, float parcial, int mouseX, int mouseY) {
        // janela
        g.fill(this.leftPos - 1, this.topPos - 1, this.leftPos + this.imageWidth + 1, this.topPos + this.imageHeight + 1, 0xFF000000);
        g.fill(this.leftPos, this.topPos, this.leftPos + this.imageWidth, this.topPos + this.imageHeight, 0xFFC6C6C6);

        // moldura de todos os slots
        for (Slot s : this.menu.slots) {
            int sx = this.leftPos + s.x;
            int sy = this.topPos + s.y;
            g.fill(sx - 1, sy - 1, sx + 17, sy + 17, 0xFF373737);
            g.fill(sx, sy, sx + 17, sy + 17, 0xFFFFFFFF);
            g.fill(sx, sy, sx + 16, sy + 16, 0xFF8B8B8B);
        }

        // ícones apagados nos slots de arma/ferramenta vazios
        for (int i = 0; i < FANTASMAS.length; i++) {
            Slot s = this.menu.slots.get(FuncionarioMenu.INICIO_FERR + i);
            if (!s.hasItem()) {
                int sx = this.leftPos + s.x;
                int sy = this.topPos + s.y;
                g.renderFakeItem(new ItemStack(FANTASMAS[i]), sx, sy);
                g.fill(RenderType.guiGhostRecipeOverlay(), sx, sy, sx + 16, sy + 16, 0xB08B8B8B);
            }
        }

        // caixa de status e fala, no meio da janela
        FuncionarioEntity f = this.menu.getFuncionario();
        int px = this.leftPos + 52;
        int py = this.topPos + 80;
        g.fill(px, py, px + 162, py + 58, 0xFF1E1E1E);
        g.drawString(this.font, f.getName(), px + 4, py + 4, 0xFFD700, false);
        g.drawString(this.font, Component.literal("Tarefa: " + f.getTarefa().getRotulo()), px + 4, py + 15, 0xAAAAAA, false);
        String fala = f.getFala();
        if (fala != null && !fala.isEmpty()) {
            int linhaY = py + 28;
            for (FormattedCharSequence linha : this.font.split(Component.literal(fala), 154)) {
                if (linhaY > py + 48) break;
                g.drawString(this.font, linha, px + 4, linhaY, 0xFFFFFF, false);
                linhaY += 10;
            }
        }
    }
}
