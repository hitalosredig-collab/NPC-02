# Mod Funcionários (Minecraft Java 1.20.1 / Forge 47.x)

Contrate funcionários humanoides que trabalham e defendem você.

## Como colocar pra rodar

1. Baixe o **Forge MDK 1.20.1** (versão 47.x) em https://files.minecraftforge.net e extraia numa pasta.
2. Dentro do MDK, apague `src/main/java/com/example` e `src/main/resources/META-INF/mods.toml`.
3. Copie a pasta `src` deste projeto para dentro do MDK (mesclando/substituindo).
4. No `gradle.properties` do MDK, troque: `mod_id=funcionarios`, `mod_name=Funcionarios`, `mod_group_id=com.funcionarios`.
5. Abra a pasta do MDK no IntelliJ IDEA (Java 17), deixe o Gradle sincronizar e rode a configuração `runClient`.
   Para gerar o `.jar`: `gradlew build` (sai em `build/libs`).

O mod NÃO precisa do TACZ para compilar nem para rodar. A compatibilidade é opcional e feita por reflexão.

## Gerar o .jar pelo GitHub (sem instalar nada)

1. Crie um repositório no GitHub e envie o CONTEÚDO desta pasta (`src`, `.github`, `README.md`).
   A pasta `.github` é escondida em alguns sistemas: ela precisa ir junto.
2. Abra a aba **Actions** do repositório. A compilação roda sozinha (ou use **Run workflow**).
3. Quando terminar (alguns minutos), clique na execução e baixe **funcionarios-jar** em *Artifacts*.
   Dentro do zip baixado está o `.jar` para a pasta `mods`.
4. Se a compilação falhar, clique na execução, copie a mensagem de erro do passo "Compilar" e mande para ajuste.

## Como jogar

- Receita (v0.48): **6 papéis + 2 esmeraldas + 1 diamante** (3x3, veja crafts-funcionarios.pdf) = Contrato de Funcionário (também na aba Ferramentas do criativo).
- Clique direito com o contrato num bloco para contratar.
- Clique direito no funcionário para abrir a tela.

### Tela do funcionário

Tudo fica numa janela só (compatível com mods de itens como o JEI).

- Primeira coluna à esquerda: **capacete, peitoral, calça, bota e escudo** (com o ícone de cada peça nos slots vazios).
  A armadura aparece no corpo dele e o escudo é levantado quando ele luta de perto.
- Segunda coluna: **2 slots de arma** (espada, machado, tridente ou arma do TACZ), **picareta, machado, pá e enxada**
  (com o ícone apagado quando vazios). Cada slot só aceita o tipo certo.
- Centro: o inventário dele (27 slots, estilo baú), uma caixa com nome, tarefa e fala, e o seu inventário embaixo.
- Direita: botões de comando.
- Ele pega a ferramenta direto desses slots (pá para terra e areia; picareta, machado e enxada para o resto) e a mostra na mão.
  Ferramentas e armas nos slots não são entregues a você no "Entregar itens".

### Comandos

| Botão | O que precisa | O que faz |
|---|---|---|
| Parar | nada | para tudo |
| Seguir você | nada | anda atrás de você |
| Me defender | espada, machado ou arma do TACZ | ataca monstros perto de você e quem te machucar |
| Pegar madeira | machado (mão ou inventário) | corta árvores num raio de 16 blocos |
| Minerar pedra | picareta | quebra a pedra exposta ao redor. Se não achar, procura a pedra mais próxima (mesmo enterrada) e cava uma escada até ela |
| Minerar minério | picareta | igual, mas só pega o minério escolhido no botão `<>` (Qualquer, Carvão, Ferro, Cobre, Ouro, Redstone, Lazurita, Diamante, Esmeralda) |
| Colher plantação | nada (enxada é opcional) | colhe plantações maduras e replanta |
| Entregar itens | nada | vem até você e entrega tudo, menos ferramentas e armas |

Sem a ferramenta ou arma certa, ele recusa com uma fala. Se o inventário enche no meio do trabalho,
ele entrega sozinho e volta a trabalhar. Ao morrer, solta o inventário e o equipamento.

## Central dos Funcionários

Receita: **bússola + papel** (também na aba Ferramentas do criativo). Clique direito com ela na mão para abrir a lista de todos os
seus funcionários que estão em área carregada: nome, tarefa atual, vida e distância. Os botões **Chamar** (ele volta para perto de você,
no chão, e passa a seguir você) e **Parar** funcionam de qualquer distância. A lista atualiza sozinha a cada 2 segundos.

Limite: funcionário em área descarregada (muito longe, sem você por perto) não aparece, porque o Minecraft não o está simulando.

## Voz

Os funcionários falam em voz alta (além de escrever) usando a **voz do sistema**, a mesma do narrador do Minecraft:
no Windows em português, a voz "Microsoft Maria/Daniel" etc., se estiver instalada. Só fala quando ele está a até 20 blocos de você.
O botão **Voz: ligada/desligada** na tela dele liga e desliga. A distância e o liga/desliga também ficam em `config/funcionarios-client.toml`.
Não é um dublador: o tom é o da voz do computador, igual para todos. Se não houver voz no sistema, ele só escreve.

## Comportamento

- Se não achar pedra ou minério no raio de trabalho, ele sai andando uns 24 blocos numa direção nova e procura de novo (até 4 vezes) antes de desistir.

- Teletransporte: se você se afastar mais de 15 blocos, ele aparece num chão firme e seco perto de você. Se você estiver voando, ele vai para o chão embaixo de você.
- Velocidade: ele quebra blocos na velocidade real da ferramenta na mão (material, eficiência e dureza do bloco).
- Combate: 40 de vida, regenera sozinho, come comida do inventário quando está ferido, usa o escudo da mão secundária e revida se for atacado trabalhando (precisa de espada, machado ou arma).
- Ele não entra na água sozinho.
- Só quebra o que ele enxerga em linha reta (não atravessa parede). Ao cavar, só mexe em terreno natural (terra, pedra, areia, cascalho, minério) e nunca em água, lava ou baús.
- Ao quebrar, aparece a rachadura no bloco, o som e o braço balançando (visível em 1ª e 3ª pessoa).

## Armas do TACZ (opcional)

Com o TACZ instalado, ponha uma arma dele no inventário (ou na mão) e munição no inventário do funcionário,
e use "Me defender". Se algo falhar, procure por `CompatArmas` no log do jogo (`logs/latest.log`) e mande para ajuste.

Essa parte foi escrita a partir da documentação pública do TACZ e ainda não foi testada com o jogo.

## Próximas etapas (ainda não feitas)

- Salário/pagamento recorrente
- Baú vinculado para entrega
- Troca com villagers
- Construção de casas
- Skins escolhidas pelo jogador


## v0.8
- Escada: ele faz a escada UMA vez até a pedra e depois só quebra o que ficou exposto ao redor (não cava mais pra baixo sem parar).
- Central: mostra vida (barra), o que tem na mão e o inventário (ícones com quantidade).
- Vozes: no Windows cada funcionário usa uma voz instalada (português) com tom e velocidade próprios; senão cai no narrador.
  Para mais vozes: Configurações > Hora e idioma > Fala > Adicionar vozes.

## v0.9
- Pedra: depois da escada, limpa um salão 7x7 (3 de altura) e avança, até o inventário encher; aí vem te entregar.
- Madeira: sem árvore perto, procura copas nos chunks carregados (até 64 blocos) e vai até lá.
- Minério: raio-X de 20 blocos; se não achar, desce em escada até a profundidade do minério (diamante y -54) e abre túnel, minerando a veia e seguindo.

## v0.10
- Se não consegue chegar andando até uma pedra/minério exposto, cava até ele; se o caminho do degrau falha, desliza até o degrau que ele mesmo cavou.
- Terra, pedra e folhas de passagem são descartadas (não enchem o inventário); na pedra ele guarda só pedra/minério.
- Madeira: começa pela base do tronco e derruba a árvore inteira (só árvores naturais, com folhas; casas de madeira não).

## v0.11
- Vigia: se ele passa 30 s sem quebrar nada nem avançar, avisa no chat o motivo ([Funcionário] ...), recomeça e sai do buraco (teleporta para o chão onde começou). Na 3ª vez para.
- Seguir/entregar: sem caminho (preso em buraco/mina funda), ele teleporta para o chão perto de você.

## v0.12 (menos pensar, mais fazer)
- Pedra: não anda atrás de pedra; quebra a grama/terra e desce em escada até achar pedra, aí limpa o salão 7x7 e segue até encher.
- Pedra/minério nunca desistem: se travar, recomeça (e volta para o chão onde começou).
- Árvore: quebra um tronco e derruba a árvore inteira (qualquer árvore com folhas).
- Ao encher o inventário ele vem entregar e, depois, volta direto para onde estava minerando.

## v0.13 – vozes
- Skins 0 e 2 usam voz masculina e a skin 1 usa voz feminina (se o Windows tiver as duas; senão ele muda o tom da que tiver).
- Para ter homem e mulher: Configurações > Hora e idioma > Fala > Adicionar vozes (Português do Brasil).

## v0.14
- Se há um bloco entre ele e o alvo (terra na frente da pedra, folhas na frente do tronco), ele quebra o que está atrapalhando na hora.
- Se ficar preso 2 vezes, passa a quebrar qualquer bloco comum no caminho (nunca baú, água ou lava).
- Árvore: derruba troncos e as folhas naturais juntos; alcança troncos até 6 blocos.

## v0.15 – mineração com raio-X
- O minério escolhido é procurado em todos os chunks carregados (até ~6 chunks) e ele cava direto até o mais próximo; depois da veia, vai pro próximo (um minério por minério).
- Se não há nenhum nos chunks carregados, abre túnel de busca na profundidade certa.
- Consertado: minério que estava no caminho era quebrado e jogado fora; agora é guardado.
- Mensagens [Funcionário] no chat mostram o que ele achou/está fazendo (ajuda a achar bugs).

## v0.16
- Viagem até árvore distante sem caminho (penhasco, montanha): teleporta para o chão perto do destino em vez de ficar parado.

## v0.17
- Madeira: tronco que não dá para alcançar andando (penhasco/buraco): ele teleporta para o chão perto do tronco (até 2 vezes) antes de desistir daquele.

## v0.18
- Anti-travamento rápido: depois de 4 s sem progresso ele quebra o bloco na frente dele (ou larga o alvo travado); com 20 s sem progresso reinicia tudo.
- Dica: para trabalharem enquanto você está longe construindo, o chão onde eles estão precisa estar carregado: fique até ~10 chunks de distância ou use /forceload add ~ ~ (servidor/mundo aberto).

## v0.19 – trabalho sem você
- Ao dar uma ordem de trabalho, ele guarda o ponto onde estava. Se houver um baú ou barril num raio de 12 blocos desse ponto, quando o inventário enche ele leva tudo (menos ferramentas/armas) para o baú, e volta direto para onde estava trabalhando. Sem baú por perto, ele vem entregar para você como antes.
- Para deixar eles trabalhando sozinhos: coloque um baú ao lado de onde dá a ordem.

## v0.20
- Carrega chunks como um jogador: enquanto trabalha (ou entrega), mantém uns 3 chunks em volta carregados, então segue trabalhando mesmo com você longe.
- Animação ao quebrar: braço balançando, rachadura no bloco, partículas do bloco e som.

## v0.21
- Conserto importante: o degrau cavado contava como "chegou" quando ele ainda estava na célula vizinha (distância < 1,5); ele ficava repetindo o mesmo degrau sem sair do lugar (congelado) e o vigia nem disparava. Agora só conta ao entrar na célula, e desliza até ela depois de 0,6 s se o caminho falhar.

## v0.22 – melhorias (3 níveis)
- Botão "Melhorar" na tela do funcionário. Cada nível custa material do SEU inventário (passe o mouse no botão para ver):
  - Nível 1 (2x2): 12 lingotes de ferro + 4 de ouro
  - Nível 2 (3x3): 8 lingotes de ouro + 4 diamantes
  - Nível 3 (4x4): 16 diamantes + 8 esmeraldas
- Pedra e minério quebram em área (2x2/3x3/4x4, no plano de frente para o bloco). Todos os níveis quebram mais rápido (x1,5 / x2,2 / x3,5), inclusive madeira e colheita.

## v0.23 – tela compacta
- A tela do funcionário agora tem 176x216 (tamanho de baú duplo) em vez de 342x224, para não brigar com o JEI.
- Duas abas na mesma janela: "Itens" (armadura/escudo, 2 armas, picareta/machado/pá/enxada, inventário dele e o seu) e "Comandos" (status, fala, botões, voz, melhorar).

## v0.24
- Em serviço (minerar, madeira, colher, entregar) ele não leva dano de queda, lava/fogo, afogamento nem sufocamento. Fora do serviço, volta ao normal.
- Se cair em lava ou ficar debaixo d'água por 3 s trabalhando, é levado para o chão onde começou.

## v0.25 – TACZ
- O tiro agora funciona com as duas assinaturas do TACZ (shoot(pitch, yaw) e shoot(pitch, yaw, tempo)); métodos são achados por nome.
- No chat aparecem mensagens "[Funcionário] TACZ ..." quando a arma de fogo não funciona (API diferente) ou o TACZ recusa o tiro (NOT_DRAW, COOL_DOWN, NO_AMMO...).

## v0.26 – vozes realmente diferentes
- A fala é gerada pelo Windows em um arquivo de áudio e o mod muda o tom antes de tocar: skin 0 voz masculina grave, skin 2 masculina mais leve, skin 1 feminina; a personalidade deixa mais grave/lenta (rabugento) ou mais aguda/rápida (animado).
- Se o Windows tiver vozes masculinas e femininas em português, usa cada uma pelo gênero e o tom só varia de leve.

## v0.27 – Baú do Funcionário
- Novo bloco "Baú do Funcionário" (receita: baú + esmeralda). Tem 27 slots de armazenamento e 5 slots verdes de "pedido".
- Ao terminar o trabalho / encher a mochila, o funcionário vai a este baú e guarda tudo; depois pega o que estiver nos 5 slots de pedido (armadura, escudo, ferramentas vestem/guardam; o resto vai para a mochila).
- Ao receber um comando de trabalho, se houver pedidos esperando, ele passa no baú antes de começar.
- Só o dono abre o baú. Funis/itens automáticos usam os 27 slots de armazenamento.

## v0.28 – Baús em 6 níveis, fundidos, visual de baú
- Baú com formato de baú (tampa, fecho com esmeralda), vira para o jogador ao colocar.
- Níveis: madeira (3 linhas), cobre (4), ferro (5), ouro (6), diamante (7), netherite (9). Upgrade: baú do nível anterior no meio + 4 lingotes/diamantes em cruz; netherite pela mesa de ferraria (molde + baú de diamante + lingote de netherite).
- Dois baús lado a lado (mesma direção) se fundem: abre uma tela só com os dois; o funcionário e funis enxergam o par como um baú só.
- Removidos os 5 slots de "pedido" (funcionário pegar itens do baú).
- Mineração: raio-X não varre mais os chunks toda hora quando não acha minério (menos lag).

## v0.29 – vozes por gênero, resenha, mineração sem espera
- Gênero da voz segue o nome (Cida, Lúcia, Rita, Neide = feminina; os outros = masculina). Voz masculina fica bem mais grave e continua na velocidade normal (reamostragem + WSOLA).
- Nova situação RESENHA: a cada ~45–105 s trabalhando ou seguindo ele solta uma fala de papo (30 frases, 10 por personalidade). Nomes novos: Rita, Chico, Neide, Juca.
- Mineração: sem pausas; a busca de raio-X só é pulada por 2 s (ele continua cavando) e a espera entre buscas caiu para 2 ticks.

## v0.30 – vozes de verdade (WinRT)
- Voz agora usa também as vozes do Windows 10/11 (as que aparecem em Configurações > Hora e idioma > Fala), com voz masculina real (ex.: Daniel pt-BR) quando instalada. Sem pitch grave: só usa a voz do gênero certo.
- O chat mostra uma vez a lista de vozes achadas ("[Funcionário] Vozes do seu Windows -> ...").

## v0.31 – baú no estilo mochila
- Tamanhos: madeira 27 slots (9x3), cobre 36 (9x4), ferro 54 (9x6), ouro 81 (9x9), diamante 108 (12x9), netherite 120 (12x10). Telas largas para os níveis altos.

## v0.32 – foice e espada
- Foice (qualquer item de mod com scythe/sickle/foice no nome) vale como enxada: slot de enxada, colheita e quebra de folhas/feno.
- Ao quebrar folhas, feno e blocos "de enxada" ele troca para enxada/foice; teia, bambu e plantas, para espada. Depois volta à ferramenta da tarefa.

## v0.32 – mineração mais rápida e sem travar
- Degraus cavados: ele anda reto até a célula (sem pathfinding), 0,3 bloco por tick.
- Quebra de passagem 3x mais rápida; pedra/minério 1,5x mais rápidos.

## v0.33 – baú duplo de verdade + rolagem
- Baús do MESMO nível lado a lado (mesma direção) se fundem em baú duplo, com modelo emendado, só 2 por vez (agachar ao colocar não funde).
- Bloco sem "transparência" ao redor (noOcclusion + forma própria).
- Tela com janela de até 6 linhas e barra de rolagem (roda do mouse ou arrastar); duplo tem o dobro de slots numa grade só.

## v0.34 – minério sem ficar parado
- Se 3 minérios seguidos ficam sem caminho (água/lava no meio), ele abre um túnel de busca por ~40 passos em vez de ficar tentando.
- A mensagem "achado a N blocos" aparece no máximo a cada 1 minuto; espera entre tentativas caiu para 1 tick.

## v0.35 – baús em ordem, depósito de longe, mochila, animação
- Baú do Funcionário agora tem 16 de altura (empilha sem frestas).
- O funcionário guarda os itens nos baús EM ORDEM de colocação (o mais antigo primeiro, até encher), de longe, sem andar até o baú (partículas e som no baú). Se não há baú dele, continua o comportamento antigo (baú/barril vanilla, ou entrega ao dono).
- Novo slot de mochila no funcionário (7º slot da linha de ferramentas): aceita qualquer item que exponha inventário (IItemHandler), ex.: Sophisticated Backpacks. Ele guarda primeiro na mochila; quando mochila e inventário enchem, esvazia tudo nos baús.
- Animação da tampa (3 estágios) e sons de abrir/fechar do baú vanilla.

## v0.36 – encaixe do baú igual ao vanilla
- Agachado e mirando na lateral de um baú: encaixa nele (assume a direção dele). Sem agachar: encaixa sozinho no baú ao lado de mesma direção. Antes, agachar desligava o encaixe.

## v0.36 – baús encaixam sempre
- Colocar um baú ao lado de outro do mesmo nível sempre funde (inclusive agachado), mesmo olhando de outro ângulo: o novo assume a direção do vizinho.

## v0.37 – mineração um por vez, protege construções, TACZ sem mensagens
- Melhorias 2x2/3x3/4x4: os blocos extras agora são quebrados UM por vez (fila), bem rápido (1/5 do tempo), em vez de tudo de uma vez.
- Mais rápido: passagem 1/5 do tempo, pedra/minério 1/3.
- Nunca quebra construções: qualquer bloco num raio de 2 de tábuas, tijolos, vidro, portas, baús, tochas etc. fica protegido; cobblestone deixou de contar como pedra natural. Removido o "pode quebrar qualquer bloco depois de preso".
- Sem caminho (6 bloqueios seguidos) ou travado: ele se teleporta para outro lugar (24–48 blocos) e recomeça.
- Ícone de mochila (e não de baú) no 7º slot.
- TACZ: sem munição para recarregar ele enche o pente (munição infinita); NOT_DRAW saca de novo; mensagens de chat desligadas (Configuracao.MENSAGENS = false).

## v0.38 – aba Comandos organizada + guardar no baú
- Aba Comandos em seções: Trabalho (Madeira, Pedra, Minério + trocar, Colher, Melhorar), Entrega (Entregar a mim / Guardar no baú) e Controle (Seguir, Defender, Parar). Botão Voz dentro da caixa de status.
- Novo comando "Guardar no baú": guarda tudo nos Baús do Funcionário (de longe, em ordem) ou, sem eles, vai ao baú/barril mais próximo.

## v0.39 – minério: veia inteira, alcance, sem teleportes à toa
- Minério: sem quebra em área (um bloco por vez); depois de quebrar um minério ele marca o resto da veia (blocos ligados, até 120) e vai cavando até cada um.
- Alcance de 7 blocos com linha de visão para quebrar minério de longe; raio-X escaneia 29x29 chunks carregados.
- Anti-bug: watchdog de 12 s na mineração; "mudar de lugar" só depois de 8 falhas de passagem seguidas, no máximo 1 vez a cada 20 s, e nunca para perto de construções. Proteção de construções agora num raio de 1.

## v0.40 – TACZ: tiro
- Corrigido o saque da arma: antes ele sacava de novo a cada tiro (a munição muda o NBT) e a animação de saque nunca terminava (NOT_DRAW eterno). Agora saca uma vez por tipo de arma e repete no máximo a cada 3 s.
- NEED_BOLT chama o ferrolho; pente vazio é enchido na hora (munição infinita).
- Resultados do tiro ficam no log do jogo (linhas "[Funcionarios] TACZ tiro: ...").

## v0.41 – Skins novas e gênero coerente
- 6 skins detalhadas (3 masculinas, 3 femininas) com olhos, sobrancelhas, cabelo em camada, roupas com padrão, cinto e botas.
- Sorteio define o gênero primeiro: nome, skin e voz combinam. Funcionários antigos têm a skin corrigida pelo nome ao carregar.

## v0.42 – Pedra: desce e faz túnel; mineração mais rápida
- Pedra: ignora a pedra rasa (menos de 6 blocos abaixo da superfície); desce ~8 blocos em escada e só então faz o túnel/salão.
- Pedra e minério quebram bem mais rápido (÷5 normal, ÷8 em passagem) e cada upgrade soma +50% de velocidade de mineração.

## v0.43 – Tudo que quebra dropa para ele
- Terra, pedra e blocos de passagem agora vão para o inventário dele (antes sumiam sem drop). Inventário cheio segue o fluxo de guardar no baú/entregar.

## v0.44 – Pedra: descida decidida
- Pedra: enquanto não estiver ~7 blocos abaixo da superfície, só cava a escada (não persegue pedra rasa nem salão distante); depois faz salão/túnel.
- Quando um passo da escada é bloqueado, grava no log (latest.log) a linha "[Funcionarios] passo bloqueado em ... bloco=... fluido=... construcao=..." (a cada 5 s no máximo).

## v0.45 – Pedra: escada não abre área
- Os blocos de terra da escada não geram mais o 2x2/3x3/4x4 da melhoria (isso o prendia quebrando terra sem descer). A área só vale na pedra de verdade, já embaixo.

## v0.46 – Níveis 0–5 com buffs
- Acabou o 2x2/3x3/4x4. Agora o "Melhorar" sobe do nível 0 ao 5 (máximo).
- Cada nível: quebra mais rápido (x1.4 / 1.9 / 2.6 / 3.5 / 5.0), anda +7%, vida +4, dano +1 (e cura ao melhorar).
- Custos: 1) 12 ferro + 4 ouro; 2) 8 ouro + 4 diamante; 3) 8 diamante + 8 esmeralda; 4) 16 diamante + 16 esmeralda; 5) 2 netherite + 32 diamante.

## v0.47 – Crafts mais caros
- Contrato: 1 papel + 1 diamante. Central: 1 bússola + 2 diamantes.

## v0.48 – Contrato e Central em grade 3x3
- Contrato: PPP / EDE / PPP (papel, esmeralda, diamante no meio).
- Central: IRI / RCR / IDI (ferro, redstone, bússola no meio, diamante embaixo).
- Textura da Central agora é um celular.

## v0.49 – Celular (Central) bonito
- Ícone da Central redesenhado: celular com moldura metálica, tela em degradê, ícones de apps e câmera.
- Tela da Central com visual de celular: moldura, relógio real, sinal, bateria, câmera e barra de início; cards em degradê azul.

## v0.50
- Removida a mensagem de chat "Vozes do seu Windows" que aparecia quando eles falavam.
- Botão de melhoria mais curto ("Upar p/ N", "Nível máx.") para caber sem cortar.

## v0.51 – 12 skins e mais nomes
- 12 skins (6 masculinas, 6 femininas): chapéu de palha, boné, bandana, cacheado, rabo de cavalo, coque, trança, capacete de mineiro, avental de ferreiro, colete, macacão etc.
- 26 nomes masculinos e 24 femininos; gênero, nome, skin e voz continuam combinando.

## v0.52 – Voz mais humana
- Fala um pouco mais devagar (rate 0.92), com pausas maiores em vírgulas/pontos.
- Pós-processamento: filtro suave nos agudos, eco curto de sala e entrada/saída suaves (menos metálico e menos estalos).

## v0.53 – Animações
- Modelo próprio: segura o item como o jogador, respira parado, braço livre acompanha ao trabalhar.
- Ao quebrar: braço bate sem parar (a cada 4 ticks) com som de batida do bloco; já anda balançando braços e pernas.

## v0.54 – Minério: menos "parado olhando"
- Bloco colado nele é quebrado mesmo sem linha de visão perfeita.
- Desiste de alvo inalcançável bem mais rápido (15 ticks olhando / 6 s andando, antes 40 / 20 s).
- Vigia da mineração: tenta destravar aos 2 s e 5 s e reinicia aos 8 s (antes 12 s); na primeira vez NÃO volta para a superfície, abre túnel de busca onde está; depois muda de lugar.
- Grava no latest.log "[Funcionarios] travou: ..." com o estado para diagnóstico.

## v0.55 – Central: rolagem suave e cartões separados
- Rolagem animada (desliza em vez de pular), com barra de rolagem fina; o celular não muda mais de tamanho ao rolar.
- Espaço de 8 px entre os funcionários; linhas que cabem se ajustam à altura da janela.

## v0.56 – Central sem limite de 10
- A lista da Central agora mostra até 200 funcionários (antes cortava em 10) e rola até o último.

## v0.57 – Minério: caminho reto e viagem longa
- Movimento até o minério agora é monótono (sem zigue-zague): desce em poço reto até 1 bloco do nível do minério, depois escada/túnel reto até ficar exposto.
- Para chegar na profundidade do minério (cavar sem alvo) também desce em poço.
- Se cavar ~90 passos de túnel sem achar o minério escolhido, teleporta 120–260 blocos para outra região (gerando o chunk), desce de novo e continua a busca.
- Poço/escada não desce em cima de lava.

## v0.58 – Vários minérios e veias
- Botão "..." ao lado de Minério abre a tela "Minérios preferidos": marque vários (ex.: diamante + ouro); ele vai atrás de todos os marcados. "Minerar estes" já começa.
- Raio-X prefere veias: quanto mais minérios juntos, mais atrativa; e a veia é seguida mesmo com buracos de até 2 blocos.
- Na viagem longa ele reveza o minério que usa para escolher a profundidade.

## v0.59 – Central mostra o inventário completo
- Cada cartão cresce para mostrar TODOS os tipos de item do inventário (13 por linha, várias linhas); antes só 9 e numa linha só.
- A rolagem agora é por pixel, respeitando os cartões de alturas diferentes.

## v0.60 – Itens de melhoria, Central e busca mais rápida
- Subir de nível agora é por ITEM: "Melhoria de Funcionário – Nível 1..5" (clique direito no funcionário no nível anterior). O botão do menu só mostra o nível.
  Receitas: N1 IGI/GRG/IGI (ferro, ouro, bloco de redstone); N2 GDG/DPD/GDG; N3 DED/EPE/DED; N4 BEB/EPE/BEB (blocos de diamante/esmeralda); N5 NBN/BPB/NBN (netherite/bloco de diamante). P = melhoria do nível anterior.
- Central: distância ("N blocos de você") em linha própria, sem sobrepor itens.
- Minerador carrega mais chunks (raio 5) e varre o raio-X a cada 1 s; quebra um pouco mais rápido.

## v0.61 – Corpo deitado em túnel apertado
- Em espaços de 1 bloco de altura o jogo colocava o funcionário na pose de nadar/engatinhar (corpo horizontal, pernas abertas). Agora ele nunca fica visualmente deitado nem agachado.

## v0.62 – Central em tempo real
- Atualiza 10x por segundo (antes a cada 2 s); botões não são mais recriados a cada atualização (menos piscar).
- Distância calculada a cada quadro quando o funcionário está perto; com muitos funcionários o intervalo aumenta (até 0,5 s).

## v0.63
- Mineração: minério selecionado ao alcance (do lado, na parede do túnel) é quebrado ANTES de andar.
- Minério ao lado de água agora é minerado (só lava bloqueia); torcha/construção perto não impede mais minério.
- Mais blocos de caverna contam como terreno natural (tuff, calcita, basalto, blackstone, musgo, argila etc.); "polished/smooth/cut" não é mais tratado como construção.
- Lista de alvos que falharam é limpa a cada ~25 s (não ficam bloqueados para sempre).
- Corrigido: andando/descendo pelo túnel ele nem olhava ao redor; agora para e quebra qualquer minério escolhido que passe ao alcance.
- v0.65: o alvo achado ao passar era descartado todo tick (exigia minério "exposto"), por isso ele ficava parado na frente do diamante; agora minério (inclusive de veia, enterrado) é quebrado direto e rápido.
- v0.66: depois de quebrar um minério vai para o MAIS PERTO da veia (não ordem aleatória), alcance da veia 3 blocos, quebra de minério ainda mais rápida, minério perto de água entra na busca.
- v0.67: acabou o "voar": nos degraus/poço ele anda no chão (horizontal direto, desce com gravidade, sobe só o degrau) em vez de deslizar em diagonal pelo ar.
- v0.68: degrau para cima só com o pé no chão e só desliza até célula que tenha chão embaixo (acaba de vez o pairar no poço).
- v0.69: física 100% normal nos degraus/poço: anda com MoveControl, pula degrau, cai com gravidade; removidos o deslize e os teleportes de cada tick (acabou o voo/lag).
- v0.70: ele não fica mais pulando parado: degrau alto demais/sem chegar em 2 s é abandonado; vigia de 3 s parado larga a meta, marca como falha e abre túnel por outro canto (2ª vez: muda de lugar).
- v0.71: caiu na água: ele nada até a margem mais próxima (raio 12) e sai; sem margem em ~5 s volta ao chão de onde começou.
- v0.72: removido o carregamento forçado de chunks dentro do tick (suspeito de crash); viagem de mudarDeLugar só para chunks já carregados (40-72 blocos).
- v0.73: corrigido crash (NullPointerException em dirMina ao abandonar degrau antes de definir a direção do túnel).
- v0.74: vigia de produção: 15 s sem quebrar nenhum bloco (preso em poço fundo, andando de lado pra outro em espaço aberto) = muda de lugar e recomeça em outro canto.
- v0.75: vigia de produção reduzido para 10 s.
- v0.76: baú novo colocado com o funcionário já entregando/cheio: ele passa a guardar nos Baús do Funcionário (todos, em ordem) a cada 1 s em vez de entregar tudo ao dono.
