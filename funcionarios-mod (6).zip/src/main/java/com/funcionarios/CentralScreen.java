package com.funcionarios;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;
import net.minecraft.world.item.ItemStack;

/** Central dos funcionários: vida, tarefa, o que ele tem na mão e no inventário; chamar de volta ou parar. */
public class CentralScreen extends Screen {
    private static final int LARGURA = 300;
    private static final int LINHA = 46;
    private static final int FOLGA = 8; // espaço entre um funcionário e outro
    private static final int PASSO = LINHA + FOLGA;
    private static final int TOPO = 32;
    private static final int MAX_LINHAS = 5;

    private List<PacoteLista.Entrada> lista = new ArrayList<>();
    private int tempo;
    private int rolagem;
    private float posSuave; // rolagem animada (em pixels)
    private long ultimoQuadro;
    private final List<Button> botoesChamar = new ArrayList<>();
    private final List<Button> botoesParar = new ArrayList<>();
    private boolean recebeu;

    public CentralScreen() {
        super(Component.literal("Central dos Funcionários"));
    }

    @Override
    protected void init() {
        Rede.CANAL.sendToServer(new PacoteCentral(PacoteCentral.PEDIR, 0));
        montar();
    }

    public void atualizar(List<PacoteLista.Entrada> nova) {
        this.lista = nova;
        this.recebeu = true;
        this.rolagem = Mth.clamp(rolagem, 0, rolagemMaxima());
        montar();
    }

    /** Quantas linhas cabem na tela (e no máximo MAX_LINHAS). */
    private int cabem() {
        int livre = this.height - 70 - TOPO;
        return Mth.clamp(livre / PASSO, 2, MAX_LINHAS);
    }

    private int visiveis() {
        return Math.max(1, Math.min(cabem(), lista.size()));
    }

    private static final int POR_LINHA = 13; // ícones por linha

    /** Altura do cartão: cresce para mostrar TODOS os itens do inventário. */
    private int alturaCartao(PacoteLista.Entrada e) {
        int linhas = Math.max(1, (e.itens.size() + POR_LINHA - 1) / POR_LINHA);
        return Math.max(LINHA, 25 + linhas * 18 + 5);
    }

    private int[] acumulado() {
        int[] c = new int[lista.size() + 1];
        for (int i = 0; i < lista.size(); i++) c[i + 1] = c[i] + alturaCartao(lista.get(i)) + FOLGA;
        return c;
    }

    private int areaLista() {
        return Math.max(visiveis() * PASSO - FOLGA, 100);
    }

    private int rolagemMaximaPx() {
        int[] c = acumulado();
        return Math.max(0, c[lista.size()] - FOLGA - areaLista());
    }

    private int rolagemMaxima() {
        int maxPx = rolagemMaximaPx();
        if (maxPx <= 0) return 0;
        int[] c = acumulado();
        for (int i = 0; i < lista.size(); i++) if (c[i] >= maxPx) return i;
        return Math.max(0, lista.size() - 1);
    }

    private int altura() {
        return TOPO + areaLista() + 22;
    }

    private void montar() {
        this.clearWidgets();
        botoesChamar.clear();
        botoesParar.clear();
        int x = (this.width - LARGURA) / 2;
        for (PacoteLista.Entrada e : lista) {
            Button c = Button.builder(Component.literal("Chamar"),
                            b -> Rede.CANAL.sendToServer(new PacoteCentral(PacoteCentral.CHAMAR, e.id)))
                    .bounds(x + LARGURA - 112, 0, 54, 18).build();
            Button p = Button.builder(Component.literal("Parar"),
                            b -> Rede.CANAL.sendToServer(new PacoteCentral(PacoteCentral.PARAR, e.id)))
                    .bounds(x + LARGURA - 54, 0, 48, 18).build();
            this.addRenderableWidget(c);
            this.addRenderableWidget(p);
            botoesChamar.add(c);
            botoesParar.add(p);
        }
    }

    @Override
    public void tick() {
        if (++tempo % 40 == 0) {
            Rede.CANAL.sendToServer(new PacoteCentral(PacoteCentral.PEDIR, 0));
        }
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double delta) {
        if (rolagemMaximaPx() > 0) {
            rolagem = Mth.clamp(rolagem - (int) Math.signum(delta), 0, rolagemMaxima());
            return true;
        }
        return super.mouseScrolled(mouseX, mouseY, delta);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    private ItemStack icone(GuiGraphics g, ItemStack s, int ix, int iy, int mouseX, int mouseY, ItemStack hover) {
        g.fill(ix - 1, iy - 1, ix + 17, iy + 17, 0xFF1E1E1E);
        if (s.isEmpty()) return hover;
        g.renderItem(s, ix, iy);
        g.renderItemDecorations(this.font, s, ix, iy);
        if (mouseX >= ix && mouseX < ix + 16 && mouseY >= iy && mouseY < iy + 16) return s;
        return hover;
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float parcial) {
        this.renderBackground(g);
        int x = (this.width - LARGURA) / 2;
        int y = (this.height - altura()) / 2;
        int h = altura();
        // corpo do celular: moldura metálica, borda preta e tela com degradê
        g.fill(x - 7, y - 7, x + LARGURA + 7, y + h + 7, 0xFFC4C8D6);
        g.fill(x - 6, y - 6, x + LARGURA + 6, y + h + 6, 0xFF0C0D14);
        g.fill(x - 7, y + h / 2 - 12, x - 8, y + h / 2 + 12, 0xFF8A8EA0);
        g.fillGradient(x, y, x + LARGURA, y + h, 0xFF1B1F4A, 0xFF3A2A5E);
        // barra de status: relógio, sinal e bateria
        String hora = java.time.LocalTime.now().format(java.time.format.DateTimeFormatter.ofPattern("HH:mm"));
        g.drawString(this.font, hora, x + 6, y + 3, 0xFFFFFF, false);
        for (int b2 = 0; b2 < 4; b2++) g.fill(x + LARGURA - 52 + b2 * 3, y + 9 - b2 * 2, x + LARGURA - 50 + b2 * 3, y + 10, 0xFFFFFFFF);
        g.fill(x + LARGURA - 32, y + 3, x + LARGURA - 14, y + 10, 0xFFFFFFFF);
        g.fill(x + LARGURA - 31, y + 4, x + LARGURA - 15, y + 9, 0xFF3DBE4A);
        g.fill(x + LARGURA - 14, y + 5, x + LARGURA - 12, y + 8, 0xFFFFFFFF);
        // câmera frontal e barra de início
        g.fill(x + LARGURA / 2 - 2, y - 4, x + LARGURA / 2 + 2, y - 2, 0xFF2A2E48);
        g.fill(x + LARGURA / 2 - 20, y + h - 4, x + LARGURA / 2 + 20, y + h - 2, 0xFFE8E8F0);
        g.drawCenteredString(this.font, this.title, this.width / 2, y + 12, 0xFFD700);

        if (lista.isEmpty()) {
            String msg = recebeu ? "Nenhum funcionário em área carregada." : "Carregando...";
            g.drawCenteredString(this.font, Component.literal(msg), this.width / 2, y + TOPO + 9, 0xAAAAAA);
        }

        // rolagem suave: a posição anima até a linha escolhida (independente da taxa de quadros)
        long agora = System.nanoTime();
        float dt = ultimoQuadro == 0 ? 0.016F : Math.min(0.1F, (agora - ultimoQuadro) / 1.0e9F);
        ultimoQuadro = agora;
        int[] cum = acumulado();
        int maxPx = rolagemMaximaPx();
        float alvoPx = Math.min(cum[Mth.clamp(rolagem, 0, lista.size())], maxPx);
        posSuave += (alvoPx - posSuave) * (1.0F - (float) Math.exp(-dt * 12.0F));
        if (Math.abs(alvoPx - posSuave) < 0.4F) posSuave = alvoPx;

        int topoLista = y + TOPO;
        int fundoLista = topoLista + areaLista();
        ItemStack hover = ItemStack.EMPTY;
        g.enableScissor(x, topoLista, x + LARGURA, fundoLista);
        for (int k = 0; k < lista.size(); k++) {
            PacoteLista.Entrada e = lista.get(k);
            int ly = topoLista + Math.round(cum[k] - posSuave);
            int hc = alturaCartao(e);
            boolean dentro = ly >= topoLista && ly + hc - 2 <= fundoLista;
            if (k < botoesChamar.size()) {
                botoesChamar.get(k).setY(ly + 3);
                botoesParar.get(k).setY(ly + 3);
                botoesChamar.get(k).visible = dentro;
                botoesParar.get(k).visible = dentro;
            }
            if (ly + hc < topoLista || ly > fundoLista) continue;
            g.fillGradient(x + 4, ly, x + LARGURA - 4, ly + hc - 2, 0xCC3A3F6A, 0xCC2A2D4C);
            g.fill(x + 4, ly, x + 6, ly + hc - 2, 0xFF7FB2FF);

            g.drawString(this.font, Component.literal(e.nome), x + 10, ly + 4, 0xFFD700, false);
            g.drawString(this.font, Component.literal(Tarefa.de(e.tarefa).getRotulo()), x + 10, ly + 15, 0xFFFFFF, false);

            // vida (barra + número)
            float prop = e.vidaMax <= 0 ? 0 : Mth.clamp(e.vida / e.vidaMax, 0.0F, 1.0F);
            int cor = prop > 0.5F ? 0xFF3DBE4A : (prop > 0.25F ? 0xFFE0B020 : 0xFFD03030);
            g.drawString(this.font, Component.literal("Vida " + (int) e.vida + "/" + (int) e.vidaMax), x + 110, ly + 4, 0xDDDDDD, false);
            g.fill(x + 110, ly + 15, x + 180, ly + 22, 0xFF000000);
            g.fill(x + 111, ly + 16, x + 111 + (int) (68 * prop), ly + 21, cor);

            // mão e inventário
            g.drawString(this.font, Component.literal("Mão"), x + 10, ly + 29, 0xAAAAAA, false);
            hover = icone(g, e.mao, x + 32, ly + 25, mouseX, mouseY, hover);
            int ix = x + 56;
            int n = 0;
            for (ItemStack s : e.itens) {
                hover = icone(g, s, x + 56 + (n % POR_LINHA) * 18, ly + 25 + (n / POR_LINHA) * 18, mouseX, mouseY, hover);
                n++;
            }
            if (e.itens.isEmpty()) {
                g.drawString(this.font, Component.literal("inventário vazio"), ix, ly + 29, 0x888888, false);
            }
            g.drawString(this.font, Component.literal(e.distancia + " blocos"), x + LARGURA - 58, ly + 29, 0xAAAAAA, false);
        }
        super.render(g, mouseX, mouseY, parcial); // botões, também recortados na área da lista
        g.disableScissor();
        if (mouseY < topoLista || mouseY > fundoLista) hover = ItemStack.EMPTY;
        if (maxPx > 0) {
            // barra de rolagem fina à direita
            int total = lista.size();
            int alt = fundoLista - topoLista;
            int barra = Math.max(12, alt * alt / (alt + maxPx));
            int pos = topoLista + (int) ((alt - barra) * (posSuave / maxPx));
            g.fill(x + LARGURA - 3, topoLista, x + LARGURA - 1, fundoLista, 0x55FFFFFF);
            g.fill(x + LARGURA - 3, pos, x + LARGURA - 1, pos + barra, 0xFF9FB8FF);
            g.drawCenteredString(this.font, Component.literal("Role o mouse para ver os outros (" + total + ")"),
                    this.width / 2, fundoLista + 8, 0xA0A8D0);
        }
        if (!hover.isEmpty()) {
            g.renderTooltip(this.font, hover, mouseX, mouseY);
        }
    }
}
