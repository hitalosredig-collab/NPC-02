package com.funcionarios;

import com.mojang.logging.LogUtils;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.Locale;
import org.slf4j.Logger;

/**
 * Voz com variedade no Windows: usa o sintetizador do sistema (System.Speech) por um PowerShell que fica aberto.
 * Cada funcionário escolhe uma das vozes instaladas (em português, se houver) e tem tom e velocidade próprios,
 * então mesmo com uma voz só dá para ter vozes bem diferentes. Em outros sistemas, ou se algo falhar, o mod usa o narrador.
 */
public final class VozWindows {
    private static final Logger LOG = LogUtils.getLogger();

    private static final String SCRIPT = """
            Add-Type -AssemblyName System.Speech
            $s = New-Object System.Speech.Synthesis.SpeechSynthesizer
            $todas = @($s.GetInstalledVoices() | Where-Object { $_.Enabled } | ForEach-Object { $_.VoiceInfo })
            $pt = @($todas | Where-Object { $_.Culture.Name -like 'pt*' })
            if ($pt.Count -gt 0) { $todas = $pt }
            [Console]::InputEncoding = [Text.Encoding]::UTF8
            while (($linha = [Console]::In.ReadLine()) -ne $null) {
              try {
                $p = $linha.Split('|')
                $quer = 'Male'; if ($p[0] -eq '1') { $quer = 'Female' }
                $mesmo = @($todas | Where-Object { $_.Gender.ToString() -eq $quer })
                $ajuste = 0
                if ($mesmo.Count -gt 0) { $voz = $mesmo[[int]$p[4] % $mesmo.Count] }
                else {
                  $voz = $todas[[int]$p[4] % $todas.Count]
                  if ($quer -eq 'Male' -and $voz.Gender.ToString() -eq 'Female') { $ajuste = -5 }
                  if ($quer -eq 'Female' -and $voz.Gender.ToString() -eq 'Male') { $ajuste = 4 }
                }
                $tom = [int]$p[1] + $ajuste
                $tomTxt = [string]$tom + 'st'; if ($tom -ge 0) { $tomTxt = '+' + $tomTxt }
                $texto = [Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($p[3]))
                $s.SelectVoice($voz.Name)
                $esc = [Security.SecurityElement]::Escape($texto)
                $ssml = "<speak version='1.0' xmlns='http://www.w3.org/2001/10/synthesis' xml:lang='" + $voz.Culture.Name + "'><prosody pitch='" + $tomTxt + "' rate='" + $p[2] + "'>" + $esc + "</prosody></speak>"
                try { $s.SpeakSsml($ssml) } catch { $s.Speak($texto) }
              } catch { }
            }
            """;

    private static Process processo;
    private static BufferedWriter escritor;
    private static boolean falhou;
    private static int partidas;

    private VozWindows() {}

    public static boolean disponivel() {
        return !falhou && System.getProperty("os.name", "").toLowerCase(Locale.ROOT).contains("win");
    }

    private static void garantir() throws IOException {
        if (processo != null && processo.isAlive()) return;
        if (++partidas > 3) {
            throw new IOException("PowerShell de voz caiu várias vezes");
        }
        String codificado = Base64.getEncoder().encodeToString(SCRIPT.getBytes(StandardCharsets.UTF_16LE));
        ProcessBuilder pb = new ProcessBuilder("powershell.exe", "-NoProfile", "-NonInteractive",
                "-ExecutionPolicy", "Bypass", "-EncodedCommand", codificado);
        pb.redirectErrorStream(true);
        pb.redirectOutput(ProcessBuilder.Redirect.DISCARD);
        processo = pb.start();
        escritor = new BufferedWriter(new OutputStreamWriter(processo.getOutputStream(), StandardCharsets.UTF_8));
        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            if (processo != null) processo.destroy();
        }));
    }

    private static String sinal(int valor) {
        return (valor >= 0 ? "+" : "") + valor;
    }

    /** Devolve false se não deu para usar (aí o chamador cai no narrador comum). */
    public static synchronized boolean falar(String texto, int genero, int indice, int tomSemitons, int velocidadePorcento) {
        if (!disponivel()) return false;
        try {
            garantir();
            String b64 = Base64.getEncoder().encodeToString(texto.getBytes(StandardCharsets.UTF_8));
            escritor.write(genero + "|" + tomSemitons + "|" + sinal(velocidadePorcento) + "%|" + b64 + "|" + Math.abs(indice) + "\n");
            escritor.flush();
            return true;
        } catch (IOException | RuntimeException e) {
            falhou = true;
            LOG.warn("[Funcionarios] Voz do Windows indisponível, usando o narrador comum.", e);
            if (processo != null) processo.destroy();
            return false;
        }
    }
}
