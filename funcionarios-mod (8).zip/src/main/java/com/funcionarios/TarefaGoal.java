package com.funcionarios;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.EnumSet;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.HoeItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ShovelItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.CropBlock;
import net.minecraft.world.level.block.EntityBlock;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.block.LeavesBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.level.chunk.LevelChunkSection;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.pathfinder.Path;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.common.Tags;

/**
 * A "IA" do funcionário: seguir, entregar e trabalhar (madeira, pedra, minério, colheita).
 *
 * Regras de trabalho:
 * - só quebra um bloco se tiver linha de visão direta até ele (nunca atravessa parede);
 * - se não achar pedra/minério exposto, escolhe o mais próximo (mesmo enterrado) e cava uma escada
 *   até ele, só em terreno natural (terra, pedra, areia...), sem tocar em água, lava ou baús;
 * - ao chegar na pedra, passa a quebrar tudo que ficou exposto ao redor.
 */
public class TarefaGoal extends Goal {
    private final FuncionarioEntity f;
    private final DefesaLogica defesa;

    private Tarefa ultima = Tarefa.PARAR;
    private BlockPos alvo;      // bloco sendo quebrado
    private BlockPos destino;   // lugar para onde andar durante a escavação
    private boolean escavando;  // true se o alvo atual é só passagem (não é o que procuramos)
    private final Set<BlockPos> falhas = new HashSet<>();
    private long xrayPausa;
    private final ArrayDeque<BlockPos> filaArea = new ArrayDeque<>();
    private boolean alvoArea;
    private final ArrayDeque<BlockPos> veia = new ArrayDeque<>();
    private int falhasPasso;
    private long ultimaMudanca = -10000;
    private final java.util.Map<BlockPos, Boolean> protegidos = new java.util.HashMap<>();
    private long limpezaProt;
    private long ultimoXrayInfo;
    private int falhasOre;
    private int tunelForcado;
    private long proxResenha;
    private final ArrayDeque<BlockPos> fila = new ArrayDeque<>();
    private int progresso;
    private int estagio = -1;
    private int tentativas;
    private int esperaBusca;
    private int tempoSemChegar;
    private int recalculos;
    private int semVisao;
    private int travados;
    private int exploracoes;
    private boolean recentrar;
    private BlockPos centro;      // onde a escada chegou na pedra: o serviço fica em volta daqui
    private boolean viaEscada;
    private boolean escadaFeita;
    private boolean modoSalao;   // pedra: depois da escada, limpa um salão 7x7 e vai avançando
    private Direction dirSalao;
    private Direction dirMina;   // minério: direção do túnel de busca
    private int viagens;      // madeira: viagens até árvores distantes
    private int passosMina;
    private BlockPos metaForcada; // pedra/minério exposto mas sem caminho: cava até ele
    private int forcadas;
    private int semProgresso;
    private int teleportesAlvo;
    private BlockPos oreXray;   // minério escolhido pelo raio-X
    private long ultimoInfo = -1000;
    private int bloqueios;
    private int estouros;
    private int preso;
    private int entrega;
    private boolean passoTunel;   // o destino atual é um degrau que ele mesmo cavou

    public TarefaGoal(FuncionarioEntity funcionario) {
        this.f = funcionario;
        this.defesa = new DefesaLogica(funcionario);
        this.setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
    }

    @Override
    public boolean canUse() {
        return f.getTarefa() != Tarefa.PARAR;
    }

    @Override
    public boolean canContinueToUse() {
        return f.getTarefa() != Tarefa.PARAR;
    }

    @Override
    public void stop() {
        soltarAlvo();
        destino = null;
        f.getNavigation().stop();
        defesa.resetar();
        ultima = Tarefa.PARAR;
    }

    @Override
    public void tick() {
        Tarefa t = f.getTarefa();
        if (t != ultima) {
            ultima = t;
            soltarAlvo();
            destino = null;
            escavando = false;
            falhas.clear();
            fila.clear();
            tentativas = 0;
            esperaBusca = 0;
            tempoSemChegar = 0;
            recalculos = 0;
            semVisao = 0;
            travados = 0;
            exploracoes = 0;
            recentrar = false;
            centro = null;
            viaEscada = false;
            escadaFeita = false;
            modoSalao = false;
            dirSalao = null;
            dirMina = null;
            viagens = 0;
            passosMina = 0;
            metaForcada = null;
            forcadas = 0;
            passoTunel = false;
            semProgresso = 0;
            teleportesAlvo = 0;
            oreXray = null;
            falhasOre = 0;
            tunelForcado = 0;
            filaArea.clear();
            veia.clear();
            falhasPasso = 0;
            alvoArea = false;
            bloqueios = 0;
            estouros = 0;
            preso = 0;
            entrega = 0;
            defesa.resetar();
        }
        if (t.ehTrabalho() && defesa.revidarSeAtacado()) {
            return;
        }
        if (t.ehTrabalho() || t == Tarefa.SEGUIR) {
            long agora = f.level().getGameTime();
            if (proxResenha == 0) proxResenha = agora + 400 + f.getRandom().nextInt(600);
            if (agora >= proxResenha) {
                proxResenha = agora + 900 + f.getRandom().nextInt(1200); // uma resenha a cada ~45-105 s
                f.falar(Falas.Situacao.RESENHA);
            }
        }
        switch (t) {
            case SEGUIR -> seguir();
            case DEFENDER -> defesa.tick();
            case ENTREGAR -> entregar();
            case MADEIRA, PEDRA, MINERIO, COLHER -> trabalhar(t);
            default -> { }
        }
    }

    // ------------------------------------------------------------------ seguir / entregar

    private void irAte(Player dono, double velocidade) {
        if (f.getNavigation().isDone() || f.tickCount % 10 == 0) {
            f.getNavigation().moveTo(dono, velocidade);
        }
    }

    private void seguir() {
        Player dono = f.getDonoJogador();
        if (dono == null) return;
        double d2 = f.distanceToSqr(dono);
        if (d2 > 225.0D && f.teleportarParaDono(dono)) {
            return;
        }
        f.getLookControl().setLookAt(dono, 30.0F, 30.0F);
        if (d2 > 9.0D) {
            irAte(dono, 1.15D);
            // sem caminho (ex.: preso num buraco): teleporta para o chão perto do dono
            if (d2 > 36.0D && f.getNavigation().isDone()) {
                if (++preso > 40 && f.teleportarParaDono(dono)) preso = 0;
            } else {
                preso = 0;
            }
        } else {
            f.getNavigation().stop();
            preso = 0;
        }
    }

    /** Inventário cheio durante o trabalho: leva para o baú/barril perto de onde começou e volta a trabalhar. */
    private void entregarNoBau(BlockPos bau) {
        Vec3 c = Vec3.atCenterOf(bau);
        if (f.distanceToSqr(c) > 6.25D) {
            f.getLookControl().setLookAt(c.x, c.y, c.z);
            if (f.getNavigation().isDone() || f.tickCount % 20 == 0) {
                Path caminho = f.getNavigation().createPath(bau, 1);
                if (caminho != null) f.getNavigation().moveTo(caminho, 1.2D);
            }
            entrega++;
            if (f.getNavigation().isDone()) preso++;
            if ((preso > 40 || entrega > 600) && f.teleportarParaSeguro(bau)) {
                preso = 0;
                entrega = 0;
            }
            return;
        }
        preso = 0;
        entrega = 0;
        boolean sobrou = f.depositarNoBau(bau);
        f.setBauAlvo(null);
        if (sobrou) { // baú cheio ou sumiu: sem dono por perto, para; com dono, entrega a ele no próximo tick
            if (f.getDonoJogador() == null) {
                f.falar(Falas.Situacao.INV_CHEIO);
                f.definirTarefa(Tarefa.PARAR);
            }
            return;
        }
        f.retomarOuParar();
    }

    private void entregar() {
        BlockPos bau = f.getBauAlvo();
        if (bau != null) {
            entregarNoBau(bau);
            return;
        }
        Player dono = f.getDonoJogador();
        if (dono == null) {
            f.falar(Falas.Situacao.LONGE);
            f.definirTarefa(Tarefa.PARAR);
            return;
        }
        double d2 = f.distanceToSqr(dono);
        if (d2 > 225.0D && f.teleportarParaDono(dono)) {
            return;
        }
        f.getLookControl().setLookAt(dono, 30.0F, 30.0F);
        if (d2 > 6.25D) {
            irAte(dono, 1.2D);
            entrega++;
            if (f.getNavigation().isDone()) preso++;
            if ((preso > 40 || entrega > 600) && f.teleportarParaDono(dono)) {
                preso = 0;
                entrega = 0;
            }
            return;
        }
        preso = 0;
        entrega = 0;
        f.entregarItens(dono);
        f.falar(Falas.Situacao.ENTREGUEI);
        f.retomarOuParar();
    }

    // ------------------------------------------------------------------ trabalho

    private void trabalhar(Tarefa t) {
        int parado = ++semProgresso;
        boolean mina = t == Tarefa.PEDRA || t == Tarefa.MINERIO;
        if (parado == 60 || parado == 150) destravar();
        if (parado > (mina ? 240 : 400)) {
            travou();
            return;
        }
        Class<? extends Item> tipo = f.ferramentaPara(t);
        if (tipo != null) {
            if (f.acharFerramenta(tipo).isEmpty()) {
                f.falar(Falas.Situacao.FERRAMENTA_QUEBROU);
                f.definirTarefa(Tarefa.PARAR);
                return;
            }
        }

        if (alvo == null && destino == null) {
            if (--esperaBusca > 0) return;
            if (escolherProximo(t)) {
                tentativas = 0;
            } else {
                tentativas++;
                esperaBusca = (t == Tarefa.PEDRA || t == Tarefa.MINERIO) ? 2 : 20;
                if (tentativas >= 3 && t != Tarefa.PEDRA && t != Tarefa.MINERIO) {
                    avisar("parou: nada para fazer (tarefa " + t + ")");
                    f.falar(Falas.Situacao.NADA_ACHADO);
                    f.definirTarefa(Tarefa.PARAR);
                }
            }
            return;
        }
        if (alvo == null) {
            andar();
            return;
        }
        minerarAlvo(t);
    }

    /** Define o próximo alvo (ou destino). Devolve false se não há mais nada a fazer. */
    private boolean escolherProximo(Tarefa t) {
        Level nivel = f.level();

        // 0-) blocos extras da melhoria (2x2, 3x3, 4x4): UM por vez, bem rápido
        while (!filaArea.isEmpty()) {
            BlockPos p = filaArea.poll();
            BlockState e = nivel.getBlockState(p);
            if (e.isAir() || falhas.contains(p) || !naturalCavavel(e) || !podeCavar(p, e)) continue;
            boolean guardar = t == Tarefa.PEDRA ? ehPedra(e) : (t == Tarefa.MINERIO && f.getMinerio().serve(e));
            alvo = p;
            alvoArea = true;
            escavando = !guardar;
            return true;
        }

        // 0) blocos de passagem pendentes (parte da escada)
        while (!fila.isEmpty()) {
            BlockPos p = fila.poll();
            BlockState e = nivel.getBlockState(p);
            if (!falhas.contains(p) && passagemOk(e, p)) {
                alvo = p;
                escavando = true;
                return true;
            }
        }

        // 0-b) resto da veia de minério: cava até cada bloco que sobrou (mesmo sem estar exposto)
        if (t == Tarefa.MINERIO && metaForcada == null) {
            while (!veia.isEmpty()) {
                BlockPos p = veia.poll();
                if (f.getMinerio().serve(nivel.getBlockState(p)) && !falhas.contains(p)) {
                    metaForcada = p;
                    break;
                }
            }
        }

        // 0a) alvo exposto que não deu para alcançar andando: cava até ele
        if (metaForcada != null) {
            BlockPos m = metaForcada;
            BlockState e = nivel.getBlockState(m);
            boolean serveVeia = t == Tarefa.MINERIO && f.getMinerio().serve(e);
            if (falhas.contains(m) || !(valido(t, e, m) || serveVeia)) {
                metaForcada = null;
            } else if (f.getEyePosition().distanceToSqr(Vec3.atCenterOf(m)) <= (t == Tarefa.MINERIO ? 49.0D : 9.0D) && veAlvo(m)) {
                alvo = m;
                escavando = false;
                metaForcada = null;
                return true;
            } else {
                return irParaMeta(m);
            }
        }

        // 0b) pedra: salão em volta de onde a escada chegou
        if (t == Tarefa.PEDRA && modoSalao && centro != null) {
            if (escolherSalao()) return true;
            modoSalao = false;
            centro = null;
            return cavarEmFrente();
        }

        // 1) o que procuramos, já exposto
        BlockPos exposto = buscarExposto(t);
        if (exposto != null) {
            alvo = exposto;
            escavando = false;
            return true;
        }

        // 2) madeira: vai até onde tem árvore; colheita não escava
        if (t == Tarefa.MADEIRA) {
            if (buscarMadeiraLonge()) return true;
            return explorar();
        }
        if (t != Tarefa.PEDRA && t != Tarefa.MINERIO) return false;

        // 3) escavar uma escada até o mais próximo
        // a escada só é feita UMA vez: depois de chegar na pedra ele só quebra o que ficou exposto ao redor
        if (t == Tarefa.MINERIO && escadaFeita) { // veio acabou: procura a próxima
            escadaFeita = false;
            centro = null;
            viaEscada = false;
        }
        if (t == Tarefa.PEDRA) return cavarEmFrente(); // quebra a grama/terra e desce até achar pedra
        // minério: raio-X em todos os chunks carregados; vai direto no mais próximo
        if (tunelForcado > 0) {
            tunelForcado--;
            return cavarEmFrente();
        }
        if (oreXray == null || falhas.contains(oreXray) || !f.getMinerio().serve(nivel.getBlockState(oreXray))) {
            oreXray = null;
            if (nivel.getGameTime() >= xrayPausa) { // só pula a varredura; ele continua cavando
                oreXray = xray();
                if (oreXray == null) xrayPausa = nivel.getGameTime() + 40; // não varre os chunks toda hora (evita lag)
            }
            if (oreXray != null && nivel.getGameTime() - ultimoXrayInfo > 1200) {
                ultimoXrayInfo = nivel.getGameTime();
                info(f.getMinerio().getRotulo() + " achado a " + (int) Math.sqrt(f.blockPosition().distSqr(oreXray))
                        + " blocos (" + oreXray.toShortString() + "), indo cavar até lá");
 } else if (oreXray == null) {
                info("raio-X não achou " + f.getMinerio().getRotulo() + " nos chunks carregados; cavando túnel de busca");
            }
        }
        if (oreXray != null) return irParaMeta(oreXray);
        return cavarEmFrente();
    }

    private void info(String texto) {
        if (!Configuracao.MENSAGENS) return;
        long agora = f.level().getGameTime();
        if (agora - ultimoInfo < 100) return;
        ultimoInfo = agora;
        Player dono = f.getDonoJogador();
        if (dono != null) dono.sendSystemMessage(Component.literal("[Funcionário] " + texto));
    }

    /** Raio-X: o minério escolhido mais próximo em qualquer chunk carregado (consulta rápida por seção). */
    private BlockPos xray() {
        Level nivel = f.level();
        BlockPos pe = f.blockPosition();
        int cx0 = pe.getX() >> 4;
        int cz0 = pe.getZ() >> 4;
        BlockPos melhor = null;
        double melhorD = Double.MAX_VALUE;
        Minerio quer = f.getMinerio();
        for (int cx = cx0 - 14; cx <= cx0 + 14; cx++) {
            for (int cz = cz0 - 14; cz <= cz0 + 14; cz++) {
                LevelChunk chunk = nivel.getChunkSource().getChunkNow(cx, cz);
                if (chunk == null) continue;
                LevelChunkSection[] secoes = chunk.getSections();
                for (int i = 0; i < secoes.length; i++) {
                    LevelChunkSection sec = secoes[i];
                    if (sec == null || sec.hasOnlyAir() || !sec.maybeHas(quer::serve)) continue;
                    int y0 = chunk.getMinBuildHeight() + i * 16;
                    for (int x = 0; x < 16; x++) {
                        for (int y = 0; y < 16; y++) {
                            for (int z = 0; z < 16; z++) {
                                if (!quer.serve(sec.getBlockState(x, y, z))) continue;
                                BlockPos p = new BlockPos(cx * 16 + x, y0 + y, cz * 16 + z);
                                double d = pe.distSqr(p);
                                if (d >= melhorD || falhas.contains(p) || temFluidoPerto(p)) continue;
                                melhorD = d;
                                melhor = p;
                            }
                        }
                    }
                }
            }
        }
        return melhor;
    }

    /** Nada por perto: anda uns 24 blocos numa direção nova e procura de novo (até 4 vezes). */
    private boolean explorar() {
        if (exploracoes >= 4) return false;
        Level nivel = f.level();
        BlockPos pe = f.blockPosition();
        for (int i = 0; i < 4; i++) {
            Direction d = Direction.from2DDataValue(exploracoes + i + f.getRandom().nextInt(4));
            BlockPos ponto = pe.relative(d, 24);
            if (!nivel.hasChunkAt(ponto)) continue;
            BlockPos topo = nivel.getHeightmapPos(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, ponto);
            if (!nivel.getBlockState(topo.below()).getFluidState().isEmpty()) continue;
            exploracoes++;
            destino = topo.immutable();
            recentrar = true;
            tempoSemChegar = 0;
            return true;
        }
        exploracoes = 4;
        return false;
    }

    private BlockPos buscarExposto(Tarefa t) {
        Level nivel = f.level();
        BlockPos c = centro != null ? centro : (t == Tarefa.MINERIO ? f.blockPosition() : f.getCasa());
        int r = centro != null ? 6 : (t == Tarefa.MINERIO ? 8 : FuncionarioEntity.RAIO);
        BlockPos melhor = null;
        double melhorDist = Double.MAX_VALUE;
        for (BlockPos p : BlockPos.betweenClosed(c.offset(-r, -r, -r), c.offset(r, r, r))) {
            if (falhas.contains(p) || !nivel.hasChunkAt(p)) continue;
            BlockState estado = nivel.getBlockState(p);
            if (!valido(t, estado, p)) continue;
            double d = f.distanceToSqr(Vec3.atCenterOf(p));
            if (t == Tarefa.MADEIRA && nivel.getBlockState(p.below()).is(BlockTags.LOGS)) d += 10000.0D;
            if ((t == Tarefa.PEDRA || t == Tarefa.MINERIO)
                    && (f.getEyePosition().distanceToSqr(Vec3.atCenterOf(p)) > (t == Tarefa.MINERIO ? 49.0D : 20.0D) || !veAlvo(p))) continue;
            if (d < melhorDist) {
                melhorDist = d;
                melhor = p.immutable();
            }
        }
        return melhor;
    }

    private boolean planejarEscavacao(Tarefa t) {
        BlockPos meta = maisProximo(t, f.blockPosition(), 20, 14);
        if (meta == null) return false;
        return irParaMeta(meta);
    }

    private boolean irParaMeta(BlockPos meta) {
        Level nivel = f.level();
        BlockPos pe = f.blockPosition();

        int dx = meta.getX() - pe.getX();
        int dz = meta.getZ() - pe.getZ();
        Direction d;
        if (dx == 0 && dz == 0) {
            d = f.getDirTunel();
        } else if (Math.abs(dx) >= Math.abs(dz)) {
            d = dx >= 0 ? Direction.EAST : Direction.WEST;
        } else {
            d = dz >= 0 ? Direction.SOUTH : Direction.NORTH;
        }
        int passo = Integer.compare(meta.getY(), pe.getY()); // -1 desce, 0 reto, +1 sobe
        return planejarPasso(meta, d, passo);
    }

    /** Um passo de escavação (3 blocos de altura livres). meta == null: túnel de exploração. */
    private boolean planejarPasso(BlockPos meta, Direction d, int passo) {
        Level nivel = f.level();
        BlockPos pe = f.blockPosition();
        BlockPos frente = pe.relative(d);

        List<BlockPos> limpar = new ArrayList<>();
        BlockPos novoPe;
        if (passo < 0) {
            limpar.add(frente.above());
            limpar.add(frente);
            limpar.add(frente.below());
            novoPe = frente.below();
        } else if (passo > 0) {
            limpar.add(pe.above(2));
            limpar.add(frente.above());
            limpar.add(frente.above(2));
            novoPe = frente.above();
        } else {
            limpar.add(frente);
            limpar.add(frente.above());
            novoPe = frente;
        }

        List<BlockPos> sobrando = new ArrayList<>();
        for (BlockPos p : limpar) {
            BlockState e = nivel.getBlockState(p);
            boolean livre = e.getCollisionShape(nivel, p).isEmpty() && e.getFluidState().isEmpty();
            if (livre) continue;
            if (!passagemOk(e, p)) {
                // caminho bloqueado por algo que não devemos quebrar: tenta outra meta
                bloquear(meta);
                return true;
            }
            sobrando.add(p.immutable());
        }
        if (sobrando.isEmpty()) {
            if (nivel.getBlockState(novoPe.below()).getCollisionShape(nivel, novoPe.below()).isEmpty()
                    && passo >= 0 && !nivel.getBlockState(novoPe.below()).getFluidState().isEmpty()) {
                bloquear(meta);
                return true;
            }
            destino = novoPe.immutable();
            passoTunel = true;
            viaEscada = meta != null;
            dirSalao = d;
            tempoSemChegar = 0;
            return true;
        }
        alvo = sobrando.get(0);
        escavando = true;
        viaEscada = meta != null;
        dirSalao = d;
        for (int i = 1; i < sobrando.size(); i++) fila.add(sobrando.get(i));
        return true;
    }

    /** Derruba o resto da árvore (troncos ligados com folhas naturais) para não sobrar tronco flutuando. */
    private boolean derrubarArvore(BlockPos base) {
        Level nivel = f.level();
        List<BlockPos> troncos = new ArrayList<>();
        Set<BlockPos> vistos = new HashSet<>();
        ArrayDeque<BlockPos> pilha = new ArrayDeque<>();
        pilha.add(base.immutable());
        vistos.add(base.immutable());
        boolean natural = false;
        while (!pilha.isEmpty() && troncos.size() < 200) {
            BlockPos p = pilha.poll();
            for (int dx = -1; dx <= 1; dx++) {
                for (int dy = -1; dy <= 1; dy++) {
                    for (int dz = -1; dz <= 1; dz++) {
                        BlockPos q = p.offset(dx, dy, dz);
                        if (vistos.contains(q)) continue;
                        BlockState e = nivel.getBlockState(q);
                        if (!e.is(BlockTags.LOGS)) continue;
                        vistos.add(q.immutable());
                        troncos.add(q.immutable());
                        pilha.add(q.immutable());
                        for (Direction d : Direction.values()) {
                            BlockState v = nivel.getBlockState(q.relative(d));
                            if (v.getBlock() instanceof LeavesBlock) {
                                natural = true;
                            }
                        }
                    }
                }
            }
        }
        if (!natural || troncos.size() >= 200) return false; // parede/casa de madeira: não mexe
        boolean cheio = false;
        for (BlockPos p : troncos) {
            if (!nivel.getBlockState(p).is(BlockTags.LOGS)) continue;
            if (f.quebrar(p, Tarefa.MADEIRA)) cheio = true;
        }
        // folhas da árvore (só as naturais) somem junto
        List<BlockPos> centros = new ArrayList<>(troncos);
        centros.add(base.immutable());
        int apagadas = 0;
        for (BlockPos c : centros) {
            for (BlockPos q : BlockPos.betweenClosed(c.offset(-3, -2, -3), c.offset(3, 3, 3))) {
                if (apagadas >= 600) break;
                BlockState v = nivel.getBlockState(q);
                if (v.getBlock() instanceof LeavesBlock
                        && !v.getValue(net.minecraft.world.level.block.state.properties.BlockStateProperties.PERSISTENT)) {
                    nivel.destroyBlock(q, false, f);
                    apagadas++;
                }
            }
        }
        return cheio;
    }

    /** 4 s sem progresso: quebra o que estiver na frente dele (qualquer bloco comum) ou larga o alvo travado. */
    private void destravar() {
        if (alvo != null) {
            falharAlvo();
            return;
        }
        destino = null;
        passoTunel = false;
        f.getNavigation().stop();
        bloqueios = Math.max(bloqueios, 2);
        Direction d = f.getDirection();
        BlockPos pe = f.blockPosition();
        BlockPos[] candidatos = {pe.relative(d), pe.relative(d).above(), pe.below(), pe.above(2)};
        for (BlockPos p : candidatos) {
            BlockState e = f.level().getBlockState(p);
            if (e.isAir() || e.getCollisionShape(f.level(), p).isEmpty()) continue;
            if (passagemOk(e, p)) {
                alvo = p.immutable();
                escavando = true;
                return;
            }
        }
    }

    private void avisar(String motivo) {
        if (!Configuracao.MENSAGENS) return;
        Player dono = f.getDonoJogador();
        if (dono == null) return;
        dono.sendSystemMessage(Component.literal("[Funcionário] " + motivo + " | alvo=" + alvo + " destino=" + destino
                + " escavando=" + escavando + " dir=" + dirMina + " pos=" + f.blockPosition().toShortString()));
    }

    /** 30 s sem quebrar nada nem avançar: avisa o motivo, recomeça do zero e, se for preciso, sai do buraco. */
    private void travou() {
        estouros++;
        if (estouros <= 3) avisar("ficou travado, recomeçando");
        semProgresso = 0;
        soltarAlvo();
        destino = null;
        fila.clear();
        falhas.clear();
        metaForcada = null;
        centro = null;
        escadaFeita = false;
        modoSalao = false;
        viaEscada = false;
        passoTunel = false;
        escavando = false;
        if (dirMina != null) dirMina = dirMina.getClockWise();
        if (estouros >= 3 && ultima != Tarefa.PEDRA && ultima != Tarefa.MINERIO) {
            f.falar(Falas.Situacao.NADA_ACHADO);
            f.definirTarefa(Tarefa.PARAR);
            return;
        }
        f.getNavigation().stop();
        if (estouros >= 2 && (ultima == Tarefa.PEDRA || ultima == Tarefa.MINERIO)) {
            mudarDeLugar();
        } else {
            f.teleportarParaSeguro(f.getCasa());
        }
    }

    /** Melhorias: quebra também os blocos ao lado (2x2, 3x3 ou 4x4), no plano de frente para onde ele olha. */
    private boolean quebrarArea(BlockPos principal, Tarefa t) {
        int nivelUp = f.getNivel();
        if (nivelUp <= 0 || t == Tarefa.MADEIRA || t == Tarefa.COLHER || t == Tarefa.MINERIO) return false; // minério: um bloco por vez
        int lado = nivelUp + 1;
        int lo = lado == 2 ? 0 : -1;
        int hi = lado == 2 ? 1 : (lado == 3 ? 1 : 2);
        Level mundo = f.level();
        Vec3 olho = f.getEyePosition();
        Vec3 c = Vec3.atCenterOf(principal);
        double ax = Math.abs(c.x - olho.x);
        double ay = Math.abs(c.y - olho.y);
        double az = Math.abs(c.z - olho.z);
        boolean cheio = false;
        for (int i = lo; i <= hi; i++) {
            for (int j = lo; j <= hi; j++) {
                if (i == 0 && j == 0) continue;
                BlockPos p;
                if (ay >= ax && ay >= az) p = principal.offset(i, 0, j);
                else if (ax >= az) p = principal.offset(0, i, j);
                else p = principal.offset(i, j, 0);
                BlockState e = mundo.getBlockState(p);
                if (e.isAir() || !naturalCavavel(e) || !podeCavar(p, e)) continue;
                filaArea.add(p.immutable());
            }
        }
        return cheio;
    }

    /** Marca o resto da veia (minérios ligados ao que ele acabou de quebrar) para ele ir buscar um por um. */
    private void coletarVeia(BlockPos origem) {
        Level nivel = f.level();
        ArrayDeque<BlockPos> bfs = new ArrayDeque<>();
        Set<BlockPos> vistos = new HashSet<>();
        bfs.add(origem.immutable());
        vistos.add(origem.immutable());
        int n = 0;
        while (!bfs.isEmpty() && n < 120) {
            BlockPos p = bfs.poll();
            for (int dx = -1; dx <= 1; dx++) {
                for (int dy = -1; dy <= 1; dy++) {
                    for (int dz = -1; dz <= 1; dz++) {
                        BlockPos q = p.offset(dx, dy, dz);
                        if (!vistos.add(q.immutable())) continue;
                        if (!nivel.hasChunkAt(q) || falhas.contains(q)) continue;
                        if (f.getMinerio().serve(nivel.getBlockState(q))) {
                            veia.add(q.immutable());
                            bfs.add(q.immutable());
                            n++;
                        }
                    }
                }
            }
        }
    }

    /** Não dá para quebrar nada por aqui: vai (teleporta) para outro lugar e recomeça a busca. */
    private void mudarDeLugar() {
        Level nivel = f.level();
        long agora = nivel.getGameTime();
        if (agora - ultimaMudanca < 400) return; // evita ficar teleportando sem parar
        ultimaMudanca = agora;
        BlockPos pe = f.blockPosition();
        for (int i = 0; i < 8; i++) {
            Direction d = Direction.from2DDataValue(f.getRandom().nextInt(4));
            BlockPos ponto = pe.relative(d, 24 + f.getRandom().nextInt(24));
            if (!nivel.hasChunkAt(ponto)) continue;
            BlockPos topo = nivel.getHeightmapPos(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, ponto);
            if (!nivel.getBlockState(topo.below()).getFluidState().isEmpty() || construcaoPerto(topo)) continue;
            if (f.teleportarParaSeguro(topo)) {
                f.setCasa(f.blockPosition());
                soltarAlvo();
                destino = null;
                fila.clear();
                filaArea.clear();
                veia.clear();
                falhasPasso = 0;
                falhas.clear();
                metaForcada = null;
                centro = null;
                escadaFeita = false;
                modoSalao = false;
                viaEscada = false;
                passoTunel = false;
                escavando = false;
                bloqueios = 0;
                falhasOre = 0;
                tunelForcado = 0;
                oreXray = null;
                semProgresso = 0;
                protegidos.clear();
                return;
            }
        }
    }

    /** Há construção de jogador num raio de 3 em volta (vilas, casas): não é um bom lugar para recomeçar. */
    private boolean construcaoPerto(BlockPos c) {
        Level nivel = f.level();
        for (BlockPos q : BlockPos.betweenClosed(c.offset(-3, -1, -3), c.offset(3, 3, 3))) {
            if (nivel.hasChunkAt(q) && ehConstrucao(nivel.getBlockState(q))) return true;
        }
        return false;
    }

    private void bloquear(BlockPos meta) {
        bloqueios++;
        if (++falhasPasso >= 8 && ultima != Tarefa.MADEIRA) {
            falhasPasso = 0;
            mudarDeLugar();
            return;
        }
        if (meta != null) {
            falhas.add(meta);
            // vários minérios seguidos sem caminho (água/lava no meio): abre um túnel por conta própria em vez de ficar parado
            if (++falhasOre >= 3) {
                falhasOre = 0;
                tunelForcado = 40;
                oreXray = null;
            }
        } else {
            dirMina = dirMina.getClockWise();
        }
        esperaBusca = 1;
    }

    /** Profundidade (y) onde cada minério costuma aparecer. */
    private int profundidadeAlvo() {
        return switch (f.getMinerio()) {
            case DIAMANTE, REDSTONE -> -54;
            case OURO -> -16;
            case LAPIS -> 0;
            case FERRO -> 16;
            case COBRE -> 40;
            case CARVAO -> 45;
            case ESMERALDA -> 90;
            default -> 0;
        };
    }

    /** Minério: não achou nada num raio de 20 (raio-X): desce em escada até a profundidade certa e abre túnel. */
    private boolean cavarEmFrente() {
        passosMina++;
        if (dirMina == null) dirMina = f.getDirTunel();
        centro = null;
        viaEscada = false;
        int y = f.blockPosition().getY();
        int alvoY = ultima == Tarefa.PEDRA ? -50 : profundidadeAlvo();
        int passo = y > alvoY + 1 ? -1 : 0;
        return planejarPasso(null, dirMina, passo);
    }

    /** Pedra: quebra tudo que é natural num salão 7x7x3; limpo, avança 7 blocos e continua (até o inventário encher). */
    private boolean escolherSalao() {
        Level nivel = f.level();
        for (int volta = 0; volta < 4; volta++) {
            BlockPos melhor = null;
            double melhorD = Double.MAX_VALUE;
            for (BlockPos p : BlockPos.betweenClosed(centro.offset(-3, 0, -3), centro.offset(3, 2, 3))) {
                if (falhas.contains(p) || !nivel.hasChunkAt(p)) continue;
                BlockState e = nivel.getBlockState(p);
                if (!valido(Tarefa.PEDRA, e, p)) continue;
                double d = f.distanceToSqr(Vec3.atCenterOf(p));
                if (d < melhorD) {
                    melhorD = d;
                    melhor = p.immutable();
                }
            }
            if (melhor != null) {
                alvo = melhor;
                escavando = false;
                return true;
            }
            Direction d = dirSalao != null ? dirSalao : f.getDirTunel();
            centro = centro.relative(d, 7);
        }
        return false;
    }

    /** Madeira: não tem árvore perto, então procura (em chunks carregados) a copa mais próxima e vai até lá. */
    private boolean buscarMadeiraLonge() {
        if (viagens >= 10) return false;
        Level nivel = f.level();
        BlockPos pe = f.blockPosition();
        BlockPos melhor = null;
        double melhorD = Double.MAX_VALUE;
        for (int dx = -64; dx <= 64; dx += 3) {
            for (int dz = -64; dz <= 64; dz += 3) {
                if (Math.abs(dx) <= 16 && Math.abs(dz) <= 16) continue; // perto já foi olhado
                int x = pe.getX() + dx;
                int z = pe.getZ() + dz;
                if (!nivel.hasChunkAt(new BlockPos(x, pe.getY(), z))) continue;
                int topo = nivel.getHeight(Heightmap.Types.MOTION_BLOCKING, x, z);
                BlockPos p = new BlockPos(x, topo - 1, z);
                BlockState e = nivel.getBlockState(p);
                if (!(e.is(BlockTags.LEAVES) || e.is(BlockTags.LOGS))) continue;
                double d = (double) dx * dx + (double) dz * dz;
                if (d < melhorD) {
                    melhorD = d;
                    melhor = p;
                }
            }
        }
        if (melhor == null) return false;
        viagens++;
        passoTunel = false;
        destino = melhor;
        recentrar = true;
        tempoSemChegar = 0;
        return true;
    }

    private BlockPos maisProximo(Tarefa t, BlockPos centro, int rh, int rv) {
        Level nivel = f.level();
        BlockPos melhor = null;
        double melhorD = Double.MAX_VALUE;
        for (BlockPos p : BlockPos.betweenClosed(centro.offset(-rh, -rv, -rh), centro.offset(rh, 8, rh))) {
            if (falhas.contains(p) || !nivel.hasChunkAt(p)) continue;
            BlockState e = nivel.getBlockState(p);
            boolean serve = t == Tarefa.MINERIO ? f.getMinerio().serve(e) : ehPedra(e);
            if (!serve || temFluidoPerto(p)) continue;
            double d = p.distSqr(centro);
            if (d < melhorD) {
                melhorD = d;
                melhor = p.immutable();
            }
        }
        return melhor;
    }

    private void andar() {
        Vec3 c = Vec3.atBottomCenterOf(destino);
        double dh = (f.getX() - c.x) * (f.getX() - c.x) + (f.getZ() - c.z) * (f.getZ() - c.z);
        // degrau cavado: só "chegou" quando está de fato dentro da célula (antes, 1,5 de distância
        // contava mesmo estando na célula vizinha, e ele ficava preso repetindo o mesmo degrau)
        boolean chegou = recentrar ? (dh < 16.0D && Math.abs(f.getY() - c.y) < 10.0D)
                : (Math.abs(f.getX() - c.x) < 0.45D && Math.abs(f.getZ() - c.z) < 0.45D
                        && Math.abs(f.getY() - c.y) < 0.7D);
        if (chegou) {
            destino = null;
            if (passoTunel) semProgresso = 0;
            passoTunel = false;
            travados = 0;
            if (recentrar) {
                f.setCasa(f.blockPosition());
                recentrar = false;
                falhas.clear();
            }
            return;
        }
        if (passoTunel) {
            // degrau cavado por ele: anda reto até a célula (sem pathfinding), rápido e sem travar
            double ddx = c.x - f.getX();
            double ddy = c.y - f.getY();
            double ddz = c.z - f.getZ();
            double dist = Math.sqrt(ddx * ddx + ddy * ddy + ddz * ddz);
            if (dist > 0.04D) {
                double k = Math.min(0.30D, dist) / dist;
                net.minecraft.world.phys.AABB prox = f.getBoundingBox().move(ddx * k, ddy * k, ddz * k);
                if (f.level().noCollision(f, prox)) {
                    f.getNavigation().stop();
                    f.moveTo(f.getX() + ddx * k, f.getY() + ddy * k, f.getZ() + ddz * k, f.getYRot(), f.getXRot());
                    f.setDeltaMovement(Vec3.ZERO);
                    f.fallDistance = 0.0F;
                    tempoSemChegar = 0;
                    semProgresso = 0;
                    return;
                }
            }
        }
        if (passoTunel && tempoSemChegar > 12) {
            // degrau que ele mesmo cavou: se o caminho falhar, só desliza até lá
            net.minecraft.world.phys.AABB caixa = f.getBoundingBox().move(c.x - f.getX(), c.y - f.getY(), c.z - f.getZ());
            if (f.level().noCollision(f, caixa)) {
                f.getNavigation().stop();
                f.moveTo(c.x, c.y, c.z, f.getYRot(), f.getXRot());
                return;
            }
        }
        // viagem longa (procurando árvore) sem caminho: teleporta para o chão perto do destino
        if (recentrar && ((tempoSemChegar > 40 && f.getNavigation().isDone()) || tempoSemChegar > 400)) {
            if (f.teleportarParaSeguro(destino)) {
                f.setCasa(f.blockPosition());
                recentrar = false;
                destino = null;
                passoTunel = false;
                falhas.clear();
                semProgresso = 0;
                return;
            }
        }
        if (++tempoSemChegar > (recentrar ? 700 : 200)) {
            destino = null;
            recentrar = false;
            if (++travados >= 4) {
                f.falar(Falas.Situacao.NADA_ACHADO);
                f.definirTarefa(Tarefa.PARAR);
            }
            return;
        }
        if (f.getNavigation().isDone() || f.tickCount % 20 == 0) {
            f.getNavigation().moveTo(c.x, c.y, c.z, 1.0D);
        }
    }

    private void minerarAlvo(Tarefa t) {
        Level nivel = f.level();
        BlockState estado = nivel.getBlockState(alvo);
        boolean ok = alvoArea ? (naturalCavavel(estado) && podeCavar(alvo, estado))
                : (escavando ? passagemOk(estado, alvo) : valido(t, estado, alvo));
        if (!ok) {
            soltarAlvo();
            return;
        }

        Vec3 cb = Vec3.atCenterOf(alvo);
        f.getLookControl().setLookAt(cb.x, cb.y, cb.z);
        boolean perto = f.getEyePosition().distanceToSqr(cb) <= (t == Tarefa.MADEIRA ? 36.0D : (t == Tarefa.MINERIO ? 49.0D : 16.0D));

        if (perto && veAlvo(alvo)) {
            f.getNavigation().stop();
            semVisao = 0;
            prepararFerramenta(t, estado);
            progresso++;
            if (progresso % 5 == 1) f.swing(InteractionHand.MAIN_HAND);
            if (progresso % 3 == 1 && nivel instanceof ServerLevel sl) {
                sl.sendParticles(new net.minecraft.core.particles.BlockParticleOption(
                                net.minecraft.core.particles.ParticleTypes.BLOCK, estado),
                        cb.x, cb.y, cb.z, 5, 0.25D, 0.25D, 0.25D, 0.05D);
            }
            int total = tempoParaQuebrar(t, estado, alvo);
            if (t == Tarefa.PEDRA || t == Tarefa.MINERIO) {
                // mineração produtiva: passagem (terra, pedra do caminho) cai bem mais rápido; o resto um pouco
                total = (alvoArea || escavando) ? Math.max(1, total / 5) : Math.max(1, total / 3);
            }
            int novoEstagio = Math.min(9, progresso * 10 / Math.max(1, total));
            if (novoEstagio != estagio) {
                estagio = novoEstagio;
                nivel.destroyBlockProgress(f.getId(), alvo, estagio);
            }
            if (progresso % 4 == 1) {
                nivel.playSound(null, alvo, estado.getSoundType().getHitSound(), SoundSource.BLOCKS, 0.6F, 0.8F);
            }
            if (progresso >= total) {
                boolean eraArea = alvoArea;
                BlockPos quebrado = alvo;
                if (t == Tarefa.PEDRA && !modoSalao && escavando && !eraArea && ehPedra(estado)) {
                    centro = quebrado;
                    modoSalao = true;
                    escadaFeita = true;
                }
                if (!escavando && viaEscada && !eraArea) {
                    centro = quebrado;
                    viaEscada = false;
                    escadaFeita = true;
                    modoSalao = t == Tarefa.PEDRA;
                }
                if (t == Tarefa.MADEIRA) viagens = 0;
                soltarAlvo();
                forcadas = 0;
                teleportesAlvo = 0;
                semProgresso = 0;
                bloqueios = 0;
                falhasOre = 0;
                boolean guardar = t == Tarefa.PEDRA ? ehPedra(estado)
                        : (!escavando || (t == Tarefa.MINERIO && f.getMinerio().serve(estado)));
                boolean cheio;
                if (guardar) {
                    cheio = f.quebrar(quebrado, t);
                } else {
                    nivel.destroyBlock(quebrado, false, f); // terra/pedra de passagem não enche o inventário
                    cheio = false;
                }
                falhasPasso = 0;
                if (t == Tarefa.MINERIO && f.getMinerio().serve(estado)) coletarVeia(quebrado);
                if (t == Tarefa.MADEIRA && !cheio) cheio = derrubarArvore(quebrado);
                if (!cheio && !eraArea) cheio = quebrarArea(quebrado, t);
                if (cheio && f.depositarRemoto()) {
                    cheio = false; // guardou nos Baús do Funcionário de longe: segue trabalhando
                }
                if (cheio) {
                    f.setLocalTrabalho(f.blockPosition());
                    BlockPos bau = f.acharBau();
                    f.setBauAlvo(bau);
                    if (bau == null) f.falar(Falas.Situacao.INV_CHEIO);
                    f.definirTarefa(Tarefa.ENTREGAR);
                }
            }
            return;
        }

        // ainda não alcança ou não enxerga o bloco: chega mais perto
        if (alvoArea && (!perto || ++semVisao > 10)) { // bloco extra da melhoria: não vale a pena correr atrás
            soltarAlvo();
            return;
        }
        if (perto && !escavando && desobstruir()) return;
        progresso = 0;
        limparRachadura();
        if (perto && ++semVisao > 40) {
            falharAlvo();
            return;
        }
        if (++tempoSemChegar > 400) {
            falharAlvo();
            return;
        }
        if (f.getNavigation().isDone()) {
            if (recalculos++ >= 3) {
                falharAlvo();
                return;
            }
            Path caminho = f.getNavigation().createPath(alvo, 1);
            if (caminho == null) {
                falharAlvo();
                return;
            }
            f.getNavigation().moveTo(caminho, 1.0D);
        }
    }

    // ------------------------------------------------------------------ auxiliares

    /** Escolhe a ferramenta certa para o bloco: pá para terra/areia; senão a da tarefa (machado, picareta, enxada). */
    private void prepararFerramenta(Tarefa t, BlockState estado) {
        if (estado.is(BlockTags.MINEABLE_WITH_SHOVEL) && f.equipar(ShovelItem.class)) return;
        if (t != Tarefa.COLHER) {
            // folhas, feno e afins: enxada/foice quebram mais rápido; teia, bambu e plantas: espada
            if (estado.is(BlockTags.MINEABLE_WITH_HOE) && f.equipar(FuncionarioEntity::ehEnxada)) return;
            if ((estado.is(net.minecraft.world.level.block.Blocks.COBWEB)
                    || estado.is(net.minecraft.world.level.block.Blocks.BAMBOO))
                    && f.equipar(s -> s.getItem() instanceof net.minecraft.world.item.SwordItem)) return;
        }
        Class<? extends Item> tipo = f.ferramentaPara(t);
        f.equipar(tipo != null ? tipo : HoeItem.class);
    }

    private void falharAlvo() {
        if (!escavando && alvo != null && desobstruir()) return;
        if (ultima == Tarefa.MADEIRA && alvo != null && teleportesAlvo < 2) {
            // tronco que não dá para alcançar andando (penhasco, buraco): vai direto para o chão perto dele
            teleportesAlvo++;
            BlockPos a = alvo.immutable();
            soltarAlvo();
            if (f.teleportarParaSeguro(a)) return;
            alvo = a;
        }
        boolean cavavel = !escavando && !modoSalao && (ultima == Tarefa.PEDRA || ultima == Tarefa.MINERIO);
        if (cavavel && forcadas < 6) {
            forcadas++;
            metaForcada = alvo.immutable();
            soltarAlvo();
            return;
        }
        falhas.add(alvo);
        soltarAlvo();
    }

    private void soltarAlvo() {
        limparRachadura();
        alvo = null;
        alvoArea = false;
        progresso = 0;
        tempoSemChegar = 0;
        recalculos = 0;
        semVisao = 0;
    }

    private void limparRachadura() {
        if (alvo != null && estagio >= 0) {
            f.level().destroyBlockProgress(f.getId(), alvo, -1);
        }
        estagio = -1;
    }

    /** Linha de visão: o primeiro bloco que o olhar do funcionário encontra tem de ser o próprio alvo. */
    private boolean veAlvo(BlockPos pos) {
        Vec3 olho = f.getEyePosition();
        Vec3 centro = Vec3.atCenterOf(pos);
        BlockHitResult r = f.level().clip(new ClipContext(olho, centro,
                ClipContext.Block.OUTLINE, ClipContext.Fluid.NONE, f));
        return r.getType() == HitResult.Type.MISS || r.getBlockPos().equals(pos);
    }

    /** Ticks para quebrar o bloco, usando a velocidade real da ferramenta na mão (igual ao jogador). */
    private int tempoParaQuebrar(Tarefa t, BlockState estado, BlockPos pos) {
        if (t == Tarefa.COLHER) return Math.max(1, Math.round(8 / f.getMultiplicadorVelocidade()));
        float dureza = estado.getDestroySpeed(f.level(), pos);
        if (dureza <= 0.0F) return 1;
        ItemStack ferramenta = f.getMainHandItem();
        float velocidade = ferramenta.isEmpty() ? 1.0F : ferramenta.getDestroySpeed(estado);
        if (velocidade > 1.0F) {
            int eficiencia = EnchantmentHelper.getBlockEfficiency(f);
            if (eficiencia > 0) velocidade += eficiencia * eficiencia + 1;
        }
        boolean ferramentaCerta = !estado.requiresCorrectToolForDrops() || ferramenta.isCorrectToolForDrops(estado);
        float danoPorTick = velocidade / dureza / (ferramentaCerta ? 30.0F : 100.0F);
        return Mth.clamp((int) Math.ceil(1.0F / danoPorTick / f.getMultiplicadorVelocidade()), 1, 400);
    }

    private boolean valido(Tarefa t, BlockState estado, BlockPos pos) {
        return switch (t) {
            case MADEIRA -> estado.is(BlockTags.LOGS);
            case PEDRA -> modoSalao ? (naturalCavavel(estado) && podeCavar(pos, estado) && exposto(pos))
                    : (ehPedra(estado) && exposto(pos) && !temConstrucaoPerto(pos));
            case MINERIO -> f.getMinerio().serve(estado) && exposto(pos) && !temConstrucaoPerto(pos);
            case COLHER -> estado.getBlock() instanceof CropBlock c && c.isMaxAge(estado);
            default -> false;
        };
    }

    private boolean ehPedra(BlockState estado) {
        return estado.is(BlockTags.BASE_STONE_OVERWORLD)
                || estado.is(Tags.Blocks.ORES);
    }

    /** Bloco claramente feito por jogador (tábuas, tijolos, vidro, portas, baús, tochas...). */
    private static boolean ehConstrucao(BlockState e) {
        if (e.isAir()) return false;
        if (e.getBlock() instanceof EntityBlock) return true;
        if (e.is(BlockTags.PLANKS) || e.is(BlockTags.STAIRS) || e.is(BlockTags.SLABS) || e.is(BlockTags.WALLS)
                || e.is(BlockTags.FENCES) || e.is(BlockTags.FENCE_GATES) || e.is(BlockTags.DOORS)
                || e.is(BlockTags.TRAPDOORS) || e.is(BlockTags.BEDS) || e.is(BlockTags.WOOL)
                || e.is(BlockTags.WOOL_CARPETS) || e.is(BlockTags.CANDLES) || e.is(BlockTags.BANNERS)
                || e.is(BlockTags.ALL_SIGNS) || e.is(BlockTags.RAILS)) return true;
        net.minecraft.resources.ResourceLocation id =
                net.minecraftforge.registries.ForgeRegistries.BLOCKS.getKey(e.getBlock());
        if (id == null) return false;
        String p = id.getPath();
        return p.contains("brick") || p.contains("glass") || p.contains("concrete") || p.contains("polished")
                || p.contains("smooth_") || p.contains("chiseled") || p.contains("cut_") || p.contains("torch")
                || p.contains("lantern") || p.contains("ladder") || p.contains("crafting") || p.contains("furnace")
                || p.contains("planks");
    }

    /** Casa ou construção encostada (raio 1): não quebra nada ali; só terreno que ninguém mexeu. */
    private boolean temConstrucaoPerto(BlockPos pos) {
        Level nivel = f.level();
        long agora = nivel.getGameTime();
        if (agora - limpezaProt > 400 || protegidos.size() > 20000) {
            protegidos.clear();
            limpezaProt = agora;
        }
        Boolean c = protegidos.get(pos);
        if (c != null) return c;
        boolean achou = false;
        for (BlockPos q : BlockPos.betweenClosed(pos.offset(-1, -1, -1), pos.offset(1, 1, 1))) {
            if (nivel.hasChunkAt(q) && ehConstrucao(nivel.getBlockState(q))) {
                achou = true;
                break;
            }
        }
        protegidos.put(pos.immutable(), achou);
        return achou;
    }

    /** Terreno natural que pode ser atravessado na escavação (nunca paredes de casa, madeira, tijolo...). */
    private boolean naturalCavavel(BlockState estado) {
        return estado.is(BlockTags.BASE_STONE_OVERWORLD)
                || estado.is(BlockTags.DIRT)
                || estado.is(BlockTags.SAND)
                || estado.is(Tags.Blocks.GRAVEL)
                || estado.is(Tags.Blocks.SANDSTONE)
                || estado.is(BlockTags.LEAVES)
                || estado.is(BlockTags.SNOW)
                || (estado.is(BlockTags.MINEABLE_WITH_SHOVEL) && !estado.is(BlockTags.CROPS)
                    && !estado.is(net.minecraft.world.level.block.Blocks.FARMLAND))
                || estado.is(Tags.Blocks.ORES);
    }

    /** Pode quebrar para passar? Terreno natural sempre; depois de ficar preso 2 vezes, qualquer bloco comum (sem baú, sem líquido). */
    private boolean passagemOk(BlockState estado, BlockPos pos) {
        if (!podeCavar(pos, estado)) return false;
        return naturalCavavel(estado); // nunca quebra construção de jogador
    }

    /** O primeiro bloco no caminho do olhar até o alvo, se for quebrável e estiver ao alcance: vira o novo alvo. */
    private boolean desobstruir() {
        if (alvo == null) return false;
        BlockHitResult r = f.level().clip(new ClipContext(f.getEyePosition(), Vec3.atCenterOf(alvo),
                ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, f));
        if (r.getType() != HitResult.Type.BLOCK) return false;
        BlockPos obst = r.getBlockPos().immutable();
        if (obst.equals(alvo)) return false;
        if (f.getEyePosition().distanceToSqr(Vec3.atCenterOf(obst)) > 20.0D) return false;
        BlockState e = f.level().getBlockState(obst);
        if (!passagemOk(e, obst)) {
            bloqueios++;
            return false;
        }
        soltarAlvo();
        alvo = obst;
        escavando = true;
        return true;
    }

    /** Sem bloco-entidade (baú etc.), com dureza normal e sem água/lava encostada. */
    private boolean podeCavar(BlockPos pos, BlockState estado) {
        Level nivel = f.level();
        if (estado.isAir() || !estado.getFluidState().isEmpty()) return false;
        if (estado.getDestroySpeed(nivel, pos) < 0.0F || estado.getBlock() instanceof EntityBlock) return false;
        return !temFluidoPerto(pos) && !temConstrucaoPerto(pos);
    }

    private boolean temFluidoPerto(BlockPos pos) {
        Level nivel = f.level();
        for (Direction d : Direction.values()) {
            if (!nivel.getBlockState(pos.relative(d)).getFluidState().isEmpty()) return true;
        }
        return false;
    }

    /** O bloco precisa ter pelo menos uma face livre e nenhum líquido encostado. */
    private boolean exposto(BlockPos pos) {
        Level nivel = f.level();
        boolean livre = false;
        for (Direction d : Direction.values()) {
            BlockPos vizinho = pos.relative(d);
            BlockState e = nivel.getBlockState(vizinho);
            if (!e.getFluidState().isEmpty()) return false;
            if (e.getCollisionShape(nivel, vizinho).isEmpty()) livre = true;
        }
        return livre;
    }
}
