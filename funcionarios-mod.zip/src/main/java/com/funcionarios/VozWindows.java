package com.funcionarios;

import com.mojang.logging.LogUtils;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Base64;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;
import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.SourceDataLine;
import org.slf4j.Logger;

/**
 * Vozes com variedade no Windows.
 *
 * O sintetizador do sistema (System.Speech) grava a fala num arquivo de áudio e o mod muda o tom antes de tocar
 * (voz grave de homem, voz mais fina de mulher, e variações por personalidade). Assim, mesmo com UMA voz instalada,
 * dá para ter vozes bem diferentes. Se o Windows tiver vozes masculinas e femininas em português, elas são usadas
 * conforme o gênero e o tom só varia de leve. Em outros sistemas, ou se algo falhar, o mod usa o narrador comum.
 */
public final class VozWindows {
    private static final Logger LOG = LogUtils.getLogger();

    private static final String SCRIPT = """
            Add-Type -AssemblyName System.Speech
            $todasSapi = @()
            $s = $null
            try {
              $s = New-Object System.Speech.Synthesis.SpeechSynthesizer
              $todasSapi = @($s.GetInstalledVoices() | Where-Object { $_.Enabled } | ForEach-Object { $_.VoiceInfo })
            } catch { }
            $wr = @()
            $asTask = $null
            try {
              Add-Type -AssemblyName System.Runtime.WindowsRuntime
              $null = [Windows.Media.SpeechSynthesis.SpeechSynthesizer, Windows.Media.SpeechSynthesis, ContentType = WindowsRuntime]
              $wr = @([Windows.Media.SpeechSynthesis.SpeechSynthesizer]::AllVoices)
              $asTask = ([System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object { $_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1 -and $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation`1' })[0]
            } catch { $wr = @() }
            $wrPt = @($wr | Where-Object { $_.Language -like 'pt*' })
            if ($wrPt.Count -gt 0) { $wr = $wrPt }
            $sapiPt = @($todasSapi | Where-Object { $_.Culture.Name -like 'pt*' })
            if ($sapiPt.Count -gt 0) { $todasSapi = $sapiPt }
            [Console]::InputEncoding = [Text.Encoding]::UTF8
            $nomesWr = ($wr | ForEach-Object { $_.DisplayName + '/' + $_.Gender.ToString() }) -join ', '
            $nomesSapi = ($todasSapi | ForEach-Object { $_.Name + '/' + $_.Gender.ToString() }) -join ', '
            [Console]::Out.WriteLine('INFO|Windows: ' + $nomesWr + ' | Classico: ' + $nomesSapi)
            [Console]::Out.Flush()
            while (($linha = [Console]::In.ReadLine()) -ne $null) {
              $desencontro = 1
              try {
                $p = $linha.Split('|')
                $quer = 'Male'; if ($p[0] -eq '1') { $quer = 'Female' }
                $i = [int]$p[1]
                $texto = [Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($p[2]))
                $feito = $false
                $mw = @($wr | Where-Object { $_.Gender.ToString() -eq $quer })
                if ($mw.Count -gt 0 -and $asTask -ne $null) {
                  try {
                    $syn = New-Object Windows.Media.SpeechSynthesis.SpeechSynthesizer
                    $syn.Voice = $mw[$i % $mw.Count]
                    $op = $syn.SynthesizeTextToStreamAsync($texto)
                    $task = $asTask.MakeGenericMethod([Windows.Media.SpeechSynthesis.SpeechSynthesisStream]).Invoke($null, @($op))
                    $task.Wait(-1) | Out-Null
                    $stream = $task.Result
                    $in = [System.IO.WindowsRuntimeStreamExtensions]::AsStreamForRead($stream)
                    $out = [System.IO.File]::Create($p[3])
                    $in.CopyTo($out)
                    $out.Close(); $in.Close(); $stream.Dispose(); $syn.Dispose()
                    $feito = $true
                    $desencontro = 0
                  } catch { }
                }
                if (-not $feito) {
                  $ms = @($todasSapi | Where-Object { $_.Gender.ToString() -eq $quer })
                  if ($ms.Count -gt 0) { $voz = $ms[$i % $ms.Count]; $desencontro = 0 }
                  else { $voz = $todasSapi[$i % $todasSapi.Count] }
                  $s.SelectVoice($voz.Name)
                  $s.SetOutputToWaveFile($p[3])
                  $s.Speak($texto)
                  $s.SetOutputToNull()
                }
              } catch { }
              [Console]::Out.WriteLine('OK|' + $desencontro)
              [Console]::Out.Flush()
            }
            """;

    private static final ExecutorService FILA = Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "funcionarios-voz");
        t.setDaemon(true);
        return t;
    });
    private static final AtomicBoolean OCUPADO = new AtomicBoolean();

    private static Process processo;
    private static BufferedWriter escritor;
    private static BufferedReader leitor;
    private static volatile boolean falhou;
    private static volatile String info;

    /** Lista de vozes que o Windows tem (para mostrar no chat uma vez). */
    public static String getInfo() {
        return info;
    }
    private static int partidas;
    private static int falhasSeguidas;

    private VozWindows() {}

    public static boolean disponivel() {
        return !falhou && System.getProperty("os.name", "").toLowerCase(Locale.ROOT).contains("win");
    }

    /**
     * Fala em segundo plano. genero: 0 masculino, 1 feminino. indice escolhe entre vozes do mesmo gênero.
     * fatorTom: 1,0 = voz original; menor = mais grave (e mais lenta); maior = mais aguda.
     * Devolve false se não deu para usar (aí o chamador cai no narrador comum).
     */
    public static boolean falar(String texto, int genero, int indice, float fatorTom) {
        if (!disponivel()) return false;
        if (!OCUPADO.compareAndSet(false, true)) return true; // ainda falando: não atropela
        FILA.execute(() -> {
            try {
                executar(texto, genero, indice, fatorTom);
                falhasSeguidas = 0;
            } catch (Exception e) {
                LOG.warn("[Funcionarios] Falha na voz do Windows.", e);
                if (++falhasSeguidas >= 3) {
                    falhou = true;
                    LOG.warn("[Funcionarios] Voz do Windows desativada; usando o narrador comum.");
                }
                if (processo != null) processo.destroy();
            } finally {
                OCUPADO.set(false);
            }
        });
        return true;
    }

    private static void garantir() throws IOException {
        if (processo != null && processo.isAlive()) return;
        if (++partidas > 4) {
            throw new IOException("PowerShell de voz caiu várias vezes");
        }
        String codificado = Base64.getEncoder().encodeToString(SCRIPT.getBytes(StandardCharsets.UTF_16LE));
        ProcessBuilder pb = new ProcessBuilder("powershell.exe", "-NoProfile", "-NonInteractive",
                "-ExecutionPolicy", "Bypass", "-EncodedCommand", codificado);
        pb.redirectErrorStream(true);
        processo = pb.start();
        escritor = new BufferedWriter(new OutputStreamWriter(processo.getOutputStream(), StandardCharsets.UTF_8));
        leitor = new BufferedReader(new InputStreamReader(processo.getInputStream(), StandardCharsets.UTF_8));
        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            if (processo != null) processo.destroy();
        }));
    }

    private static void executar(String texto, int genero, int indice, float fatorTom) throws Exception {
        garantir();
        Path wav = Files.createTempFile("funcionarios-voz", ".wav");
        try {
            String b64 = Base64.getEncoder().encodeToString(texto.getBytes(StandardCharsets.UTF_8));
            String caminho = wav.toAbsolutePath().toString().replace("|", "");
            escritor.write((genero == 1 ? "1" : "0") + "|" + Math.abs(indice) + "|" + b64 + "|" + caminho + "\n");
            escritor.flush();
            String resposta = lerResposta(20000);
            if (resposta == null) throw new IOException("o sintetizador não respondeu");
            boolean desencontro = resposta.endsWith("|1"); // não há voz do gênero pedido: o tom faz a diferença toda
            // voz do gênero certo: só uma variação mínima por personagem; sem voz do gênero: no máximo uma leve mudança
            float fator = desencontro ? Math.max(0.92F, Math.min(1.06F, fatorTom)) : 1.0F + (fatorTom - 1.0F) * 0.15F;
            tocar(wav, fator);
        } finally {
            Files.deleteIfExists(wav);
        }
    }

    private static String lerResposta(long limiteMs) throws IOException, InterruptedException {
        long fim = System.currentTimeMillis() + limiteMs;
        while (System.currentTimeMillis() < fim) {
            if (leitor.ready()) {
                String linha = leitor.readLine();
                if (linha == null) return null;
                if (linha.startsWith("INFO|")) {
                    info = linha.substring(5);
                    LOG.info("[Funcionarios] Vozes encontradas: {}", info);
                }
                if (linha.startsWith("OK|")) return linha;
            } else {
                Thread.sleep(15);
            }
        }
        return null;
    }

    private static void tocar(Path wav, float fator) throws Exception {
        try (AudioInputStream entrada = AudioSystem.getAudioInputStream(wav.toFile())) {
            AudioFormat formato = entrada.getFormat();
            byte[] dados = entrada.readAllBytes();
            if (dados.length == 0) throw new IOException("áudio vazio");
            boolean pcm16 = formato.getSampleSizeInBits() == 16
                    && formato.getEncoding() == AudioFormat.Encoding.PCM_SIGNED && !formato.isBigEndian();
            if (pcm16 && Math.abs(fator - 1.0F) > 0.01F) {
                dados = reamostrar(dados, formato.getChannels(), fator);
                if (formato.getChannels() == 1) dados = restaurarDuracao(dados, fator);
            }
            try (SourceDataLine linha = AudioSystem.getSourceDataLine(formato)) {
                linha.open(formato);
                linha.start();
                linha.write(dados, 0, dados.length);
                linha.drain();
            }
        }
    }

    /** Muda o tom por reamostragem linear: fator > 1 = mais agudo e mais rápido; fator < 1 = mais grave e mais lento. */
    private static byte[] reamostrar(byte[] dados, int canais, float fator) {
        int quadros = dados.length / (2 * canais);
        int novos = Math.max(1, (int) (quadros / fator));
        byte[] saida = new byte[novos * 2 * canais];
        for (int i = 0; i < novos; i++) {
            double pos = i * (double) fator;
            int i0 = Math.min((int) pos, quadros - 1);
            int i1 = Math.min(i0 + 1, quadros - 1);
            double frac = pos - i0;
            for (int c = 0; c < canais; c++) {
                int a = amostra(dados, i0 * canais + c);
                int b = amostra(dados, i1 * canais + c);
                int v = (int) Math.round(a + (b - a) * frac);
                int destino = (i * canais + c) * 2;
                saida[destino] = (byte) (v & 0xFF);
                saida[destino + 1] = (byte) ((v >> 8) & 0xFF);
            }
        }
        return saida;
    }

    /**
     * Depois da reamostragem o áudio ficou mais lento (tom grave) ou mais rápido (tom agudo). Esta rotina (WSOLA)
     * devolve a duração original sem mexer no tom: fica voz grave, mas falando em velocidade normal.
     */
    private static byte[] restaurarDuracao(byte[] dados, float razao) {
        int n = dados.length / 2;
        if (n < 4000) return dados;
        double[] x = new double[n];
        for (int i = 0; i < n; i++) x[i] = amostra(dados, i);
        int janela = 1024;
        int hs = janela / 2;
        int delta = janela / 4;
        int saidaLen = (int) (n * (double) razao);
        double[] y = new double[saidaLen + janela];
        double[] peso = new double[saidaLen + janela];
        double[] hann = new double[janela];
        for (int i = 0; i < janela; i++) hann[i] = 0.5 - 0.5 * Math.cos(2 * Math.PI * i / janela);
        int anterior = 0;
        for (int k = 0; (long) k * hs < saidaLen; k++) {
            int nominal = (int) (k * (double) hs / razao);
            int pos;
            if (k == 0) {
                pos = 0;
            } else {
                int alvo = anterior + hs;
                int lo = Math.max(0, nominal - delta);
                int hi = Math.min(n - janela - 1, nominal + delta);
                if (hi < lo || alvo + janela >= n) {
                    pos = Math.max(0, Math.min(nominal, n - janela - 1));
                } else {
                    pos = lo;
                    double melhor = -Double.MAX_VALUE;
                    for (int c = lo; c <= hi; c += 2) {
                        double soma = 0;
                        for (int i = 0; i < janela; i += 2) soma += x[c + i] * x[alvo + i];
                        if (soma > melhor) {
                            melhor = soma;
                            pos = c;
                        }
                    }
                }
            }
            anterior = pos;
            int base = k * hs;
            for (int i = 0; i < janela && pos + i < n; i++) {
                y[base + i] += x[pos + i] * hann[i];
                peso[base + i] += hann[i];
            }
        }
        byte[] saida = new byte[saidaLen * 2];
        for (int i = 0; i < saidaLen; i++) {
            double v = peso[i] > 1e-6 ? y[i] / peso[i] : 0;
            int q = (int) Math.max(-32768, Math.min(32767, Math.round(v)));
            saida[i * 2] = (byte) (q & 0xFF);
            saida[i * 2 + 1] = (byte) ((q >> 8) & 0xFF);
        }
        return saida;
    }

    private static int amostra(byte[] dados, int indice) {
        int baixo = dados[indice * 2] & 0xFF;
        int alto = dados[indice * 2 + 1]; // com sinal
        return (alto << 8) | baixo;
    }
}
